"""공연 쇼츠 편집기 — Claude Code 용 명령 도구.

편집기(서버)가 켜져 있을 때, 같은 노트북에서 실행한다.
  list                         영상 목록 (번호, 상태, 구간 수, 자막 채움 여부)
  show  <영상>                 그 영상의 편집 내용(구간·자막·작품 정보·캡션)
  frames <영상> [--overview]   구간마다 장면 사진(앞·중간·끝 3장을 붙인 1장) 경로. --overview 면 영상 전체 12장도
  set-info <영상> 키=값 ...    작품 정보: series year en ko company tags
  set-hook <영상> <구간번호> <자막>     자막 (최대 2줄, 줄바꿈은 \\n, 금색은 *별표*)
  set-badge <영상> <구간번호> on|off|hero   수상 배지 (hero = 크게+빛, '베스트 퍼포먼스' 장면)
  set-seg <영상> <구간번호> <시작초> <끝초>   구간 시간 바꾸기
  add-seg <영상> <시작초> <끝초>       구간 추가 (맨 뒤)
  del-seg <영상> <구간번호>            구간 지우기
  set-caption <영상> <캡션>            올릴 때 쓸 설명 (줄바꿈은 \\n)
  ready <영상>                 '🤖 자막 완료 · 확인 필요' 로 표시 (사용자가 앱에서 확인 후 만들기)
<영상> 은 list 의 번호 또는 파일 이름 일부.
"""
import json
import os
import secrets
import sys
import urllib.request

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass


def data_dir():
    d = os.environ.get("SHORTSMAKER_DATA")
    if not d:
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        d = os.path.join(base, "ShortsMaker", "data")
    return d


def base_url():
    try:
        port = open(os.path.join(data_dir(), "port.txt")).read().strip()
    except OSError:
        port = "8765"
    return f"http://127.0.0.1:{port}"


def call(path, body=None):
    url = base_url() + path
    data = None if body is None else json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=600) as r:
            out = json.loads(r.read().decode("utf-8"))
    except urllib.error.URLError as e:
        die(f"편집기 서버에 연결할 수 없어요 ({e}). 바탕화면의 '공연 쇼츠 편집기'를 켜 주세요.")
    if isinstance(out, dict) and out.get("error"):
        die(out["error"])
    return out


def die(msg):
    print("오류: " + msg)
    sys.exit(1)


def files():
    r = call("/api/files")
    if not r.get("ok"):
        die("소스 폴더를 찾을 수 없어요: " + str(r.get("folder")))
    return r["files"]


def pick(ref):
    fs = files()
    if ref.isdigit() and 1 <= int(ref) <= len(fs):
        return fs[int(ref) - 1]
    hits = [f for f in fs if ref.lower() in f["name"].lower() or ref.lower() in (f.get("folder") or "").lower()]
    if len(hits) == 1:
        return hits[0]
    if not hits:
        die(f"'{ref}' 에 맞는 영상이 없어요. list 로 번호를 확인해 주세요.")
    die(f"'{ref}' 에 맞는 영상이 {len(hits)}개예요. 번호로 골라 주세요.")


def project(f):
    r = call("/api/project_get", {"path": f["path"]})
    pj = r.get("project") or {"segments": [], "bof": r.get("default_bof") or {}, "status": ""}
    pj.setdefault("bof", r.get("default_bof") or {})
    pj.setdefault("segments", [])
    return pj


def save(f, pj, status=None):
    body = {"path": f["path"], "segments": pj["segments"], "bof": pj["bof"]}
    if "caption" in pj:
        body["caption"] = pj["caption"]
    if status:
        body["status"] = status
    return call("/api/project", body)


STATUS = {"auto": "자동 초안", "edit": "편집 중", "ready": "자막 완료·확인 필요", "made": "완성", "": "초안 없음"}


def seg_index(pj, n):
    try:
        i = int(n) - 1
    except ValueError:
        die("구간 번호는 숫자로 적어 주세요.")
    if not 0 <= i < len(pj["segments"]):
        die(f"구간 {n} 이 없어요. (지금 {len(pj['segments'])}개)")
    return i


def unescape(t):
    return t.replace("\\n", "\n")


def main(argv):
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(__doc__)
        return
    cmd, args = argv[0], argv[1:]
    if cmd == "list":
        for i, f in enumerate(files(), 1):
            pj = project(f)
            segs = pj["segments"]
            hooks = sum(1 for s in segs if (s.get("hook") or "").strip())
            st = STATUS.get(pj.get("status", ""), pj.get("status", ""))
            print(f"{i:>2}. [{st}] {f['name']}" + (f"  (폴더: {f['folder']})" if f.get("folder") else "") +
                  f"  — 구간 {len(segs)}개, 자막 {hooks}/{len(segs)}, 제목: {pj['bof'].get('en') or '-'}")
        return
    if not args:
        die("영상을 골라 주세요 (번호 또는 이름 일부).")
    f = pick(args[0])
    pj = project(f)
    if cmd == "show":
        print(json.dumps({"file": f["name"], "folder": f.get("folder"), "status": pj.get("status"),
                          "bof": pj["bof"], "caption": pj.get("caption", ""),
                          "segments": [{"번호": i + 1, "start": s["start"], "end": s["end"],
                                        "길이": round(s["end"] - s["start"], 1), "hook": s.get("hook", ""),
                                        "badge": s.get("badge") if s.get("badge") == "hero" else bool(s.get("badge"))}
                                       for i, s in enumerate(pj["segments"])]},
                         ensure_ascii=False, indent=2))
    elif cmd == "frames":
        r = call("/api/frames", {"path": f["path"], "overview": "--overview" in args})
        import re
        import shutil
        dest = os.path.join(os.getcwd(), "frames", re.sub(r"[^0-9A-Za-z가-힣._-]+", "_", os.path.splitext(f["name"])[0]))
        os.makedirs(dest, exist_ok=True)

        def bring(src):
            if not src or not os.path.exists(src):
                return "(사진 없음)"
            dst = os.path.join(dest, os.path.basename(src))
            shutil.copyfile(src, dst)
            return os.path.relpath(dst, os.getcwd()).replace("\\", "/")
        print(f"영상 길이 {r['duration']:.1f}초 — 사진은 Read 도구로 열어 보세요")
        for sg in r["segments"]:
            print(f"구간 {sg['segment']} ({sg['start']:.1f}~{sg['end']:.1f}초, 사진 시점 {sg['times']}): {bring(sg['image'])}")
        if r.get("overview"):
            ov = r["overview"]
            print(f"전체 훑어보기 ({ov['layout']}, 시점 {ov['times']}): {bring(ov['image'])}")
    elif cmd == "set-info":
        for kv in args[1:]:
            k, _, v = kv.partition("=")
            if k not in ("series", "year", "en", "ko", "company", "tags"):
                die(f"모르는 항목 '{k}' — series year en ko company tags 중에서 써 주세요.")
            pj["bof"][k] = v
        save(f, pj)
        print("작품 정보 저장:", json.dumps(pj["bof"], ensure_ascii=False))
    elif cmd == "set-hook":
        if len(args) < 3:
            die("set-hook <영상> <구간번호> <자막>")
        i = seg_index(pj, args[1])
        hook = unescape(" ".join(args[2:]))
        lines = hook.split("\n")
        if len(lines) > 2:
            die(f"자막은 최대 2줄이에요. (지금 {len(lines)}줄) 줄을 줄여서 다시 써 주세요.")
        pj["segments"][i]["hook"] = hook
        save(f, pj)
        print(f"구간 {i + 1} 자막 저장: {hook!r}")
        long_ = [ln.replace("*", "") for ln in lines if len(ln.replace("*", "")) > 18]
        if long_:
            print(f"  참고: 한 줄은 16자 안팎이 좋아요. 긴 줄: {long_}")
    elif cmd == "set-badge":
        if len(args) < 3:
            die("set-badge <영상> <구간번호> on|off|hero")
        i = seg_index(pj, args[1])
        v = args[2].lower()
        pj["segments"][i]["badge"] = "hero" if v in ("hero", "강조") else v in ("on", "1", "true", "켜기", "예")
        save(f, pj)
        print(f"구간 {i + 1} 배지: {pj['segments'][i]['badge']}")
    elif cmd == "set-seg":
        i = seg_index(pj, args[1])
        a, b = float(args[2]), float(args[3])
        if b - a < 0.5:
            die("구간이 너무 짧아요.")
        pj["segments"][i]["start"], pj["segments"][i]["end"] = round(a, 2), round(b, 2)
        save(f, pj)
        print(f"구간 {i + 1}: {a}~{b}초")
    elif cmd == "add-seg":
        a, b = float(args[1]), float(args[2])
        land = None
        tmpl = pj["segments"][-1]["framing"] if pj["segments"] else {"mode": "fit", "zoom": 1, "px": 0.5, "py": 0.379}
        pj["segments"].append({"id": secrets.token_hex(4), "path": f["path"], "name": f["name"], "start": round(a, 2),
                               "end": round(b, 2), "framing": dict(tmpl), "hook": "", "badge": True})
        save(f, pj)
        print(f"구간 {len(pj['segments'])} 추가: {a}~{b}초")
    elif cmd == "del-seg":
        i = seg_index(pj, args[1])
        pj["segments"].pop(i)
        save(f, pj)
        print(f"구간 {i + 1} 삭제 (남은 구간 {len(pj['segments'])}개)")
    elif cmd == "set-caption":
        pj["caption"] = unescape(" ".join(args[1:]))
        save(f, pj)
        print("캡션 저장:\n" + pj["caption"])
    elif cmd == "ready":
        save(f, pj, status="ready")
        print(f"'{f['name']}' — 자막 완료·확인 필요 로 표시했어요. 앱에서 확인하고 '만들기'를 누르면 돼요.")
    else:
        die(f"모르는 명령 '{cmd}'. help 로 사용법을 볼 수 있어요.")


if __name__ == "__main__":
    main(sys.argv[1:])
