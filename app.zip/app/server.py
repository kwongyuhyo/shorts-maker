"""공연 쇼츠 편집기 — 로컬 서버 (파이썬 기본 라이브러리만 사용)."""
import base64
import datetime
import hashlib
import hmac
import secrets
import json
import mimetypes
import os
import re
import shutil
import socket
import string
import subprocess
import sys
import threading
import time
import traceback
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

APP_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(APP_DIR)
WEB_DIR = os.path.join(APP_DIR, "web")
sys.path.insert(0, APP_DIR)
from engine import Engine  # noqa: E402

IS_WIN = os.name == "nt"
VERSION = open(os.path.join(APP_DIR, "VERSION"), encoding="utf-8").read().strip()


def data_dir():
    d = os.environ.get("SHORTSMAKER_DATA")
    if not d:
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        d = os.path.join(base, "ShortsMaker", "data")
    os.makedirs(d, exist_ok=True)
    return d


DATA = data_dir()
CACHE = os.path.join(DATA, "cache")
LOGS = os.path.join(DATA, "logs")
os.makedirs(CACHE, exist_ok=True)
os.makedirs(LOGS, exist_ok=True)
LOG_FILE = os.path.join(LOGS, "app.log")
SETTINGS_FILE = os.path.join(DATA, "settings.json")
LOGO_FILE = os.path.join(DATA, "logo.png")
BADGE_DIR = os.path.join(DATA, "badges")
os.makedirs(BADGE_DIR, exist_ok=True)
PROJ_DIR = os.path.join(DATA, "projects")
os.makedirs(PROJ_DIR, exist_ok=True)
_PROJ_LOCK = threading.Lock()


def proj_file(path):
    return os.path.join(PROJ_DIR, hashlib.md5(os.path.normcase(os.path.abspath(path)).encode("utf-8")).hexdigest()[:20] + ".json")


def load_project(path):
    try:
        with open(proj_file(path), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def save_project(path, data):
    data["path"] = path
    data["updated"] = time.time()
    with _PROJ_LOCK:
        tmp = proj_file(path) + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, proj_file(path))


def default_bof(path):
    """폴더 이름이 작품 이름이면 영문 제목으로 미리 채움. 연도·시리즈는 마지막에 쓴 값."""
    last = (SETTINGS.get("style") or {}).get("bof") or {}
    b = {"series": "", "year": last.get("year", "") or str(datetime.date.today().year), "en": "", "ko": "", "company": "", "tags": ""}
    src = SETTINGS.get("source_dir") or ""
    parent = os.path.dirname(path)
    if src and os.path.normcase(os.path.abspath(parent)) != os.path.normcase(os.path.abspath(src)):
        b["en"] = os.path.basename(parent)
    return b
PORT_FILE = os.path.join(DATA, "port.txt")
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".mkv", ".avi", ".mts", ".m2ts", ".webm", ".3gp", ".wmv"}

_log_lock = threading.Lock()


def log(msg):
    line = f"[{datetime.datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n"
    with _log_lock:
        try:
            if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 2_000_000:
                os.replace(LOG_FILE, LOG_FILE + ".1")
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(line)
        except OSError:
            pass
    if sys.stdout:
        try:
            sys.stdout.write(line)
        except Exception:
            pass


# ---------------------------------------------------------------- 설정
DEFAULTS = {
    "source_dir": "",
    "output_dir": "",
    "encoder": "auto",
    "style": {},          # 글자·로고 스타일 (화면에서 관리)
    "loudnorm": True,
    "extra_files": [],    # '다른 곳에서 열기'로 연 파일 (다시 켜도 열 수 있게)
    "pin": "",            # 원격 접속 PIN
    "secret": "",         # 로그인 쿠키 서명용
    "remote": False,      # 원격 접속(Tailscale Funnel) 사용 여부
    "funnel_url": "",
}
PUBLIC_PATHS = {"/", "/index.html", "/manifest.webmanifest", "/api/ping", "/api/login", "/api/state"}
LOGIN_FAILS = {"n": 0, "until": 0.0}


def find_drive_root():
    """구글 드라이브 데스크톱의 '내 드라이브' 위치 찾기."""
    names = ["내 드라이브", "My Drive"]
    cands = []
    if IS_WIN:
        for L in string.ascii_uppercase:
            cands.append(f"{L}:\\")
    home = os.path.expanduser("~")
    cands += [os.path.join(home, "Google Drive"), os.path.join(home, "My Drive"), home]
    for c in cands:
        for n in names:
            p = os.path.join(c, n)
            try:
                if os.path.isdir(p):
                    return p
            except OSError:
                pass
    return ""


def fill_defaults(s):
    if not s.get("source_dir") or not s.get("output_dir"):
        root = find_drive_root()
        if root:
            if not s.get("source_dir"):
                s["source_dir"] = os.path.join(root, "공연소스")
            if not s.get("output_dir"):
                s["output_dir"] = os.path.join(root, "공연완성본")
    return s


def load_settings():
    s = dict(DEFAULTS)
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            s.update(json.load(f))
    except (OSError, ValueError):
        pass
    return fill_defaults(s)


def path_state(p):
    """ok / drive_missing(드라이브가 아직 안 켜짐) / folder_missing / unset"""
    if not p:
        return "unset"
    if os.path.isdir(p):
        return "ok"
    drive = os.path.splitdrive(p)[0]
    if IS_WIN and drive and not os.path.exists(drive + "\\"):
        return "drive_missing"
    return "folder_missing"


def save_settings(s):
    tmp = SETTINGS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(s, f, ensure_ascii=False, indent=2)
    os.replace(tmp, SETTINGS_FILE)


SETTINGS = load_settings()
ENGINE = Engine(os.path.join(ROOT_DIR, "runtime", "ffmpeg"), CACHE, log)
ALLOWED_FILES = set(os.path.normcase(os.path.abspath(p)) for p in SETTINGS.get("extra_files", []))
THUMB_LOCK = threading.Lock()
LOCAL_ONLY = {"pick_folder", "pick_file", "open", "shutdown", "remote_setup", "remote_off", "create_folder", "cleanup"}
LAST_BEAT = [time.time()]


def norm(p):
    return os.path.normcase(os.path.abspath(p))


def is_allowed(path):
    p = norm(path)
    roots = [SETTINGS.get("source_dir"), SETTINGS.get("output_dir"), CACHE]
    for r in roots:
        if r and (p == norm(r) or p.startswith(norm(r) + os.sep)):
            return True
    return p in ALLOWED_FILES


def safe_name(name):
    name = re.sub(r'[\\/:*?"<>|\r\n\t]', " ", name).strip().strip(".")
    name = re.sub(r"\s+", " ", name)
    return name[:80] or "쇼츠"


def unique_path(folder, base, ext=".mp4"):
    p = os.path.join(folder, base + ext)
    k = 2
    while os.path.exists(p):
        p = os.path.join(folder, f"{base} ({k}){ext}")
        k += 1
    return p


def run_dialog(kind, initial=""):
    """폴더/파일 고르기 창 (별도 프로세스로 띄움)."""
    py = sys.executable
    if IS_WIN and py.lower().endswith("python.exe"):
        w = py[:-10] + "pythonw.exe"
        if os.path.exists(w):
            py = w
    try:
        r = subprocess.run([py, os.path.join(APP_DIR, "dialogs.py"), kind, initial or ""],
                           capture_output=True, timeout=600,
                           creationflags=0x08000000 if IS_WIN else 0)
        out = r.stdout.decode("utf-8", "replace").strip()
        return out or None
    except Exception as e:
        log(f"대화상자 실패: {e}")
        return None


def open_in_explorer(path):
    try:
        if IS_WIN:
            if os.path.isfile(path):
                subprocess.Popen(["explorer", "/select,", path])
            else:
                os.startfile(path)  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception as e:
        log(f"폴더 열기 실패: {e}")


def list_files():
    src = SETTINGS.get("source_dir")
    if not src or not os.path.isdir(src):
        return {"ok": False, "reason": "no_folder", "folder": src, "files": []}
    files = []
    base_depth = src.rstrip(os.sep).count(os.sep)
    for dirpath, dirnames, filenames in os.walk(src):
        if dirpath.count(os.sep) - base_depth >= 2:
            dirnames[:] = []
        dirnames[:] = [d for d in dirnames if not d.startswith((".", "_"))]
        for fn in filenames:
            if os.path.splitext(fn)[1].lower() in VIDEO_EXT and not fn.startswith("."):
                p = os.path.join(dirpath, fn)
                try:
                    st = os.stat(p)
                except OSError:
                    continue
                rel = os.path.relpath(dirpath, src)
                pj = load_project(p)
                files.append({"path": p, "name": fn, "folder": "" if rel == "." else rel,
                              "size": st.st_size, "mtime": st.st_mtime,
                              "status": (pj or {}).get("status", "")})
    files.sort(key=lambda f: f["mtime"], reverse=True)
    return {"ok": True, "folder": src, "files": files[:500]}


def auth_token():
    if not SETTINGS.get("secret"):
        return None
    return hmac.new(SETTINGS["secret"].encode(), b"shortsmaker-v1", hashlib.sha256).hexdigest()


# ---------------------------------------------------------------- 원격 접속 (Tailscale Funnel)
def tailscale_exe():
    p = shutil.which("tailscale")
    if p:
        return p
    for base in (os.environ.get("PROGRAMFILES", r"C:\Program Files"), os.environ.get("PROGRAMFILES(X86)", "")):
        if base:
            c = os.path.join(base, "Tailscale", "tailscale.exe")
            if os.path.exists(c):
                return c
    return None


def run_tailscale(args, allow_elevate=True):
    """tailscale 명령 실행. 권한이 부족하면 관리자 권한(UAC 창)으로 다시 실행."""
    exe = tailscale_exe()
    if not exe:
        return False, "Tailscale이 설치돼 있지 않아요."
    flags = 0x08000000 if IS_WIN else 0
    try:
        r = subprocess.run([exe] + args, capture_output=True, timeout=60, creationflags=flags)
        out = (r.stdout + r.stderr).decode("utf-8", "replace")
        if r.returncode == 0:
            return True, out
    except Exception as e:
        out = str(e)
    log(f"tailscale {' '.join(args)} 실패(일반 권한): {out[-400:]}")
    if "login.tailscale.com" in out or not (IS_WIN and allow_elevate):
        return False, out
    # 관리자 권한으로 다시 (노트북 화면에 '예/아니요' 창이 뜸)
    tmp = os.path.join(CACHE, "ts_out.txt")
    try:
        os.remove(tmp)
    except OSError:
        pass
    cmdline = '"' + exe + '" ' + " ".join(args) + ' > "' + tmp + '" 2>&1'
    ps = ("Start-Process -FilePath cmd.exe -ArgumentList '/c', '" + cmdline.replace("'", "''") +
          "' -Verb RunAs -Wait -WindowStyle Hidden")
    try:
        subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
                       capture_output=True, timeout=180, creationflags=flags)
        out = open(tmp, encoding="utf-8", errors="replace").read() if os.path.exists(tmp) else ""
    except Exception as e:
        return False, str(e)
    ok = "error" not in out.lower() and "login.tailscale.com" not in out
    log(f"tailscale {' '.join(args)} (관리자): {out[-400:]}")
    return ok, out


def tailscale_dns():
    exe = tailscale_exe()
    if not exe:
        return ""
    try:
        r = subprocess.run([exe, "status", "--json"], capture_output=True, timeout=20,
                           creationflags=0x08000000 if IS_WIN else 0)
        d = json.loads(r.stdout.decode("utf-8", "replace"))
        return (d.get("Self", {}).get("DNSName") or "").rstrip(".")
    except Exception as e:
        log(f"tailscale status 실패: {e}")
        return ""


_FUNNEL_CACHE = {"t": 0.0, "on": False}


def funnel_on(fresh=False):
    """실제로 Funnel(인터넷 공개)이 켜져 있는지 tailscale 에 직접 물어봄."""
    if not fresh and time.time() - _FUNNEL_CACHE["t"] < 30:
        return _FUNNEL_CACHE["on"]
    exe = tailscale_exe()
    on = False
    if exe:
        try:
            r = subprocess.run([exe, "funnel", "status", "--json"], capture_output=True, timeout=20,
                               creationflags=0x08000000 if IS_WIN else 0)
            d = json.loads(r.stdout.decode("utf-8", "replace") or "{}")
            on = any((d.get("AllowFunnel") or {}).values())
        except Exception as e:
            log(f"funnel status 확인 실패: {e}")
    _FUNNEL_CACHE.update(t=time.time(), on=on)
    return on


def startup_shortcut(enable):
    """윈도우 시작할 때 편집기가 (창 없이) 같이 켜지게."""
    if not IS_WIN:
        return
    pyw = os.path.join(ROOT_DIR, "runtime", "python", "pythonw.exe")
    launch = os.path.join(ROOT_DIR, "launch.py")
    if enable:
        ps = ("$p = Join-Path ([Environment]::GetFolderPath('Startup')) 'ShortsMaker.lnk'; "
              "$s = (New-Object -ComObject WScript.Shell).CreateShortcut($p); "
              f"$s.TargetPath = '{pyw}'; $s.Arguments = '\"{launch}\" --no-browser'; "
              f"$s.WorkingDirectory = '{ROOT_DIR}'; $s.Save()")
    else:
        ps = "Remove-Item (Join-Path ([Environment]::GetFolderPath('Startup')) 'ShortsMaker.lnk') -ErrorAction SilentlyContinue"
    try:
        subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
                       capture_output=True, timeout=60, creationflags=0x08000000)
    except Exception as e:
        log(f"시작 프로그램 등록 실패: {e}")


def current_port():
    try:
        return int(open(PORT_FILE).read().strip())
    except Exception:
        return 8765


# ---------------------------------------------------------------- HTTP
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def is_local(self):
        """노트북에서 직접 연 경우만 True. Funnel로 들어온 요청은 X-Forwarded-* 헤더가 붙고 Host가 ts.net 주소."""
        if self.client_address[0] not in ("127.0.0.1", "::1"):
            return False
        if self.headers.get("X-Forwarded-For") or self.headers.get("X-Forwarded-Host") \
                or self.headers.get("Tailscale-Funnel-Request"):
            return False
        host = (self.headers.get("Host") or "").split(":")[0].lower()
        return host in ("127.0.0.1", "localhost", "")

    def authed(self):
        if self.is_local():
            return True
        tok = auth_token()
        if not tok or not SETTINGS.get("remote"):
            return False
        for part in (self.headers.get("Cookie") or "").split(";"):
            k, _, v = part.strip().partition("=")
            if k == "sm_auth" and hmac.compare_digest(v, tok):
                return True
        return False

    def log_message(self, fmt, *args):  # 조용히
        pass

    # ---- 응답 도우미
    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0:
            return {}
        return json.loads(self.rfile.read(n).decode("utf-8"))

    def send_file(self, path, mime=None, cache=False):
        try:
            size = os.path.getsize(path)
        except OSError:
            return self.send_error(404)
        mime = mime or mimetypes.guess_type(path)[0] or "application/octet-stream"
        rng = self.headers.get("Range")
        start, end = 0, size - 1
        code = 200
        if rng:
            m = re.match(r"bytes=(\d*)-(\d*)", rng)
            if m:
                if m.group(1):
                    start = int(m.group(1))
                    if m.group(2):
                        end = min(int(m.group(2)), size - 1)
                elif m.group(2):
                    start = max(0, size - int(m.group(2)))
                if start > end or start >= size:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{size}")
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                code = 206
        length = end - start + 1
        self.send_response(code)
        self.send_header("Content-Type", mime)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(length))
        if code == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.send_header("Cache-Control", "max-age=3600" if cache else "no-store")
        dn = getattr(self, "_download_name", None)
        if dn:
            self.send_header("Content-Disposition", "attachment; filename*=UTF-8''" + urllib.parse.quote(dn))
            self._download_name = None
        self.end_headers()
        try:
            with open(path, "rb") as f:
                f.seek(start)
                left = length
                while left > 0:
                    chunk = f.read(min(1 << 20, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
        except (ConnectionError, BrokenPipeError, OSError):
            pass

    # ---- 라우팅
    def do_GET(self):
        try:
            u = urllib.parse.urlparse(self.path)
            q = urllib.parse.parse_qs(u.query)
            p = u.path
            if not (p in PUBLIC_PATHS or p.startswith("/static/")) and not self.authed():
                return self.send_json({"error": "login", "need_login": True}, 401)
            if p == "/api/ping":
                return self.send_json({"ok": True, "app": "shortsmaker"})
            if p == "/manifest.webmanifest":
                body = json.dumps({
                    "name": "공연 쇼츠 편집기", "short_name": "쇼츠 편집기", "start_url": "/", "display": "standalone",
                    "background_color": "#15161b", "theme_color": "#15161b",
                    "icons": [{"src": "/static/icon.png", "sizes": "512x512", "type": "image/png"},
                              {"src": "/static/icon192.png", "sizes": "192x192", "type": "image/png"}]},
                    ensure_ascii=False).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/manifest+json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if p == "/" or p == "/index.html":
                return self.send_file(os.path.join(WEB_DIR, "index.html"), "text/html; charset=utf-8")
            if p.startswith("/static/"):
                rel = os.path.normpath(urllib.parse.unquote(p[len("/static/"):]))
                if rel.startswith("..") or os.path.isabs(rel):
                    return self.send_error(403)
                f = os.path.join(WEB_DIR, rel)
                mime = None
                if f.endswith(".js"):
                    mime = "text/javascript; charset=utf-8"
                elif f.endswith(".css"):
                    mime = "text/css; charset=utf-8"
                elif f.endswith(".woff2"):
                    mime = "font/woff2"
                return self.send_file(f, mime, cache=f.endswith(".woff2"))
            if p == "/media":
                path = q.get("path", [""])[0]
                if not path or not is_allowed(path) or not os.path.isfile(path):
                    return self.send_error(403)
                ext = os.path.splitext(path)[1].lower()
                mime = "video/webm" if ext in (".webm", ".mkv") else "video/mp4"
                if q.get("dl"):
                    self._download_name = os.path.basename(path)
                return self.send_file(path, mime)
            if p == "/api/badge":
                year = re.sub(r"\D", "", q.get("year", [""])[0])[:4]
                f = os.path.join(BADGE_DIR, f"{year}.png")
                if year and os.path.exists(f):
                    return self.send_file(f, "image/png")
                return self.send_error(404)
            if p == "/api/logo":
                if os.path.exists(LOGO_FILE):
                    return self.send_file(LOGO_FILE, "image/png")
                return self.send_error(404)
            if p == "/api/thumb":
                path = q.get("path", [""])[0]
                if not path or not is_allowed(path) or not os.path.isfile(path):
                    return self.send_error(403)
                t = self.thumb(path)
                if not t:
                    return self.send_error(404)
                return self.send_file(t, "image/jpeg", cache=True)
            if p == "/api/state":
                st = self.state()
                if st.get("need_login"):
                    return self.send_json(st, 401)
                return self.send_json(st)
            if p == "/api/files":
                return self.send_json(list_files())
            LAST_BEAT[0] = time.time()
            if p == "/api/job":
                st = ENGINE.job_status(q.get("id", [""])[0])
                return self.send_json(st or {"state": "missing"})
            return self.send_error(404)
        except Exception:
            log("GET 오류:\n" + traceback.format_exc())
            try:
                self.send_json({"error": "서버 오류"}, 500)
            except Exception:
                pass

    def do_POST(self):
        try:
            p = urllib.parse.urlparse(self.path).path
            body = self.read_json()
            LAST_BEAT[0] = time.time()
            if p == "/api/login":
                return self.do_login(body)
            if p not in PUBLIC_PATHS and not self.authed():
                return self.send_json({"error": "login", "need_login": True}, 401)
            if p.replace("/api/", "") in LOCAL_ONLY and not self.is_local():
                return self.send_json({"error": "이 기능은 고모 노트북에서만 할 수 있어요."}, 403)
            fn = getattr(self, "api_" + p.replace("/api/", "").replace("/", "_"), None)
            if not fn:
                return self.send_error(404)
            return self.send_json(fn(body))
        except Exception as e:
            log("POST 오류:\n" + traceback.format_exc())
            try:
                self.send_json({"error": str(e)}, 500)
            except Exception:
                pass

    def do_login(self, b):
        now = time.time()
        if now < LOGIN_FAILS["until"]:
            return self.send_json({"error": "여러 번 틀려서 잠시 잠겼어요. 5분 뒤에 다시 해 주세요."}, 429)
        pin = str(b.get("pin", "")).strip()
        if SETTINGS.get("remote") and SETTINGS.get("pin") and hmac.compare_digest(pin, SETTINGS["pin"]):
            LOGIN_FAILS["n"] = 0
            body = json.dumps({"ok": True}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Set-Cookie", f"sm_auth={auth_token()}; Path=/; Max-Age=7776000; HttpOnly; Secure; SameSite=Lax")
            self.end_headers()
            self.wfile.write(body)
            log("원격 로그인 성공")
            return
        LOGIN_FAILS["n"] += 1
        if LOGIN_FAILS["n"] >= 5:
            LOGIN_FAILS.update(n=0, until=now + 300)
        log("원격 로그인 실패")
        return self.send_json({"error": "PIN 번호가 맞지 않아요."}, 403)

    # ---- API
    def state(self):
        if not self.authed():
            return {"need_login": True, "remote": True, "version": VERSION}
        fill_defaults(SETTINGS)
        drive = find_drive_root()
        return {
            "source_state": path_state(SETTINGS.get("source_dir")),
            "version": VERSION,
            "settings": {k: v for k, v in SETTINGS.items() if k not in ("pin", "secret", "extra_files")},
            "drive_root": drive,
            "source_ok": bool(SETTINGS.get("source_dir")) and os.path.isdir(SETTINGS["source_dir"]),
            "output_ok": bool(SETTINGS.get("output_dir")),
            "encoder": ENGINE.encoder,
            "has_logo": os.path.exists(LOGO_FILE),
            "badges": sorted(f[:-4] for f in os.listdir(BADGE_DIR) if f.endswith(".png")),
            "platform": sys.platform,
            "remote": not self.is_local(),
            "remote_enabled": bool(SETTINGS.get("remote")),
            "funnel_url": SETTINGS.get("funnel_url", ""),
            "tailscale": bool(tailscale_exe()),
            "funnel_on": funnel_on() if (self.is_local() and SETTINGS.get("remote")) else None,
        }

    def thumb(self, path):
        import hashlib
        st = os.stat(path)
        key = hashlib.md5(f"{path}|{st.st_size}|{int(st.st_mtime)}".encode("utf-8")).hexdigest()[:16]
        out = os.path.join(CACHE, f"thumb_{key}.jpg")
        if os.path.exists(out):
            return out
        with THUMB_LOCK:   # 한 번에 하나씩 (옛날 노트북 + 드라이브 스트리밍 배려)
            if os.path.exists(out):
                return out
            for ss in ("5", "0"):
                try:
                    r = subprocess.run([ENGINE.ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-ss", ss,
                                        "-i", path, "-frames:v", "1", "-vf", "scale=192:-2", "-q:v", "6", out],
                                       capture_output=True, timeout=45,
                                       creationflags=0x08000000 if IS_WIN else 0)
                    if r.returncode == 0 and os.path.exists(out) and os.path.getsize(out) > 0:
                        return out
                except Exception as e:
                    log(f"썸네일 실패: {e}")
                    break
        return None

    def api_heartbeat(self, b):
        return {"ok": True}

    def api_project_get(self, b):
        path = b.get("path", "")
        if not is_allowed(path):
            return {"error": "열 수 없는 위치의 파일이에요."}
        pj = load_project(path)
        return {"project": pj, "default_bof": default_bof(path)}

    def api_frames(self, b):
        """Claude 가 볼 장면 사진. 구간마다 앞·중간·끝 3장을 가로로 붙인 사진 1장 + (선택) 영상 전체 훑어보기."""
        path = b.get("path", "")
        if not is_allowed(path):
            return {"error": "열 수 없는 위치의 파일이에요."}
        pj = load_project(path) or {}
        info = ENGINE.probe(path)
        px = ENGINE.proxy_path(path)
        src = px if os.path.exists(px) else path
        key = os.path.splitext(os.path.basename(proj_file(path)))[0]
        out_dir = os.path.join(CACHE, "frames_" + key)
        os.makedirs(out_dir, exist_ok=True)
        flags = 0x08000000 if IS_WIN else 0

        def grab(t, fn):
            subprocess.run([ENGINE.ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{max(0, t):.2f}", "-i", src,
                            "-frames:v", "1", "-vf", "scale=400:-2", "-q:v", "4", fn], capture_output=True, timeout=120, creationflags=flags)
            return os.path.exists(fn)

        result = {"segments": [], "overview": None, "duration": info["duration"]}
        for i, sg in enumerate(pj.get("segments") or []):
            a, e = float(sg["start"]), float(sg["end"])
            ts = [a + min(1.0, (e - a) * 0.15), (a + e) / 2, e - min(1.0, (e - a) * 0.15)]
            parts = []
            for k, t in enumerate(ts):
                fn = os.path.join(out_dir, f"s{i + 1}_{k}.jpg")
                if grab(t, fn):
                    parts.append(fn)
            sheet = os.path.join(out_dir, f"segment{i + 1}.jpg")
            if len(parts) == 3:
                subprocess.run([ENGINE.ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", parts[0], "-i", parts[1], "-i", parts[2],
                                "-filter_complex", "hstack=3", "-q:v", "4", sheet], capture_output=True, timeout=60, creationflags=flags)
            result["segments"].append({"segment": i + 1, "start": a, "end": e, "times": [round(t, 1) for t in ts],
                                       "image": sheet if os.path.exists(sheet) else (parts[0] if parts else None)})
        if b.get("overview"):
            n = 12
            d = info["duration"]
            times = [d * (k + 0.5) / n for k in range(n)]
            tiles = []
            for k, t in enumerate(times):
                fn = os.path.join(out_dir, f"o{k}.jpg")
                if grab(t, fn):
                    tiles.append(fn)
            ov = os.path.join(out_dir, "overview.jpg")
            if len(tiles) == n:
                args = [ENGINE.ffmpeg, "-hide_banner", "-loglevel", "error", "-y"]
                for fn in tiles:
                    args += ["-i", fn]
                rows = ";".join(f"{''.join(f'[{r * 4 + c}:v]' for c in range(4))}hstack=4[r{r}]" for r in range(3))
                args += ["-filter_complex", rows + ";[r0][r1][r2]vstack=3", "-q:v", "4", ov]
                subprocess.run(args, capture_output=True, timeout=120, creationflags=flags)
            result["overview"] = {"image": ov if os.path.exists(ov) else None, "times": [round(t, 1) for t in times],
                                  "layout": "가로 4장 x 세로 3줄, 왼쪽 위부터 시간 순서"}
        return result

    def api_project(self, b):
        path = b.get("path", "")
        if not is_allowed(path):
            return {"error": "열 수 없는 위치의 파일이에요."}
        pj = load_project(path) or {}
        for k in ("segments", "bof", "caption"):
            if k in b:
                pj[k] = b[k]
        if b.get("status"):
            pj["status"] = b["status"]
        elif pj.get("status") != "made":
            pj["status"] = "edit"
        if b.get("output"):
            pj.setdefault("outputs", []).append(b["output"])
        save_project(path, pj)
        return {"ok": True, "status": pj["status"]}

    def api_clientlog(self, b):
        log("화면 오류: " + str(b.get("msg", ""))[:2000])
        return {"ok": True}

    def api_probe(self, b):
        path = b.get("path", "")
        if not is_allowed(path):
            return {"error": "열 수 없는 위치의 파일이에요."}
        return {"info": ENGINE.probe(path)}

    def api_proxy(self, b):
        path = b.get("path", "")
        if not is_allowed(path):
            return {"error": "열 수 없는 위치의 파일이에요."}
        return {"job": ENGINE.start_proxy(path)}

    def api_cancel(self, b):
        ENGINE.cancel(b.get("id", ""))
        return {"ok": True}

    def api_settings(self, b):
        keys = ("source_dir", "output_dir", "encoder", "style", "loudnorm") if self.is_local() else ("style", "loudnorm")
        for k in keys:
            if k in b:
                SETTINGS[k] = b[k]
        save_settings(SETTINGS)
        if "encoder" in b:
            ENGINE.encoder = None
            ENGINE.encoder_ready.clear()
            threading.Thread(target=ENGINE.detect_encoder,
                             args=("libx264" if b["encoder"] == "software" else None,),
                             daemon=True).start()
        return {"ok": True}

    def api_create_folder(self, b):
        which = b.get("which")
        path = SETTINGS.get("source_dir" if which == "source" else "output_dir")
        if path:
            os.makedirs(path, exist_ok=True)
        return {"ok": bool(path) and os.path.isdir(path)}

    def api_pick_folder(self, b):
        which = b.get("which", "source")
        key = "source_dir" if which == "source" else "output_dir"
        init = SETTINGS.get(key) or find_drive_root()
        if init and not os.path.isdir(init):
            init = os.path.dirname(init)
        path = run_dialog("folder", init)
        if path and os.path.isdir(path):
            SETTINGS[key] = os.path.normpath(path)
            save_settings(SETTINGS)
            return {"ok": True, "path": SETTINGS[key]}
        return {"ok": False}

    def api_pick_file(self, b):
        init = SETTINGS.get("source_dir") or find_drive_root()
        path = run_dialog("file", init)
        if path and os.path.isfile(path):
            path = os.path.normpath(path)
            ALLOWED_FILES.add(norm(path))
            ex = [x for x in SETTINGS.get("extra_files", []) if norm(x) != norm(path)]
            SETTINGS["extra_files"] = (ex + [path])[-50:]
            save_settings(SETTINGS)
            st = os.stat(path)
            return {"ok": True, "file": {"path": path, "name": os.path.basename(path),
                                         "size": st.st_size, "mtime": st.st_mtime, "folder": ""}}
        return {"ok": False}

    def api_open(self, b):
        path = b.get("path") or SETTINGS.get("output_dir")
        if path and os.path.exists(path):
            open_in_explorer(path)
            return {"ok": True}
        return {"ok": False}

    def api_logo(self, b):
        data = b.get("data")
        if not data:
            try:
                os.remove(LOGO_FILE)
            except OSError:
                pass
            return {"ok": True}
        raw = base64.b64decode(data.split(",", 1)[-1])
        with open(LOGO_FILE, "wb") as f:
            f.write(raw)
        return {"ok": True}

    def api_badge(self, b):
        year = re.sub(r"\D", "", str(b.get("year", "")))[:4]
        if not year:
            return {"error": "연도를 먼저 적어 주세요."}
        f = os.path.join(BADGE_DIR, f"{year}.png")
        if not b.get("data"):
            try:
                os.remove(f)
            except OSError:
                pass
            return {"ok": True}
        with open(f, "wb") as fh:
            fh.write(base64.b64decode(b["data"].split(",", 1)[-1]))
        return {"ok": True}

    def api_export(self, b):
        segs = b.get("segments") or []
        if not segs:
            return {"error": "구간이 하나도 없어요."}
        for s in segs:
            if not is_allowed(s.get("path", "")) or not os.path.isfile(s["path"]):
                return {"error": "원본 파일을 찾을 수 없어요: " + os.path.basename(s.get("path", ""))}
            if float(s["end"]) - float(s["start"]) < 0.2:
                return {"error": "너무 짧은 구간이 있어요."}
        out_dir = SETTINGS.get("output_dir")
        if not out_dir:
            return {"error": "완성본 저장 폴더가 정해지지 않았어요. 설정에서 골라 주세요."}
        os.makedirs(out_dir, exist_ok=True)
        overlay = None
        stamp_ms = int(time.time() * 1000)
        if b.get("overlay"):
            overlay = os.path.join(CACHE, f"overlay_{stamp_ms}.png")
            with open(overlay, "wb") as f:
                f.write(base64.b64decode(b["overlay"].split(",", 1)[-1]))
        seg_overlays = []
        for k, d in enumerate(b.get("seg_overlays") or []):
            if d:
                pth = os.path.join(CACHE, f"overlay_{stamp_ms}_{k}.png")
                with open(pth, "wb") as f:
                    f.write(base64.b64decode(d.split(",", 1)[-1]))
                seg_overlays.append(pth)
            else:
                seg_overlays.append(None)
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M")
        base = safe_name(f"{stamp} {b.get('name') or '쇼츠'}")
        out = unique_path(out_dir, base)
        caption = (b.get("caption") or "").strip() or None
        jid = ENGINE.start_export(segs, out, overlay=overlay,
                                  loudnorm=bool(b.get("loudnorm", SETTINGS.get("loudnorm", True))),
                                  caption=caption, seg_overlays=seg_overlays)
        return {"job": jid, "output": out}

    def api_report(self, b):
        out_dir = SETTINGS.get("output_dir")
        if not out_dir:
            return {"ok": False, "error": "완성본 폴더가 없어요."}
        dst = os.path.join(out_dir, "_오류기록")
        os.makedirs(dst, exist_ok=True)
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        target = os.path.join(dst, f"오류기록_{stamp}.txt")
        with open(target, "w", encoding="utf-8") as f:
            f.write(f"버전 {VERSION} / 인코더 {ENGINE.encoder} / {sys.platform}\n")
            f.write(f"메모: {b.get('note', '')}\n\n")
            f.write(json.dumps(SETTINGS, ensure_ascii=False, indent=2) + "\n\n")
            try:
                with open(LOG_FILE, encoding="utf-8") as lf:
                    f.write(lf.read()[-200_000:])
            except OSError:
                pass
        return {"ok": True, "path": target}

    def api_cleanup(self, b):
        n = 0
        for fn in os.listdir(CACHE):
            try:
                os.remove(os.path.join(CACHE, fn))
                n += 1
            except OSError:
                pass
        return {"ok": True, "removed": n}

    def api_remote_setup(self, b):
        pin = re.sub(r"\D", "", str(b.get("pin", "")))
        keep = not pin and SETTINGS.get("pin")      # '다시 확인' — 지금 PIN 그대로
        if not keep and not 4 <= len(pin) <= 8:
            return {"error": "PIN은 숫자 4~8자리로 정해 주세요."}
        if not tailscale_exe():
            return {"error": "Tailscale이 설치돼 있지 않아요. tailscale.com/download 에서 설치하고 로그인해 주세요."}
        if not keep:
            SETTINGS["pin"] = pin
            SETTINGS["secret"] = secrets.token_hex(24)   # PIN 바꾸면 예전 로그인은 모두 풀림
        SETTINGS["remote"] = True
        save_settings(SETTINGS)
        ok, out = run_tailscale(["funnel", "--bg", str(current_port())])
        m = re.search(r"https://login\.tailscale\.com/\S+", out or "")
        dns = tailscale_dns()
        if dns:
            SETTINGS["funnel_url"] = f"https://{dns}/"
            save_settings(SETTINGS)
        startup_shortcut(True)
        if m:
            return {"ok": False, "approve_url": m.group(0), "url": SETTINGS.get("funnel_url", ""),
                    "message": "Tailscale 쪽에서 한 번 허락이 필요해요. 아래 주소를 열어 'Enable'을 누른 뒤 '다시 확인'을 눌러 주세요."}
        if not funnel_on(fresh=True):
            tail = (out or "").strip()[-300:]
            return {"ok": False, "url": SETTINGS.get("funnel_url", ""),
                    "message": ("인터넷 공개(Funnel)가 아직 안 켜졌어요. '예' 창에서 '예'를 눌렀는지 확인하고 '다시 확인'을 눌러 주세요. "
                                f"계속 안 되면 관리자 명령 프롬프트에서 'tailscale funnel --bg {current_port()}' 를 실행해 주세요."
                                + (f" (기록: {tail})" if tail else ""))}
        return {"ok": True, "url": SETTINGS.get("funnel_url", "")}

    def api_remote_off(self, b):
        run_tailscale(["funnel", "--https=443", "off"])
        SETTINGS["remote"] = False
        save_settings(SETTINGS)
        startup_shortcut(False)
        return {"ok": True}

    def api_logout(self, b):
        return {"ok": True}

    def api_shutdown(self, b):
        threading.Timer(0.5, lambda: os._exit(0)).start()
        return {"ok": True}


# ---------------------------------------------------------------- 정리 작업
def cleanup_cache(max_age_days=3):
    now = time.time()
    for fn in os.listdir(CACHE):
        p = os.path.join(CACHE, fn)
        age = 14 if fn.startswith(("proxy_", "thumb_")) else max_age_days
        try:
            if now - os.path.getmtime(p) > age * 86400 or fn.endswith(".part.mp4"):
                os.remove(p)
        except OSError:
            pass


def watchdog(idle_minutes=60):
    while True:
        time.sleep(30)
        if SETTINGS.get("remote"):
            continue   # 원격 접속을 켜 두면 폰에서 언제든 들어올 수 있게 계속 켜 둠
        if time.time() - LAST_BEAT[0] > idle_minutes * 60 and not ENGINE.busy():
            # 노트북이 절전에서 막 깨어난 경우 창이 다시 신호를 보낼 시간을 줌
            time.sleep(120)
            if time.time() - LAST_BEAT[0] > idle_minutes * 60 and not ENGINE.busy():
                log("창이 오래 닫혀 있어 프로그램을 종료해요.")
                os._exit(0)


def vtuple(v):
    try:
        return tuple(int(x) for x in str(v).strip().split("."))
    except Exception:
        return (0,)


def update_watch(every_minutes=30):
    """원격 접속을 켜 둔 서버는 계속 켜져 있으니, 켜진 채로도 새 버전을 받게."""
    import urllib.request
    while True:
        time.sleep(every_minutes * 60)
        if not SETTINGS.get("remote"):
            continue
        try:
            cfg = json.load(open(os.path.join(APP_DIR, "update.json"), encoding="utf-8"))
            url = cfg.get("url")
            if not url:
                continue
            with urllib.request.urlopen(url + ("&" if "?" in url else "?") + "t=" + str(int(time.time())), timeout=10) as r:
                rel = json.loads(r.read().decode("utf-8"))
            if vtuple(rel.get("version")) <= vtuple(VERSION):
                continue
            while ENGINE.busy():
                time.sleep(60)
            log(f"새 버전 {rel.get('version')} 발견 — 다시 시작해서 업데이트해요")
            py = sys.executable
            subprocess.Popen([py, os.path.join(ROOT_DIR, "launch.py"), "--no-browser", "--after-exit"],
                             cwd=ROOT_DIR, creationflags=0x08000008 if IS_WIN else 0,
                             close_fds=True)
            time.sleep(1)
            os._exit(0)
        except Exception as e:
            log(f"업데이트 확인 실패: {e}")


CLAUDE_MD = """# 공연 쇼츠 편집기 — Claude Code 작업 폴더

이 폴더는 고모의 '공연 쇼츠 편집기'를 Claude Code로 다루는 곳이다. (프로그램이 자동으로 만들고, 켤 때마다 갱신한다)

## 하는 일
구글 드라이브 `공연소스`에 들어온 공연 영상마다 편집기가 **자동 초안**(하이라이트 구간)을 만들어 둔다.
Claude 는 그 초안에 **작품 정보 · 구간 자막 · 캡션**을 채우고 '확인 필요'로 표시한다.
영상 만들기(내보내기)는 고모가 앱에서 확인하고 직접 누른다.

## 도구
모든 작업은 `./sm` 명령으로만 한다. (`./sm help` 로 전체 사용법)
- `./sm list` · `./sm show <번호>` · `./sm frames <번호> --overview`
- `./sm set-info` · `./sm set-hook` · `./sm set-badge` · `./sm set-seg` · `./sm add-seg` · `./sm del-seg` · `./sm set-caption` · `./sm ready`

자막·캡션을 쓰는 법은 `best-of-fest-shorts` 스킬에 있다. 작업 전에 반드시 그 스킬을 따른다.

## 지킬 것
- 편집기 프로그램 파일(`{root}`)은 **절대 고치지 않는다.** 프로그램 수정·업데이트는 규효가 GitHub로 따로 한다.
- 장면 사진(`frames/`)을 실제로 열어 보고 자막을 쓴다.
- 모르는 사실(시리즈 번호, 수상 연도, 단체 정보)은 지어내지 않고 비워 둔 뒤 보고한다.
- 편집기가 꺼져 있다는 오류가 나면, 고모에게 바탕화면 '공연 쇼츠 편집기'를 켜 달라고 말한다.
- 답은 한국어로, 짧게.
"""


def ensure_claude_workspace():
    """Claude Code 가 쓸 작업 폴더(사용법·스킬·권한·sm 명령)를 만들어 둠."""
    try:
        ws = os.path.join(os.path.expanduser("~"), "ShortsMaker-Claude") if IS_WIN else os.path.join(DATA, "claude_ws")
        os.makedirs(os.path.join(ws, ".claude", "skills", "best-of-fest-shorts"), exist_ok=True)
        os.makedirs(os.path.join(ws, "frames"), exist_ok=True)
        py = os.path.join(ROOT_DIR, "runtime", "python", "python.exe") if IS_WIN else sys.executable
        tool = os.path.join(APP_DIR, "claude_tool.py")
        fwd = lambda p: p.replace("\\", "/")
        with open(os.path.join(ws, "CLAUDE.md"), "w", encoding="utf-8") as f:
            f.write(CLAUDE_MD.replace("{root}", ROOT_DIR))
        shutil.copyfile(os.path.join(APP_DIR, "claude", "SKILL.md"),
                        os.path.join(ws, ".claude", "skills", "best-of-fest-shorts", "SKILL.md"))
        env_line = f'export SHORTSMAKER_DATA="{fwd(DATA)}"\n' if os.environ.get("SHORTSMAKER_DATA") else ""
        with open(os.path.join(ws, "sm"), "w", encoding="utf-8", newline="\n") as f:
            f.write("#!/usr/bin/env bash\nexport PYTHONIOENCODING=utf-8\n" + env_line +
                    f'"{fwd(py)}" "{fwd(tool)}" "$@"\n')
        try:
            os.chmod(os.path.join(ws, "sm"), 0o755)
        except OSError:
            pass
        with open(os.path.join(ws, "sm.cmd"), "w", encoding="utf-8", newline="\r\n") as f:
            f.write(f'@echo off\nset PYTHONIOENCODING=utf-8\n"{py}" "{tool}" %*\n')
        settings_p = os.path.join(ws, ".claude", "settings.json")
        st = {}
        try:
            st = json.load(open(settings_p, encoding="utf-8"))
        except (OSError, ValueError):
            pass
        allow = st.setdefault("permissions", {}).setdefault("allow", [])
        for rule in ("Bash(./sm:*)", "Bash(sm:*)", "Bash(./sm.cmd:*)", "WebSearch", "WebFetch", "Read(./frames/**)"):
            if rule not in allow:
                allow.append(rule)
        with open(settings_p, "w", encoding="utf-8") as f:
            json.dump(st, f, ensure_ascii=False, indent=2)
        log(f"Claude 작업 폴더 준비: {ws}")
        return ws
    except Exception as e:
        log(f"Claude 작업 폴더 준비 실패: {e}")
        return None


def make_auto_draft(path, proxy=None):
    """새 영상에 자동 초안(하이라이트 구간 + Best of Fest 배치)을 만들어 둠."""
    try:
        info, hl = ENGINE.highlights(path, proxy)
        if not hl:
            return
        land = info["width"] >= info["height"]
        framing = {"mode": "fit", "zoom": 1, "px": 0.5, "py": 0.379} if land else {"mode": "fill", "zoom": 1, "px": 0.5, "py": 0.5}
        segs = [{"id": secrets.token_hex(4), "path": path, "name": os.path.basename(path), "start": a, "end": b,
                 "framing": dict(framing), "hook": "", "badge": i == 0} for i, (a, b) in enumerate(hl)]
        save_project(path, {"status": "auto", "segments": segs, "bof": default_bof(path)})
        log(f"자동 초안: {os.path.basename(path)} {hl}")
    except Exception as e:
        log(f"자동 초안 실패 ({os.path.basename(path)}): {e}")
        # 같은 영상에서 계속 실패하지 않게 빈 초안 기록
        save_project(path, {"status": "", "segments": [], "bof": default_bof(path), "error": str(e)[:300]})


def prewarm_previews(every_minutes=5):
    """원격 접속 중이면, 소스 폴더의 새 영상은 폰에서 바로 볼 수 있게 가벼운 미리보기를 미리 만들어 둠."""
    time.sleep(20)
    while True:
        try:
            if SETTINGS.get("auto_draft", True) and not ENGINE.busy():
                r = list_files()
                for f in (r.get("files") or [])[:15]:
                    if ENGINE.busy():
                        break
                    try:
                        out = ENGINE.proxy_path(f["path"])
                    except OSError:
                        continue
                    if not os.path.exists(out):
                        jid = ENGINE.start_proxy(f["path"])
                        while ENGINE.job_status(jid)["state"] == "running":
                            time.sleep(5)
                    else:
                        os.utime(out, None)
                    if not load_project(f["path"]) and not ENGINE.busy():
                        make_auto_draft(f["path"], out if os.path.exists(out) else None)
        except Exception as e:
            log(f"미리보기 미리 만들기 실패: {e}")
        time.sleep(every_minutes * 60)


def port_free(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        if not IS_WIN:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def main():
    no_browser = "--no-browser" in sys.argv
    port = int(os.environ.get("SHORTSMAKER_PORT", "8765"))
    while not port_free(port) and port < 8790:
        port += 1
    with open(PORT_FILE, "w") as f:
        f.write(str(port))
    log(f"시작 v{VERSION} port={port} data={DATA}")
    cleanup_cache()
    threading.Thread(target=ENGINE.detect_encoder,
                     args=("libx264" if SETTINGS.get("encoder") == "software" else None,),
                     daemon=True).start()
    threading.Thread(target=ensure_claude_workspace, daemon=True).start()
    threading.Thread(target=watchdog, daemon=True).start()
    threading.Thread(target=update_watch, daemon=True).start()
    threading.Thread(target=prewarm_previews, daemon=True).start()
    ThreadingHTTPServer.allow_reuse_address = not IS_WIN  # 윈도우에선 같은 포트 중복 사용 방지
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    srv.daemon_threads = True
    url = f"http://127.0.0.1:{port}/"
    if not no_browser:
        threading.Timer(0.6, lambda: open_browser(url)).start()
    srv.serve_forever()


def open_browser(url):
    """크롬이 있으면 앱 창처럼(주소창 없이) 열고, 없으면 기본 브라우저."""
    if IS_WIN:
        cands = []
        for env in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
            b = os.environ.get(env)
            if b:
                cands.append(os.path.join(b, "Google", "Chrome", "Application", "chrome.exe"))
                cands.append(os.path.join(b, "Microsoft", "Edge", "Application", "msedge.exe"))
        for c in cands:
            if os.path.exists(c):
                try:
                    subprocess.Popen([c, f"--app={url}", "--start-maximized"])
                    return
                except Exception:
                    pass
    webbrowser.open(url)


if __name__ == "__main__":
    main()
