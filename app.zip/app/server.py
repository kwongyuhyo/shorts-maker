"""공연 쇼츠 편집기 — 로컬 서버 (파이썬 기본 라이브러리만 사용)."""
import base64
import datetime
import json
import mimetypes
import os
import re
import shutil
import socket
import string
import subprocess
import sys
import threading
import time
import traceback
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

APP_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(APP_DIR)
WEB_DIR = os.path.join(APP_DIR, "web")
sys.path.insert(0, APP_DIR)
from engine import Engine  # noqa: E402

IS_WIN = os.name == "nt"
VERSION = open(os.path.join(APP_DIR, "VERSION"), encoding="utf-8").read().strip()


def data_dir():
    d = os.environ.get("SHORTSMAKER_DATA")
    if not d:
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        d = os.path.join(base, "ShortsMaker", "data")
    os.makedirs(d, exist_ok=True)
    return d


DATA = data_dir()
CACHE = os.path.join(DATA, "cache")
LOGS = os.path.join(DATA, "logs")
os.makedirs(CACHE, exist_ok=True)
os.makedirs(LOGS, exist_ok=True)
LOG_FILE = os.path.join(LOGS, "app.log")
SETTINGS_FILE = os.path.join(DATA, "settings.json")
LOGO_FILE = os.path.join(DATA, "logo.png")
PORT_FILE = os.path.join(DATA, "port.txt")
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".mkv", ".avi", ".mts", ".m2ts", ".webm", ".3gp", ".wmv"}

_log_lock = threading.Lock()


def log(msg):
    line = f"[{datetime.datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n"
    with _log_lock:
        try:
            if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 2_000_000:
                os.replace(LOG_FILE, LOG_FILE + ".1")
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(line)
        except OSError:
            pass
    if sys.stdout:
        try:
            sys.stdout.write(line)
        except Exception:
            pass


# ---------------------------------------------------------------- 설정
DEFAULTS = {
    "source_dir": "",
    "output_dir": "",
    "encoder": "auto",
    "style": {},          # 글자·로고 스타일 (화면에서 관리)
    "loudnorm": True,
    "extra_files": [],    # '다른 곳에서 열기'로 연 파일 (다시 켜도 열 수 있게)
}


def find_drive_root():
    """구글 드라이브 데스크톱의 '내 드라이브' 위치 찾기."""
    names = ["내 드라이브", "My Drive"]
    cands = []
    if IS_WIN:
        for L in string.ascii_uppercase:
            cands.append(f"{L}:\\")
    home = os.path.expanduser("~")
    cands += [os.path.join(home, "Google Drive"), os.path.join(home, "My Drive"), home]
    for c in cands:
        for n in names:
            p = os.path.join(c, n)
            try:
                if os.path.isdir(p):
                    return p
            except OSError:
                pass
    return ""


def fill_defaults(s):
    if not s.get("source_dir") or not s.get("output_dir"):
        root = find_drive_root()
        if root:
            if not s.get("source_dir"):
                s["source_dir"] = os.path.join(root, "공연소스")
            if not s.get("output_dir"):
                s["output_dir"] = os.path.join(root, "공연완성본")
    return s


def load_settings():
    s = dict(DEFAULTS)
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            s.update(json.load(f))
    except (OSError, ValueError):
        pass
    return fill_defaults(s)


def path_state(p):
    """ok / drive_missing(드라이브가 아직 안 켜짐) / folder_missing / unset"""
    if not p:
        return "unset"
    if os.path.isdir(p):
        return "ok"
    drive = os.path.splitdrive(p)[0]
    if IS_WIN and drive and not os.path.exists(drive + "\\"):
        return "drive_missing"
    return "folder_missing"


def save_settings(s):
    tmp = SETTINGS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(s, f, ensure_ascii=False, indent=2)
    os.replace(tmp, SETTINGS_FILE)


SETTINGS = load_settings()
ENGINE = Engine(os.path.join(ROOT_DIR, "runtime", "ffmpeg"), CACHE, log)
ALLOWED_FILES = set(os.path.normcase(os.path.abspath(p)) for p in SETTINGS.get("extra_files", []))
THUMB_LOCK = threading.Lock()
LAST_BEAT = [time.time()]


def norm(p):
    return os.path.normcase(os.path.abspath(p))


def is_allowed(path):
    p = norm(path)
    roots = [SETTINGS.get("source_dir"), SETTINGS.get("output_dir"), CACHE]
    for r in roots:
        if r and (p == norm(r) or p.startswith(norm(r) + os.sep)):
            return True
    return p in ALLOWED_FILES


def safe_name(name):
    name = re.sub(r'[\\/:*?"<>|\r\n\t]', " ", name).strip().strip(".")
    name = re.sub(r"\s+", " ", name)
    return name[:80] or "쇼츠"


def unique_path(folder, base, ext=".mp4"):
    p = os.path.join(folder, base + ext)
    k = 2
    while os.path.exists(p):
        p = os.path.join(folder, f"{base} ({k}){ext}")
        k += 1
    return p


def run_dialog(kind, initial=""):
    """폴더/파일 고르기 창 (별도 프로세스로 띄움)."""
    py = sys.executable
    if IS_WIN and py.lower().endswith("python.exe"):
        w = py[:-10] + "pythonw.exe"
        if os.path.exists(w):
            py = w
    try:
        r = subprocess.run([py, os.path.join(APP_DIR, "dialogs.py"), kind, initial or ""],
                           capture_output=True, timeout=600,
                           creationflags=0x08000000 if IS_WIN else 0)
        out = r.stdout.decode("utf-8", "replace").strip()
        return out or None
    except Exception as e:
        log(f"대화상자 실패: {e}")
        return None


def open_in_explorer(path):
    try:
        if IS_WIN:
            if os.path.isfile(path):
                subprocess.Popen(["explorer", "/select,", path])
            else:
                os.startfile(path)  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception as e:
        log(f"폴더 열기 실패: {e}")


def list_files():
    src = SETTINGS.get("source_dir")
    if not src or not os.path.isdir(src):
        return {"ok": False, "reason": "no_folder", "folder": src, "files": []}
    files = []
    base_depth = src.rstrip(os.sep).count(os.sep)
    for dirpath, dirnames, filenames in os.walk(src):
        if dirpath.count(os.sep) - base_depth >= 2:
            dirnames[:] = []
        dirnames[:] = [d for d in dirnames if not d.startswith((".", "_"))]
        for fn in filenames:
            if os.path.splitext(fn)[1].lower() in VIDEO_EXT and not fn.startswith("."):
                p = os.path.join(dirpath, fn)
                try:
                    st = os.stat(p)
                except OSError:
                    continue
                rel = os.path.relpath(dirpath, src)
                files.append({"path": p, "name": fn, "folder": "" if rel == "." else rel,
                              "size": st.st_size, "mtime": st.st_mtime})
    files.sort(key=lambda f: f["mtime"], reverse=True)
    return {"ok": True, "folder": src, "files": files[:500]}


# ---------------------------------------------------------------- HTTP
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):  # 조용히
        pass

    # ---- 응답 도우미
    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0:
            return {}
        return json.loads(self.rfile.read(n).decode("utf-8"))

    def send_file(self, path, mime=None, cache=False):
        try:
            size = os.path.getsize(path)
        except OSError:
            return self.send_error(404)
        mime = mime or mimetypes.guess_type(path)[0] or "application/octet-stream"
        rng = self.headers.get("Range")
        start, end = 0, size - 1
        code = 200
        if rng:
            m = re.match(r"bytes=(\d*)-(\d*)", rng)
            if m:
                if m.group(1):
                    start = int(m.group(1))
                    if m.group(2):
                        end = min(int(m.group(2)), size - 1)
                elif m.group(2):
                    start = max(0, size - int(m.group(2)))
                if start > end or start >= size:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{size}")
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                code = 206
        length = end - start + 1
        self.send_response(code)
        self.send_header("Content-Type", mime)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(length))
        if code == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.send_header("Cache-Control", "max-age=3600" if cache else "no-store")
        self.end_headers()
        try:
            with open(path, "rb") as f:
                f.seek(start)
                left = length
                while left > 0:
                    chunk = f.read(min(1 << 20, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
        except (ConnectionError, BrokenPipeError, OSError):
            pass

    # ---- 라우팅
    def do_GET(self):
        try:
            u = urllib.parse.urlparse(self.path)
            q = urllib.parse.parse_qs(u.query)
            p = u.path
            if p == "/" or p == "/index.html":
                return self.send_file(os.path.join(WEB_DIR, "index.html"), "text/html; charset=utf-8")
            if p.startswith("/static/"):
                rel = os.path.normpath(urllib.parse.unquote(p[len("/static/"):]))
                if rel.startswith("..") or os.path.isabs(rel):
                    return self.send_error(403)
                f = os.path.join(WEB_DIR, rel)
                mime = None
                if f.endswith(".js"):
                    mime = "text/javascript; charset=utf-8"
                elif f.endswith(".css"):
                    mime = "text/css; charset=utf-8"
                elif f.endswith(".woff2"):
                    mime = "font/woff2"
                return self.send_file(f, mime, cache=f.endswith(".woff2"))
            if p == "/media":
                path = q.get("path", [""])[0]
                if not path or not is_allowed(path) or not os.path.isfile(path):
                    return self.send_error(403)
                ext = os.path.splitext(path)[1].lower()
                mime = "video/webm" if ext in (".webm", ".mkv") else "video/mp4"
                return self.send_file(path, mime)
            if p == "/api/logo":
                if os.path.exists(LOGO_FILE):
                    return self.send_file(LOGO_FILE, "image/png")
                return self.send_error(404)
            if p == "/api/thumb":
                path = q.get("path", [""])[0]
                if not path or not is_allowed(path) or not os.path.isfile(path):
                    return self.send_error(403)
                t = self.thumb(path)
                if not t:
                    return self.send_error(404)
                return self.send_file(t, "image/jpeg", cache=True)
            if p == "/api/state":
                return self.send_json(self.state())
            if p == "/api/files":
                return self.send_json(list_files())
            LAST_BEAT[0] = time.time()
            if p == "/api/job":
                st = ENGINE.job_status(q.get("id", [""])[0])
                return self.send_json(st or {"state": "missing"})
            return self.send_error(404)
        except Exception:
            log("GET 오류:\n" + traceback.format_exc())
            try:
                self.send_json({"error": "서버 오류"}, 500)
            except Exception:
                pass

    def do_POST(self):
        try:
            p = urllib.parse.urlparse(self.path).path
            body = self.read_json()
            LAST_BEAT[0] = time.time()
            fn = getattr(self, "api_" + p.replace("/api/", "").replace("/", "_"), None)
            if not fn:
                return self.send_error(404)
            return self.send_json(fn(body))
        except Exception as e:
            log("POST 오류:\n" + traceback.format_exc())
            try:
                self.send_json({"error": str(e)}, 500)
            except Exception:
                pass

    # ---- API
    def state(self):
        fill_defaults(SETTINGS)
        drive = find_drive_root()
        return {
            "source_state": path_state(SETTINGS.get("source_dir")),
            "version": VERSION,
            "settings": SETTINGS,
            "drive_root": drive,
            "source_ok": bool(SETTINGS.get("source_dir")) and os.path.isdir(SETTINGS["source_dir"]),
            "output_ok": bool(SETTINGS.get("output_dir")),
            "encoder": ENGINE.encoder,
            "has_logo": os.path.exists(LOGO_FILE),
            "platform": sys.platform,
        }

    def thumb(self, path):
        import hashlib
        st = os.stat(path)
        key = hashlib.md5(f"{path}|{st.st_size}|{int(st.st_mtime)}".encode("utf-8")).hexdigest()[:16]
        out = os.path.join(CACHE, f"thumb_{key}.jpg")
        if os.path.exists(out):
            return out
        with THUMB_LOCK:   # 한 번에 하나씩 (옛날 노트북 + 드라이브 스트리밍 배려)
            if os.path.exists(out):
                return out
            for ss in ("5", "0"):
                try:
                    r = subprocess.run([ENGINE.ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-ss", ss,
                                        "-i", path, "-frames:v", "1", "-vf", "scale=192:-2", "-q:v", "6", out],
                                       capture_output=True, timeout=45,
                                       creationflags=0x08000000 if IS_WIN else 0)
                    if r.returncode == 0 and os.path.exists(out) and os.path.getsize(out) > 0:
                        return out
                except Exception as e:
                    log(f"썸네일 실패: {e}")
                    break
        return None

    def api_heartbeat(self, b):
        return {"ok": True}

    def api_clientlog(self, b):
        log("화면 오류: " + str(b.get("msg", ""))[:2000])
        return {"ok": True}

    def api_probe(self, b):
        path = b.get("path", "")
        if not is_allowed(path):
            return {"error": "열 수 없는 위치의 파일이에요."}
        return {"info": ENGINE.probe(path)}

    def api_proxy(self, b):
        path = b.get("path", "")
        if not is_allowed(path):
            return {"error": "열 수 없는 위치의 파일이에요."}
        return {"job": ENGINE.start_proxy(path)}

    def api_cancel(self, b):
        ENGINE.cancel(b.get("id", ""))
        return {"ok": True}

    def api_settings(self, b):
        for k in ("source_dir", "output_dir", "encoder", "style", "loudnorm"):
            if k in b:
                SETTINGS[k] = b[k]
        save_settings(SETTINGS)
        if "encoder" in b:
            ENGINE.encoder = None
            ENGINE.encoder_ready.clear()
            threading.Thread(target=ENGINE.detect_encoder,
                             args=("libx264" if b["encoder"] == "software" else None,),
                             daemon=True).start()
        return {"ok": True, "settings": SETTINGS}

    def api_create_folder(self, b):
        which = b.get("which")
        path = SETTINGS.get("source_dir" if which == "source" else "output_dir")
        if path:
            os.makedirs(path, exist_ok=True)
        return {"ok": bool(path) and os.path.isdir(path)}

    def api_pick_folder(self, b):
        which = b.get("which", "source")
        key = "source_dir" if which == "source" else "output_dir"
        init = SETTINGS.get(key) or find_drive_root()
        if init and not os.path.isdir(init):
            init = os.path.dirname(init)
        path = run_dialog("folder", init)
        if path and os.path.isdir(path):
            SETTINGS[key] = os.path.normpath(path)
            save_settings(SETTINGS)
            return {"ok": True, "path": SETTINGS[key]}
        return {"ok": False}

    def api_pick_file(self, b):
        init = SETTINGS.get("source_dir") or find_drive_root()
        path = run_dialog("file", init)
        if path and os.path.isfile(path):
            path = os.path.normpath(path)
            ALLOWED_FILES.add(norm(path))
            ex = [x for x in SETTINGS.get("extra_files", []) if norm(x) != norm(path)]
            SETTINGS["extra_files"] = (ex + [path])[-50:]
            save_settings(SETTINGS)
            st = os.stat(path)
            return {"ok": True, "file": {"path": path, "name": os.path.basename(path),
                                         "size": st.st_size, "mtime": st.st_mtime, "folder": ""}}
        return {"ok": False}

    def api_open(self, b):
        path = b.get("path") or SETTINGS.get("output_dir")
        if path and os.path.exists(path):
            open_in_explorer(path)
            return {"ok": True}
        return {"ok": False}

    def api_logo(self, b):
        data = b.get("data")
        if not data:
            try:
                os.remove(LOGO_FILE)
            except OSError:
                pass
            return {"ok": True}
        raw = base64.b64decode(data.split(",", 1)[-1])
        with open(LOGO_FILE, "wb") as f:
            f.write(raw)
        return {"ok": True}

    def api_export(self, b):
        segs = b.get("segments") or []
        if not segs:
            return {"error": "구간이 하나도 없어요."}
        for s in segs:
            if not is_allowed(s.get("path", "")) or not os.path.isfile(s["path"]):
                return {"error": "원본 파일을 찾을 수 없어요: " + os.path.basename(s.get("path", ""))}
            if float(s["end"]) - float(s["start"]) < 0.2:
                return {"error": "너무 짧은 구간이 있어요."}
        out_dir = SETTINGS.get("output_dir")
        if not out_dir:
            return {"error": "완성본 저장 폴더가 정해지지 않았어요. 설정에서 골라 주세요."}
        os.makedirs(out_dir, exist_ok=True)
        overlay = None
        if b.get("overlay"):
            overlay = os.path.join(CACHE, f"overlay_{int(time.time() * 1000)}.png")
            with open(overlay, "wb") as f:
                f.write(base64.b64decode(b["overlay"].split(",", 1)[-1]))
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M")
        base = safe_name(f"{stamp} {b.get('name') or '쇼츠'}")
        out = unique_path(out_dir, base)
        caption = (b.get("caption") or "").strip() or None
        jid = ENGINE.start_export(segs, out, overlay=overlay,
                                  loudnorm=bool(b.get("loudnorm", SETTINGS.get("loudnorm", True))),
                                  caption=caption)
        return {"job": jid, "output": out}

    def api_report(self, b):
        out_dir = SETTINGS.get("output_dir")
        if not out_dir:
            return {"ok": False, "error": "완성본 폴더가 없어요."}
        dst = os.path.join(out_dir, "_오류기록")
        os.makedirs(dst, exist_ok=True)
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        target = os.path.join(dst, f"오류기록_{stamp}.txt")
        with open(target, "w", encoding="utf-8") as f:
            f.write(f"버전 {VERSION} / 인코더 {ENGINE.encoder} / {sys.platform}\n")
            f.write(f"메모: {b.get('note', '')}\n\n")
            f.write(json.dumps(SETTINGS, ensure_ascii=False, indent=2) + "\n\n")
            try:
                with open(LOG_FILE, encoding="utf-8") as lf:
                    f.write(lf.read()[-200_000:])
            except OSError:
                pass
        return {"ok": True, "path": target}

    def api_cleanup(self, b):
        n = 0
        for fn in os.listdir(CACHE):
            try:
                os.remove(os.path.join(CACHE, fn))
                n += 1
            except OSError:
                pass
        return {"ok": True, "removed": n}

    def api_shutdown(self, b):
        threading.Timer(0.5, lambda: os._exit(0)).start()
        return {"ok": True}


# ---------------------------------------------------------------- 정리 작업
def cleanup_cache(max_age_days=3):
    now = time.time()
    for fn in os.listdir(CACHE):
        p = os.path.join(CACHE, fn)
        try:
            if now - os.path.getmtime(p) > max_age_days * 86400 or fn.endswith(".part.mp4"):
                os.remove(p)
        except OSError:
            pass


def watchdog(idle_minutes=60):
    while True:
        time.sleep(30)
        if time.time() - LAST_BEAT[0] > idle_minutes * 60 and not ENGINE.busy():
            # 노트북이 절전에서 막 깨어난 경우 창이 다시 신호를 보낼 시간을 줌
            time.sleep(120)
            if time.time() - LAST_BEAT[0] > idle_minutes * 60 and not ENGINE.busy():
                log("창이 오래 닫혀 있어 프로그램을 종료해요.")
                os._exit(0)


def port_free(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        if not IS_WIN:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def main():
    no_browser = "--no-browser" in sys.argv
    port = int(os.environ.get("SHORTSMAKER_PORT", "8765"))
    while not port_free(port) and port < 8790:
        port += 1
    with open(PORT_FILE, "w") as f:
        f.write(str(port))
    log(f"시작 v{VERSION} port={port} data={DATA}")
    cleanup_cache()
    threading.Thread(target=ENGINE.detect_encoder,
                     args=("libx264" if SETTINGS.get("encoder") == "software" else None,),
                     daemon=True).start()
    threading.Thread(target=watchdog, daemon=True).start()
    ThreadingHTTPServer.allow_reuse_address = not IS_WIN  # 윈도우에선 같은 포트 중복 사용 방지
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    srv.daemon_threads = True
    url = f"http://127.0.0.1:{port}/"
    if not no_browser:
        threading.Timer(0.6, lambda: open_browser(url)).start()
    srv.serve_forever()


def open_browser(url):
    """크롬이 있으면 앱 창처럼(주소창 없이) 열고, 없으면 기본 브라우저."""
    if IS_WIN:
        cands = []
        for env in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
            b = os.environ.get(env)
            if b:
                cands.append(os.path.join(b, "Google", "Chrome", "Application", "chrome.exe"))
                cands.append(os.path.join(b, "Microsoft", "Edge", "Application", "msedge.exe"))
        for c in cands:
            if os.path.exists(c):
                try:
                    subprocess.Popen([c, f"--app={url}", "--start-maximized"])
                    return
                except Exception:
                    pass
    webbrowser.open(url)


if __name__ == "__main__":
    main()
