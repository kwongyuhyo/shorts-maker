"""ffmpeg 처리 담당: 영상 정보 읽기, 미리보기 사본, 최종 쇼츠 만들기."""
import json
import math
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid

OUT_W, OUT_H = 1080, 1920
FPS = 30

IS_WIN = os.name == "nt"
NO_WINDOW = 0x08000000 if IS_WIN else 0  # CREATE_NO_WINDOW


def _even(v):
    v = int(round(v))
    return v if v % 2 == 0 else v + 1


class Engine:
    def __init__(self, ffmpeg_dir, cache_dir, log):
        exe = ".exe" if IS_WIN else ""
        if ffmpeg_dir and os.path.exists(os.path.join(ffmpeg_dir, "ffmpeg" + exe)):
            self.ffmpeg = os.path.join(ffmpeg_dir, "ffmpeg" + exe)
            self.ffprobe = os.path.join(ffmpeg_dir, "ffprobe" + exe)
        else:
            self.ffmpeg, self.ffprobe = "ffmpeg", "ffprobe"
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        self.log = log
        self.encoder = None          # 확인된 인코더 이름
        self.encoder_ready = threading.Event()
        self.jobs = {}
        self.jobs_lock = threading.Lock()
        self._probe_cache = {}

    # ------------------------------------------------------------ 공통 실행
    def _run(self, args, timeout=None):
        return subprocess.run(args, capture_output=True, timeout=timeout,
                              creationflags=NO_WINDOW)

    # ------------------------------------------------------------ 인코더 확인
    ENCODERS = {
        "h264_qsv": ["-c:v", "h264_qsv", "-preset", "medium", "-profile:v", "high",
                     "-b:v", "10M", "-maxrate", "14M", "-bufsize", "20M"],
        "h264_mf": ["-c:v", "h264_mf", "-hw_encoding", "1", "-b:v", "10M"],
        "libx264": ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                    "-maxrate", "14M", "-bufsize", "28M", "-profile:v", "high"],
    }
    PIXFMT = {"h264_qsv": "nv12", "h264_mf": "nv12", "libx264": "yuv420p"}

    def detect_encoder(self, prefer=None):
        order = ["h264_qsv", "h264_mf", "libx264"]
        if prefer == "libx264":
            order = ["libx264"]
        for enc in order:
            args = [self.ffmpeg, "-hide_banner", "-loglevel", "error",
                    "-f", "lavfi", "-i", f"color=c=gray:s={OUT_W}x{OUT_H}:r={FPS}:d=0.5",
                    "-vf", f"format={self.PIXFMT[enc]}"] + self.ENCODERS[enc] + ["-f", "null", "-"]
            try:
                r = self._run(args, timeout=40)
                if r.returncode == 0:
                    self.encoder = enc
                    self.log(f"인코더 사용: {enc}")
                    break
                self.log(f"인코더 {enc} 사용 불가: {r.stderr.decode('utf-8', 'replace')[-300:]}")
            except Exception as e:  # noqa
                self.log(f"인코더 {enc} 확인 실패: {e}")
        if not self.encoder:
            self.encoder = "libx264"
        self.encoder_ready.set()

    # ------------------------------------------------------------ 영상 정보
    def probe(self, path):
        st = os.stat(path)
        key = (path, st.st_size, int(st.st_mtime))
        if key in self._probe_cache:
            return self._probe_cache[key]
        r = self._run([self.ffprobe, "-v", "error", "-print_format", "json",
                       "-show_format", "-show_streams", path], timeout=120)
        if r.returncode != 0:
            raise RuntimeError("영상 정보를 읽지 못했어요: " + r.stderr.decode("utf-8", "replace")[-200:])
        d = json.loads(r.stdout.decode("utf-8", "replace"))
        v = next((s for s in d.get("streams", []) if s.get("codec_type") == "video"
                  and not (s.get("disposition") or {}).get("attached_pic")), None)
        a = next((s for s in d.get("streams", []) if s.get("codec_type") == "audio"), None)
        if not v:
            raise RuntimeError("영상(화면) 트랙이 없는 파일이에요.")
        w, h = int(v.get("width", 0)), int(v.get("height", 0))
        rot = 0
        for sd in v.get("side_data_list", []) or []:
            if "rotation" in sd:
                rot = int(float(sd["rotation"]))
        if not rot and "rotate" in (v.get("tags") or {}):
            rot = int(float(v["tags"]["rotate"]))
        if abs(rot) % 180 == 90:
            w, h = h, w
        dur = float(d.get("format", {}).get("duration") or v.get("duration") or 0)
        fps = 0.0
        fr = v.get("avg_frame_rate") or v.get("r_frame_rate") or "0/1"
        try:
            n, m = fr.split("/")
            fps = float(n) / float(m) if float(m) else 0.0
        except Exception:
            pass
        info = {"path": path, "width": w, "height": h, "duration": dur, "fps": round(fps, 3),
                "vcodec": v.get("codec_name"), "has_audio": a is not None,
                "size": st.st_size, "name": os.path.basename(path)}
        self._probe_cache[key] = info
        return info

    # ------------------------------------------------------------ 작업 관리
    def _new_job(self, kind):
        jid = uuid.uuid4().hex[:10]
        job = {"id": jid, "kind": kind, "state": "running", "progress": 0.0,
               "message": "준비 중", "output": None, "error": None, "started": time.time(),
               "proc": None, "cancel": False}
        with self.jobs_lock:
            self.jobs[jid] = job
        return job

    def job_status(self, jid):
        job = self.jobs.get(jid)
        if not job:
            return None
        return {k: v for k, v in job.items() if k != "proc"}

    def cancel(self, jid):
        job = self.jobs.get(jid)
        if job:
            job["cancel"] = True
            p = job.get("proc")
            if p and p.poll() is None:
                try:
                    p.kill()
                except Exception:
                    pass

    def busy(self):
        return any(j["state"] == "running" for j in self.jobs.values())

    def _run_progress(self, job, args, total, base=0.0, span=1.0):
        """ffmpeg 를 실행하며 진행률 갱신. 성공 여부와 에러 로그 반환."""
        args = args[:1] + ["-hide_banner", "-nostats", "-progress", "pipe:1"] + args[1:]
        self.log("실행: " + " ".join(f'"{a}"' if " " in a else a for a in args))
        errlog = []
        p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             creationflags=NO_WINDOW)
        job["proc"] = p

        def read_err():
            for line in iter(p.stderr.readline, b""):
                errlog.append(line.decode("utf-8", "replace"))
                if len(errlog) > 200:
                    del errlog[:100]
        t = threading.Thread(target=read_err, daemon=True)
        t.start()
        for raw in iter(p.stdout.readline, b""):
            line = raw.decode("utf-8", "replace").strip()
            if line.startswith("out_time_us=") or line.startswith("out_time_ms="):
                try:
                    us = int(line.split("=", 1)[1])
                    if total > 0:
                        job["progress"] = min(0.999, base + span * (us / 1e6) / total)
                except ValueError:
                    pass
        p.wait()
        t.join(timeout=2)
        job["proc"] = None
        return p.returncode == 0, "".join(errlog[-40:])

    # ------------------------------------------------------------ 미리보기 사본
    def proxy_path(self, src):
        import hashlib
        st = os.stat(src)
        key = hashlib.md5(f"{src}|{st.st_size}|{int(st.st_mtime)}".encode("utf-8")).hexdigest()[:16]
        return os.path.join(self.cache_dir, f"proxy_{key}.mp4")

    def start_proxy(self, src):
        out = self.proxy_path(src)
        job = self._new_job("proxy")
        if os.path.exists(out) and os.path.getsize(out) > 1000:
            job.update(state="done", progress=1.0, output=out, message="완료")
            return job["id"]

        def work():
            try:
                info = self.probe(src)
                job["message"] = "미리보기용 사본 만드는 중"
                tmp = out + ".part.mp4"
                base = [self.ffmpeg, "-y"]
                tail = ["-i", src, "-map", "0:v:0", "-map", "0:a:0?",
                        "-vf", "scale=-2:540,fps=30,format=yuv420p",
                        "-c:v", "libx264", "-preset", "ultrafast", "-crf", "30", "-g", "15",
                        "-c:a", "aac", "-b:a", "96k", "-ac", "2", "-movflags", "+faststart", tmp]
                ok, err = self._run_progress(job, base + ["-hwaccel", "auto"] + tail, info["duration"])
                if not ok and not job["cancel"]:
                    ok, err = self._run_progress(job, base + tail, info["duration"])
                if job["cancel"]:
                    raise RuntimeError("취소됐어요.")
                if not ok:
                    raise RuntimeError(err[-600:])
                os.replace(tmp, out)
                job.update(state="done", progress=1.0, output=out, message="완료")
            except Exception as e:
                self.log(f"미리보기 사본 실패: {e}")
                job.update(state="error", error=str(e), message="실패")
        threading.Thread(target=work, daemon=True).start()
        return job["id"]

    # ------------------------------------------------------------ 화면 배치 계산
    @staticmethod
    def framing_filter(W, H, fr, tag=""):
        """[in] 라벨로 들어온 영상을 1080x1920 으로 배치하는 필터 문자열(끝 라벨 없음)."""
        mode = fr.get("mode", "fill")
        z = max(1.0, min(4.0, float(fr.get("zoom", 1.0))))
        px = max(0.0, min(1.0, float(fr.get("px", 0.5))))
        py = max(0.0, min(1.0, float(fr.get("py", 0.5))))
        if mode == "fill":
            s = max(OUT_W / W, OUT_H / H) * z
            sw, sh = max(OUT_W, _even(W * s)), max(OUT_H, _even(H * s))
            x, y = int(round((sw - OUT_W) * px)), int(round((sh - OUT_H) * py))
            return f"scale={sw}:{sh}:flags=bicubic,crop={OUT_W}:{OUT_H}:{x}:{y}"
        # fit: 흐린 배경 + 전체 화면
        s0 = max(OUT_W / W, OUT_H / H)
        bw, bh = max(270, _even(W * s0 / 4)), max(480, _even(H * s0 / 4))
        s = min(OUT_W / W, OUT_H / H) * z
        fw, fh = _even(W * s), _even(H * s)
        x, y = int(round((OUT_W - fw) * px)), int(round((OUT_H - fh) * py))
        bg = (f"scale={bw}:{bh}:flags=fast_bilinear,crop=270:480,boxblur=10:2,"
              f"scale={OUT_W}:{OUT_H}:flags=bilinear,lutyuv=y=val*0.82")
        t = tag
        return (f"split[_b{t}][_f{t}];[_b{t}]{bg}[_bg{t}];[_f{t}]scale={fw}:{fh}:flags=bicubic[_fg{t}];"
                f"[_bg{t}][_fg{t}]overlay={x}:{y}")

    def build_graph(self, segs, infos, overlay, loudnorm):
        """segs: [{path,start,end,framing}] -> (input args, filter_complex, total)"""
        inputs, parts, labels = [], [], []
        total = 0.0
        for i, sg in enumerate(segs):
            info = infos[i]
            st, en = float(sg["start"]), float(sg["end"])
            dur = max(0.1, en - st)
            total += dur
            inputs += ["-ss", f"{st:.3f}", "-t", f"{dur:.3f}", "-i", sg["path"]]
            frm = self.framing_filter(info["width"], info["height"], sg.get("framing") or {}, tag=str(i))
            parts.append(f"[{i}:v:0]setpts=PTS-STARTPTS,trim=duration={dur:.3f},{frm},"
                         f"fps={FPS},setsar=1,format=yuv420p[v{i}]")
            fd = min(0.04, dur / 4)
            if info["has_audio"]:
                parts.append(f"[{i}:a:0]asetpts=PTS-STARTPTS,aresample=48000,"
                             f"aformat=sample_fmts=fltp:channel_layouts=stereo,"
                             f"atrim=duration={dur:.3f},apad=whole_dur={dur:.3f},"
                             f"afade=t=in:d={fd:.3f},afade=t=out:st={dur - fd:.3f}:d={fd:.3f}[a{i}]")
            else:
                parts.append(f"anullsrc=r=48000:cl=stereo,atrim=duration={dur:.3f}[a{i}]")
            labels.append(f"[v{i}][a{i}]")
        n = len(segs)
        parts.append("".join(labels) + f"concat=n={n}:v=1:a=1[vc][ac0]")
        vlast = "vc"
        if overlay:
            inputs += ["-i", overlay]
            parts.append(f"[{n}:v]format=rgba[ov];[vc][ov]overlay=0:0:format=auto:eof_action=repeat[vo]")
            vlast = "vo"
        a = "[ac0]"
        chain = []
        if loudnorm:
            chain.append("loudnorm=I=-14:TP=-1.5:LRA=11")
            chain.append("aresample=48000")
        fo = min(0.6, total / 4)
        chain.append(f"afade=t=out:st={max(0, total - fo):.3f}:d={fo:.3f}")
        parts.append(a + ",".join(chain) + "[ao]")
        return inputs, ";".join(parts), total, vlast

    # ------------------------------------------------------------ 최종 만들기
    def start_export(self, segs, out_path, overlay=None, loudnorm=True, caption=None):
        job = self._new_job("export")

        def work():
            try:
                self.encoder_ready.wait(timeout=60)
                job["message"] = "영상 정보 확인 중"
                infos = [self.probe(s["path"]) for s in segs]
                inputs, graph, total, vlast = self.build_graph(segs, infos, overlay, loudnorm)
                os.makedirs(os.path.dirname(out_path), exist_ok=True)
                # 임시 파일은 노트북 안(캐시)에서 만들고, 다 되면 드라이브 폴더로 옮김
                tmp = os.path.join(self.cache_dir, f"export_{job['id']}.part.mp4")
                attempts = []
                enc = self.encoder or "libx264"
                attempts.append((True, enc))
                attempts.append((False, enc))
                if enc != "libx264":
                    attempts.append((False, "libx264"))
                last_err = ""
                for hw, e in attempts:
                    if job["cancel"]:
                        break
                    job["message"] = "쇼츠 만드는 중" + ("" if e == "libx264" else " (빠른 모드)")
                    job["progress"] = 0.0
                    g = graph + f";[{vlast}]format={self.PIXFMT[e]}[vfinal]"
                    pre = []
                    if hw:
                        # 각 입력 앞에 하드웨어 디코딩 옵션
                        new_inputs = []
                        k = 0
                        while k < len(inputs):
                            if inputs[k] == "-ss":
                                new_inputs += ["-hwaccel", "auto"]
                            new_inputs.append(inputs[k])
                            k += 1
                        ins = new_inputs
                    else:
                        ins = inputs
                    args = [self.ffmpeg, "-y"] + pre + ins + [
                        "-filter_complex", g, "-map", "[vfinal]", "-map", "[ao]",
                        "-r", str(FPS), "-g", str(FPS * 2)] + self.ENCODERS[e] + [
                        "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2",
                        "-movflags", "+faststart", "-f", "mp4", tmp]
                    ok, err = self._run_progress(job, args, total)
                    if ok and os.path.exists(tmp) and os.path.getsize(tmp) > 1000:
                        job["message"] = "완성본 폴더로 옮기는 중"
                        shutil.move(tmp, out_path)
                        if overlay:
                            try:
                                os.remove(overlay)
                            except OSError:
                                pass
                        if caption:
                            with open(os.path.splitext(out_path)[0] + ".txt", "w", encoding="utf-8") as f:
                                f.write(caption)
                        job.update(state="done", progress=1.0, output=out_path, message="완료")
                        self.log(f"완성: {out_path} ({e}, hw={hw})")
                        return
                    last_err = err
                    self.log(f"시도 실패 ({e}, hw={hw}):\n{err}")
                    try:
                        os.remove(tmp)
                    except OSError:
                        pass
                if job["cancel"]:
                    raise RuntimeError("취소됐어요.")
                raise RuntimeError(last_err[-800:] or "알 수 없는 오류")
            except Exception as ex:
                self.log(f"만들기 실패: {ex}")
                job.update(state="error", error=str(ex), message="실패")
        threading.Thread(target=work, daemon=True).start()
        return job["id"]
