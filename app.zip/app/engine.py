"""ffmpeg 처리 담당: 영상 정보 읽기, 미리보기 사본, 최종 쇼츠 만들기."""
import json
import math
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid

OUT_W, OUT_H = 1080, 1920
FPS = 30

IS_WIN = os.name == "nt"
NO_WINDOW = 0x08000000 if IS_WIN else 0  # CREATE_NO_WINDOW


def _even(v):
    v = int(round(v))
    return v if v % 2 == 0 else v + 1


class Engine:
    def __init__(self, ffmpeg_dir, cache_dir, log):
        exe = ".exe" if IS_WIN else ""
        if ffmpeg_dir and os.path.exists(os.path.join(ffmpeg_dir, "ffmpeg" + exe)):
            self.ffmpeg = os.path.join(ffmpeg_dir, "ffmpeg" + exe)
            self.ffprobe = os.path.join(ffmpeg_dir, "ffprobe" + exe)
        else:
            self.ffmpeg, self.ffprobe = "ffmpeg", "ffprobe"
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        self.log = log
        self.encoder = None          # 확인된 인코더 이름
        self.encoder_ready = threading.Event()
        self.jobs = {}
        self.jobs_lock = threading.Lock()
        self._probe_cache = {}

    # ------------------------------------------------------------ 공통 실행
    def _run(self, args, timeout=None):
        return subprocess.run(args, capture_output=True, timeout=timeout,
                              creationflags=NO_WINDOW)

    # ------------------------------------------------------------ 인코더 확인
    ENCODERS = {
        "h264_qsv": ["-c:v", "h264_qsv", "-preset", "medium", "-profile:v", "high",
                     "-b:v", "10M", "-maxrate", "14M", "-bufsize", "20M"],
        "h264_mf": ["-c:v", "h264_mf", "-hw_encoding", "1", "-b:v", "10M"],
        "libx264": ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                    "-maxrate", "14M", "-bufsize", "28M", "-profile:v", "high"],
    }
    PIXFMT = {"h264_qsv": "nv12", "h264_mf": "nv12", "libx264": "yuv420p"}

    def highlights(self, src, analysis_src=None, scene_sec=4.0, scenes=7):
        info = self.probe(src)
        a = analysis_src or src
        loud = _analyze_loudness(self, a)
        cuts = _analyze_cuts(self, a)
        return info, pick_scenes(loud, cuts, info["duration"], scene_sec=scene_sec, n=scenes)

    def detect_encoder(self, prefer=None):
        order = ["h264_qsv", "h264_mf", "libx264"]
        if prefer == "libx264":
            order = ["libx264"]
        for enc in order:
            args = [self.ffmpeg, "-hide_banner", "-loglevel", "error",
                    "-f", "lavfi", "-i", f"color=c=gray:s={OUT_W}x{OUT_H}:r={FPS}:d=0.5",
                    "-vf", f"format={self.PIXFMT[enc]}"] + self.ENCODERS[enc] + ["-f", "null", "-"]
            try:
                r = self._run(args, timeout=40)
                if r.returncode == 0:
                    self.encoder = enc
                    self.log(f"인코더 사용: {enc}")
                    break
                self.log(f"인코더 {enc} 사용 불가: {r.stderr.decode('utf-8', 'replace')[-300:]}")
            except Exception as e:  # noqa
                self.log(f"인코더 {enc} 확인 실패: {e}")
        if not self.encoder:
            self.encoder = "libx264"
        self.encoder_ready.set()

    # ------------------------------------------------------------ 영상 정보
    def probe(self, path):
        st = os.stat(path)
        key = (path, st.st_size, int(st.st_mtime))
        if key in self._probe_cache:
            return self._probe_cache[key]
        r = self._run([self.ffprobe, "-v", "error", "-print_format", "json",
                       "-show_format", "-show_streams", path], timeout=120)
        if r.returncode != 0:
            raise RuntimeError("영상 정보를 읽지 못했어요: " + r.stderr.decode("utf-8", "replace")[-200:])
        d = json.loads(r.stdout.decode("utf-8", "replace"))
        v = next((s for s in d.get("streams", []) if s.get("codec_type") == "video"
                  and not (s.get("disposition") or {}).get("attached_pic")), None)
        a = next((s for s in d.get("streams", []) if s.get("codec_type") == "audio"), None)
        if not v:
            raise RuntimeError("영상(화면) 트랙이 없는 파일이에요.")
        w, h = int(v.get("width", 0)), int(v.get("height", 0))
        rot = 0
        for sd in v.get("side_data_list", []) or []:
            if "rotation" in sd:
                rot = int(float(sd["rotation"]))
        if not rot and "rotate" in (v.get("tags") or {}):
            rot = int(float(v["tags"]["rotate"]))
        if abs(rot) % 180 == 90:
            w, h = h, w
        dur = float(d.get("format", {}).get("duration") or v.get("duration") or 0)
        fps = 0.0
        fr = v.get("avg_frame_rate") or v.get("r_frame_rate") or "0/1"
        try:
            n, m = fr.split("/")
            fps = float(n) / float(m) if float(m) else 0.0
        except Exception:
            pass
        info = {"path": path, "width": w, "height": h, "duration": dur, "fps": round(fps, 3),
                "vcodec": v.get("codec_name"), "has_audio": a is not None,
                "size": st.st_size, "name": os.path.basename(path)}
        self._probe_cache[key] = info
        return info

    # ------------------------------------------------------------ 작업 관리
    def _new_job(self, kind):
        jid = uuid.uuid4().hex[:10]
        job = {"id": jid, "kind": kind, "state": "running", "progress": 0.0,
               "message": "준비 중", "output": None, "error": None, "started": time.time(),
               "proc": None, "cancel": False}
        with self.jobs_lock:
            self.jobs[jid] = job
        return job

    def job_status(self, jid):
        job = self.jobs.get(jid)
        if not job:
            return None
        return {k: v for k, v in job.items() if k != "proc"}

    def cancel(self, jid):
        job = self.jobs.get(jid)
        if job:
            job["cancel"] = True
            p = job.get("proc")
            if p and p.poll() is None:
                try:
                    p.kill()
                except Exception:
                    pass

    def busy(self):
        return any(j["state"] == "running" for j in self.jobs.values())

    def _run_progress(self, job, args, total, base=0.0, span=1.0):
        """ffmpeg 를 실행하며 진행률 갱신. 성공 여부와 에러 로그 반환."""
        args = args[:1] + ["-hide_banner", "-nostats", "-progress", "pipe:1"] + args[1:]
        self.log("실행: " + " ".join(f'"{a}"' if " " in a else a for a in args))
        errlog = []
        p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             creationflags=NO_WINDOW)
        job["proc"] = p

        def read_err():
            for line in iter(p.stderr.readline, b""):
                errlog.append(line.decode("utf-8", "replace"))
                if len(errlog) > 200:
                    del errlog[:100]
        t = threading.Thread(target=read_err, daemon=True)
        t.start()
        for raw in iter(p.stdout.readline, b""):
            line = raw.decode("utf-8", "replace").strip()
            if line.startswith("out_time_us=") or line.startswith("out_time_ms="):
                try:
                    us = int(line.split("=", 1)[1])
                    if total > 0:
                        job["progress"] = min(0.999, base + span * (us / 1e6) / total)
                except ValueError:
                    pass
        p.wait()
        t.join(timeout=2)
        job["proc"] = None
        return p.returncode == 0, "".join(errlog[-40:])

    # ------------------------------------------------------------ 미리보기 사본
    def proxy_path(self, src):
        import hashlib
        st = os.stat(src)
        key = hashlib.md5(f"{src}|{st.st_size}|{int(st.st_mtime)}".encode("utf-8")).hexdigest()[:16]
        return os.path.join(self.cache_dir, f"proxy_{key}.mp4")

    def start_proxy(self, src):
        out = self.proxy_path(src)
        job = self._new_job("proxy")
        if os.path.exists(out) and os.path.getsize(out) > 1000:
            job.update(state="done", progress=1.0, output=out, message="완료")
            return job["id"]

        def work():
            try:
                info = self.probe(src)
                job["message"] = "미리보기용 사본 만드는 중"
                tmp = out + ".part.mp4"
                base = [self.ffmpeg, "-y"]
                tail = ["-i", src, "-map", "0:v:0", "-map", "0:a:0?",
                        "-vf", "scale=-2:540,fps=30,format=yuv420p",
                        "-c:v", "libx264", "-preset", "ultrafast", "-crf", "30", "-g", "15",
                        "-c:a", "aac", "-b:a", "96k", "-ac", "2", "-movflags", "+faststart", tmp]
                ok, err = self._run_progress(job, base + ["-hwaccel", "auto"] + tail, info["duration"])
                if not ok and not job["cancel"]:
                    ok, err = self._run_progress(job, base + tail, info["duration"])
                if job["cancel"]:
                    raise RuntimeError("취소됐어요.")
                if not ok:
                    raise RuntimeError(err[-600:])
                os.replace(tmp, out)
                job.update(state="done", progress=1.0, output=out, message="완료")
            except Exception as e:
                self.log(f"미리보기 사본 실패: {e}")
                job.update(state="error", error=str(e), message="실패")
        threading.Thread(target=work, daemon=True).start()
        return job["id"]

    # ------------------------------------------------------------ 화면 배치 계산
    @staticmethod
    def framing_filter(W, H, fr, tag=""):
        """[in] 라벨로 들어온 영상을 1080x1920 으로 배치하는 필터 문자열(끝 라벨 없음)."""
        mode = fr.get("mode", "fill")
        z = max(1.0, min(4.0, float(fr.get("zoom", 1.0))))
        px = max(0.0, min(1.0, float(fr.get("px", 0.5))))
        py = max(0.0, min(1.0, float(fr.get("py", 0.5))))
        if mode == "fill":
            s = max(OUT_W / W, OUT_H / H) * z
            sw, sh = max(OUT_W, _even(W * s)), max(OUT_H, _even(H * s))
            x, y = int(round((sw - OUT_W) * px)), int(round((sh - OUT_H) * py))
            return f"format=yuv420p,scale={sw}:{sh}:flags=bicubic,crop={OUT_W}:{OUT_H}:{x}:{y}"
        # fit: 흐린 배경 + 전체 화면
        s0 = max(OUT_W / W, OUT_H / H)
        bw, bh = max(270, _even(W * s0 / 4)), max(480, _even(H * s0 / 4))
        s = min(OUT_W / W, OUT_H / H) * z
        fw, fh = _even(W * s), _even(H * s)
        x, y = int(round((OUT_W - fw) * px)), int(round((OUT_H - fh) * py))
        bg = (f"scale={bw}:{bh}:flags=fast_bilinear,crop=270:480,boxblur=10:2,"
              f"scale={OUT_W}:{OUT_H}:flags=bilinear,lutyuv=y=val*0.82")
        t = tag
        # 하드웨어 디코딩(-hwaccel auto) 프레임을 그대로 줄이면 흐린 배경 오른쪽이 초록색이 됨 → 먼저 yuv420p 로 바꿈
        return (f"format=yuv420p,split[_b{t}][_f{t}];[_b{t}]{bg}[_bg{t}];[_f{t}]scale={fw}:{fh}:flags=bicubic[_fg{t}];"
                f"[_bg{t}][_fg{t}]overlay={x}:{y}")

    def build_graph(self, segs, infos, overlay, loudnorm, seg_overlays=None, badge_fade=None, ending=None):
        """segs: [{path,start,end,framing}] -> (input args, filter_complex, total)
        seg_overlays: 구간마다 덮을 PNG 경로 목록 (구간별 자막·배지)
        badge_fade: {"png": 배지만 그린 PNG, "sec": 1.0} — 첫 구간에서 배지가 서서히 나타남
        ending: {"png": 엔딩 화면 PNG, "sec": 3.0} — 마지막에 붙는 엔딩 (소리는 마지막 구간 뒤 원음이 이어짐)"""
        inputs, parts, labels = [], [], []
        seg_overlays = seg_overlays or [None] * len(segs)
        ov_inputs = []
        extra = []          # 반복 이미지·엔딩 소리 입력 (구간 PNG 다음, 전체 overlay 앞)
        n = len(segs)
        n_ov = sum(1 for k in range(n) if k < len(seg_overlays) and seg_overlays[k])
        n_extra = 0
        total = 0.0
        for i, sg in enumerate(segs):
            info = infos[i]
            st, en = float(sg["start"]), float(sg["end"])
            dur = max(0.1, en - st)
            total += dur
            inputs += ["-ss", f"{st:.3f}", "-t", f"{dur:.3f}", "-i", sg["path"]]
            frm = self.framing_filter(info["width"], info["height"], sg.get("framing") or {}, tag=str(i))
            sov = seg_overlays[i] if i < len(seg_overlays) else None
            parts.append(f"[{i}:v:0]setpts=PTS-STARTPTS,trim=duration={dur:.3f},{frm}[fr{i}]")
            cur = f"fr{i}"
            if sov:
                ov_idx = n + len(ov_inputs)
                ov_inputs.append(sov)
                parts.append(f"[{ov_idx}:v]format=rgba[so{i}];[{cur}][so{i}]overlay=0:0:format=auto:eof_action=repeat[os{i}]")
                cur = f"os{i}"
            if i == 0 and badge_fade and badge_fade.get("png"):
                bi = n + n_ov + n_extra
                n_extra += 1
                extra += ["-loop", "1", "-framerate", str(FPS), "-t", f"{dur:.3f}", "-i", badge_fade["png"]]
                fs = max(0.1, min(float(badge_fade.get("sec", 1.0)), dur))
                parts.append(f"[{bi}:v]format=rgba,fade=t=in:st=0:d={fs:.2f}:alpha=1[bf{i}];"
                             f"[{cur}][bf{i}]overlay=0:0:format=auto:shortest=1[ob{i}]")
                cur = f"ob{i}"
            tail = ""
            if ending and ending.get("png") and i == n - 1:
                fo = min(0.35, dur / 4)
                tail = f",fade=t=out:st={dur - fo:.3f}:d={fo:.3f}"
            parts.append(f"[{cur}]fps={FPS},setsar=1,format=yuv420p{tail}[v{i}]")
            fd = min(0.04, dur / 4)
            if info["has_audio"]:
                parts.append(f"[{i}:a:0]asetpts=PTS-STARTPTS,aresample=48000,"
                             f"aformat=sample_fmts=fltp:channel_layouts=stereo,"
                             f"atrim=duration={dur:.3f},apad=whole_dur={dur:.3f},"
                             f"afade=t=in:d={fd:.3f},afade=t=out:st={dur - fd:.3f}:d={fd:.3f}[a{i}]")
            else:
                parts.append(f"anullsrc=r=48000:cl=stereo,atrim=duration={dur:.3f}[a{i}]")
            labels.append(f"[v{i}][a{i}]")
        for p in ov_inputs:
            inputs += ["-i", p]
        n_seg = n
        if ending and ending.get("png") and n:
            # 엔딩 화면: 짧게 어두워졌다가 나타남. 소리는 마지막 구간 바로 뒤 원음이 이어지다 끝에서 사라짐
            esec = max(1.0, float(ending.get("sec", 3.0)))
            ei = n + n_ov + n_extra
            n_extra += 1
            extra += ["-loop", "1", "-framerate", str(FPS), "-t", f"{esec:.3f}", "-i", ending["png"]]
            parts.append(f"[{ei}:v]format=rgba,fps={FPS},scale={OUT_W}:{OUT_H},setsar=1,format=yuv420p,"
                         f"trim=duration={esec:.3f},fade=t=in:st=0:d=0.4[v{n}]")
            last, linfo = segs[-1], infos[-1]
            lend = float(last["end"])
            if linfo["has_audio"] and lend + 0.5 < float(linfo.get("duration") or 0):
                ai = n + n_ov + n_extra
                n_extra += 1
                extra += ["-ss", f"{lend:.3f}", "-t", f"{esec:.3f}", "-i", last["path"]]
                parts.append(f"[{ai}:a:0]asetpts=PTS-STARTPTS,aresample=48000,"
                             f"aformat=sample_fmts=fltp:channel_layouts=stereo,"
                             f"atrim=duration={esec:.3f},apad=whole_dur={esec:.3f}[a{n}]")
            else:
                parts.append(f"anullsrc=r=48000:cl=stereo,atrim=duration={esec:.3f}[a{n}]")
            labels.append(f"[v{n}][a{n}]")
            total += esec
            n_seg = n + 1
        inputs += extra
        parts.append("".join(labels) + f"concat=n={n_seg}:v=1:a=1[vc][ac0]")
        vlast = "vc"
        if overlay:
            inputs += ["-i", overlay]
            parts.append(f"[{n + n_ov + n_extra}:v]format=rgba[ov];[vc][ov]overlay=0:0:format=auto:eof_action=repeat[vo]")
            vlast = "vo"
        a = "[ac0]"
        chain = []
        if loudnorm:
            chain.append("loudnorm=I=-14:TP=-1.5:LRA=11")
            chain.append("aresample=48000")
        fo = min(1.5, total / 4) if (ending and ending.get("png")) else min(0.6, total / 4)
        chain.append(f"afade=t=out:st={max(0, total - fo):.3f}:d={fo:.3f}")
        parts.append(a + ",".join(chain) + "[ao]")
        return inputs, ";".join(parts), total, vlast

    # ------------------------------------------------------------ 최종 만들기
    def _venc_args(self, e, kbps):
        """kbps 를 주면 그 비트레이트로 (Best of Fest 완성본: 약 1.9Mbps), 없으면 기본 화질."""
        if not kbps:
            return self.ENCODERS[e]
        k = int(kbps)
        if e == "libx264":
            return ["-c:v", "libx264", "-preset", "medium", "-b:v", f"{k}k", "-maxrate", f"{int(k * 1.5)}k",
                    "-bufsize", f"{k * 2}k", "-profile:v", "high"]
        args = list(self.ENCODERS[e])
        for flag, val in (("-b:v", f"{k}k"), ("-maxrate", f"{int(k * 1.5)}k"), ("-bufsize", f"{k * 2}k")):
            if flag in args:
                args[args.index(flag) + 1] = val
        return args

    def start_export(self, segs, out_path, overlay=None, loudnorm=True, caption=None, seg_overlays=None,
                     badge_fade=None, ending=None, video_kbps=None, audio_kbps=None):
        job = self._new_job("export")

        def work():
            nonlocal out_path
            try:
                self.encoder_ready.wait(timeout=60)
                job["message"] = "영상 정보 확인 중"
                infos = [self.probe(s["path"]) for s in segs]
                inputs, graph, total, vlast = self.build_graph(segs, infos, overlay, loudnorm, seg_overlays,
                                                               badge_fade=badge_fade, ending=ending)
                os.makedirs(os.path.dirname(out_path), exist_ok=True)
                # 임시 파일은 노트북 안(캐시)에서 만들고, 다 되면 드라이브 폴더로 옮김
                tmp = os.path.join(self.cache_dir, f"export_{job['id']}.part.mp4")
                attempts = []
                enc = self.encoder or "libx264"
                attempts.append((True, enc))
                attempts.append((False, enc))
                if enc != "libx264":
                    attempts.append((False, "libx264"))
                last_err = ""
                for hw, e in attempts:
                    if job["cancel"]:
                        break
                    job["message"] = "쇼츠 만드는 중" + ("" if e == "libx264" else " (빠른 모드)")
                    job["progress"] = 0.0
                    g = graph + f";[{vlast}]format={self.PIXFMT[e]}[vfinal]"
                    pre = []
                    if hw:
                        # 각 입력 앞에 하드웨어 디코딩 옵션
                        new_inputs = []
                        k = 0
                        while k < len(inputs):
                            if inputs[k] == "-ss":
                                new_inputs += ["-hwaccel", "auto"]
                            new_inputs.append(inputs[k])
                            k += 1
                        ins = new_inputs
                    else:
                        ins = inputs
                    args = [self.ffmpeg, "-y"] + pre + ins + [
                        "-filter_complex", g, "-map", "[vfinal]", "-map", "[ao]",
                        "-r", str(FPS), "-g", str(FPS * 2)] + self._venc_args(e, video_kbps) + [
                        "-c:a", "aac", "-b:a", f"{int(audio_kbps or 192)}k", "-ar", "48000", "-ac", "2",
                        "-movflags", "+faststart", "-f", "mp4", tmp]
                    ok, err = self._run_progress(job, args, total)
                    if ok and os.path.exists(tmp) and os.path.getsize(tmp) > 1000:
                        job["message"] = "완성본 폴더로 옮기는 중"
                        # 만드는 사이에 같은 이름이 생겼으면 덮어쓰지 않고 번호를 붙임 ({slug}_reel → _reel2, _reel3 …)
                        root, ext = os.path.splitext(out_path)
                        m = re.match(r"^(.*_reel)(\d*)$", root)
                        k = 2
                        while os.path.exists(out_path) or (caption and os.path.exists(os.path.splitext(out_path)[0] + ".txt")):
                            out_path = f"{m.group(1)}{k}{ext}" if m else f"{root}_{k}{ext}"
                            k += 1
                        shutil.move(tmp, out_path)
                        tmp_pngs = [overlay] + list(seg_overlays or []) + [(badge_fade or {}).get("png"), (ending or {}).get("png")]
                        for o in tmp_pngs:
                            if o:
                                try:
                                    os.remove(o)
                                except OSError:
                                    pass
                        if caption:
                            with open(os.path.splitext(out_path)[0] + ".txt", "w", encoding="utf-8") as f:
                                f.write(caption)
                        job.update(state="done", progress=1.0, output=out_path, message="완료")
                        self.log(f"완성: {out_path} ({e}, hw={hw})")
                        return
                    last_err = err
                    self.log(f"시도 실패 ({e}, hw={hw}):\n{err}")
                    try:
                        os.remove(tmp)
                    except OSError:
                        pass
                if job["cancel"]:
                    raise RuntimeError("취소됐어요.")
                raise RuntimeError(last_err[-800:] or "알 수 없는 오류")
            except Exception as ex:
                self.log(f"만들기 실패: {ex}")
                job.update(state="error", error=str(ex), message="실패")
        threading.Thread(target=work, daemon=True).start()
        return job["id"]


# ================================================================ 자동 초안: 하이라이트 고르기
def _analyze_loudness(eng, src):
    """0.5초마다 소리 크기(dB)."""
    r = subprocess.run([eng.ffmpeg, "-hide_banner", "-nostats", "-i", src, "-vn", "-af",
                        "aresample=8000,asetnsamples=4000,astats=metadata=1:reset=1,"
                        "ametadata=print:key=lavfi.astats.Overall.RMS_level:file=-",
                        "-f", "null", "-"], capture_output=True, timeout=1800, creationflags=NO_WINDOW)
    vals, t = [], None
    for line in r.stdout.decode("utf-8", "replace").splitlines():
        if "pts_time:" in line:
            try:
                t = float(line.split("pts_time:")[1].split()[0])
            except ValueError:
                t = None
        elif "RMS_level=" in line and t is not None:
            v = line.split("=", 1)[1].strip()
            try:
                db = float(v)
            except ValueError:
                db = -90.0
            if db != db or db < -90:   # nan / -inf
                db = -90.0
            vals.append((t, db))
    return vals


def _analyze_cuts(eng, src):
    """장면이 바뀌는 시간들."""
    r = subprocess.run([eng.ffmpeg, "-hide_banner", "-nostats", "-i", src, "-an", "-vf",
                        "fps=5,scale=160:-2,select='gt(scene,0.32)',metadata=print:file=-",
                        "-f", "null", "-"], capture_output=True, timeout=1800, creationflags=NO_WINDOW)
    cuts = []
    for line in r.stdout.decode("utf-8", "replace").splitlines():
        if "pts_time:" in line:
            try:
                cuts.append(float(line.split("pts_time:")[1].split()[0]))
            except ValueError:
                pass
    return cuts


def pick_highlights(loud, cuts, duration, target_total=30.0, n=3):
    """소리가 크게 올라오는 구간(박수·클라이맥스)을 영상 앞·중간·뒤에서 하나씩 골라 장면 전환에 맞춰 자름."""
    if duration <= 0:
        return []
    if duration <= target_total + 8:
        a = min(1.0, duration * 0.05)
        return [(round(a, 2), round(min(duration - 0.2, a + target_total), 2))]
    seg = target_total / n
    step = 0.5
    db = {round(t * 2) / 2: v for t, v in loud}
    def mean(a, b):
        xs = [db.get(round(k * 2) / 2, -90.0) for k in frange(a, b, step)]
        return sum(xs) / max(1, len(xs))
    lo, hi = duration * 0.03, duration * 0.97 - seg
    best = []
    parts = [(lo + (hi - lo) * i / n, lo + (hi - lo) * (i + 1) / n) for i in range(n)]
    for (pa, pb) in parts:
        cand, score = None, -1e9
        for st in frange(pa, max(pa + step, pb), 1.0):
            sc = mean(st, st + seg) + 0.35 * (mean(st + seg * 0.4, st + seg) - mean(max(0, st - 3), st))
            if sc > score:
                cand, score = st, sc
        if cand is not None:
            best.append(cand)
    out = []
    for st in best:
        en = st + seg
        # 가까운 장면 전환에 맞추기 (±1.5초)
        near = [c for c in cuts if abs(c - st) <= 1.5]
        if near:
            st = min(near, key=lambda c: abs(c - st)) + 0.05
        near = [c for c in cuts if abs(c - en) <= 1.5 and c - st >= 6]
        if near:
            en = min(near, key=lambda c: abs(c - en)) - 0.05
        en = min(en, duration - 0.2)
        if out and st < out[-1][1]:
            st = out[-1][1] + 0.1
        if en - st >= 4:
            out.append((round(st, 2), round(en, 2)))
    return out


def pick_scenes(loud, cuts, duration, scene_sec=4.0, n=7):
    """Best of Fest 릴스: 약 4초짜리 장면 n개 (자막 1개 = 장면 1개).
    영상을 n칸으로 나눠 칸마다 소리가 살아 있는 4초를 고르고, 가까운 장면 전환에 시작을 맞춤.
    영상이 짧으면 장면 수를 줄이거나 앞에서부터 이어 붙임."""
    if duration <= 0:
        return []
    usable = duration * 0.94
    if usable < scene_sec:
        a = min(0.5, duration * 0.03)
        return [(round(a, 2), round(max(a + 0.5, duration - 0.2), 2))]
    n = max(1, min(n, int(usable // scene_sec)))
    lo, hi = duration * 0.03, duration * 0.97 - scene_sec
    if hi - lo < scene_sec * n * 1.25:
        # 여유가 거의 없음: 고르게 나눠 이어 붙임
        gap = max(0.0, (hi + scene_sec - lo - scene_sec * n) / max(1, n))
        out, t = [], lo
        for _ in range(n):
            out.append((round(t, 2), round(min(duration - 0.2, t + scene_sec), 2)))
            t += scene_sec + gap
        return out
    step = 0.5
    db = {round(t * 2) / 2: v for t, v in loud}

    def mean(a, b):
        xs = [db.get(round(k * 2) / 2, -90.0) for k in frange(a, b, step)]
        return sum(xs) / max(1, len(xs))
    width = (hi - lo) / n
    out = []
    for i in range(n):
        pa, pb = lo + width * i, lo + width * (i + 1)
        if out:
            pa = max(pa, out[-1][1] + 0.2)
        best, score = None, -1e9
        for st in frange(pa, max(pa + step, pb - scene_sec * 0.25), step):
            sc = mean(st, st + scene_sec) + 0.3 * (mean(st + scene_sec * 0.4, st + scene_sec) - mean(max(0, st - 2), st))
            if sc > score:
                best, score = st, sc
        if best is None:
            continue
        st = best
        near = [c for c in cuts if abs(c - st) <= 1.0 and (not out or c > out[-1][1] + 0.1)]
        if near:
            st = min(near, key=lambda c: abs(c - st)) + 0.05
        en = min(st + scene_sec, duration - 0.2)
        if en - st >= scene_sec * 0.75:
            out.append((round(st, 2), round(en, 2)))
    return out


def frange(a, b, step):
    x = a
    while x < b:
        yield x
        x += step
