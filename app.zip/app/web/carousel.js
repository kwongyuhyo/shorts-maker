/* 카드뉴스(캐러셀) 6장 — Best of Fest 양식 (STYLE.md 4장 · templates/best_of_fest.json 의 carousel) */
"use strict";
const CW = 1080, CH = 1350;
const SERIF_KR = `NotoSerifKR, "Noto Serif KR", Batang, "바탕", AppleMyungjo, serif`;
const C = {
  work: null, name: "", car: null, photos: [], videos: [], outputs: [],
  sel: 0, imgs: {}, dirty: true, saveT: null, pick: "photos", vid: 0, thumbT: 0, busy: false,
};
function TC() { return (S.state && S.state.template && S.state.template.carousel) || {}; }
const ROLE_NAMES = { cover: "표지", story: "이야기", highlight: "볼거리", acclaim: "성과", jury_note: "심사위원장 노트", info_cta: "공연 정보" };
function roleName(r) { return (TC().role_names || {})[r] || ROLE_NAMES[r] || r; }

// 카드마다 적는 칸 (라벨, 키, 줄 수, 안내)
const CARD_FIELDS = {
  cover: [
    ["작은 금색 줄", "award", 1, ""],
    ["영문 제목", "title", 2, "길면 줄을 나눠 적어도 돼요 (최대 2줄)"],
    ["한글 부제", "subtitle", 1, ""],
    ["대표 문구", "tagline", 3, "*별표*로 감싼 글자는 금색. 캡션 첫 줄로도 쓰여요"],
  ],
  story: [["큰 제목", "title", 2, "2줄까지"], ["본문", "body", 3, "3줄까지"]],
  highlight: [["큰 제목", "title", 2, "2줄까지"], ["본문", "body", 3, "3줄까지"]],
  acclaim: [
    ["금색 작은 제목", "kicker", 1, "도시·축제명 (예: 에든버러 프린지 2025)"],
    ["큰 제목", "title", 2, "2줄까지"],
    ["목록 4줄", "items", 4, "한 줄에 하나씩 '머리말 | 내용'. 별 5개 리뷰는 머리말에 ★★★★★ 매체명"],
  ],
  jury_note: [["인용문", "quote", 5, "한글 명조로 들어가요"], ["서명", "sign", 1, ""]],
  info_cta: [
    ["영문 제목", "title", 1, ""],
    ["한글 제목 (작게)", "title_ko", 1, ""],
    ["정보 3줄", "info", 3, "단체 / 도시 · 공연 시간 · 관람 연령 / YYYY 서울아츠어워즈 위너"],
    ["안내 박스 2줄", "cta", 2, "금색 테두리 상자 안 문장"],
  ],
};

// ------------------------------------------------------------ 열기·저장
async function openCarousel(path) {
  let r;
  try { r = await api("/api/carousel_get", { path }); } catch (e) { toast(e.message); return; }
  if (r.error) { toast(r.error, 4000); return; }
  C.work = r.work; C.name = r.name; C.car = r.carousel; C.photos = r.photos || []; C.videos = r.videos || [];
  C.outputs = r.outputs || []; C.sel = 0; C.vid = 0;
  C.pick = C.photos.length ? "photos" : "video";
  try {
    await Promise.all([document.fonts.load("500 40px NotoSerifKR"), document.fonts.load("700 40px SourceSerif"),
      document.fonts.load("600 40px SourceSerif"), document.fonts.load("700 40px Pretendard"), document.fonts.load("500 40px Pretendard")]);
  } catch { }
  carBadge(C.car.common.year);
  if (autoPhotos()) saveCar();
  $("#carName").textContent = r.name;
  try { video().pause(); } catch { }
  show("#carousel");
  renderCarPicker(); renderCarThumbs(); renderCarFields(); C.dirty = true;
}
// 아직 사진을 하나도 안 골랐으면: 사진 6장을 순서대로, 사진이 없으면 영상에서 고르게 장면 6개
function autoPhotos() {
  const cards = C.car.cards;
  if (cards.some((c) => c.photo)) return false;
  if (C.photos.length) {
    cards.forEach((c, i) => { c.photo = { path: C.photos[Math.floor(i * C.photos.length / 6) % C.photos.length].path }; });
    return true;
  } else if (C.videos.length && C.videos[0].duration) {
    const v = C.videos[0];
    cards.forEach((c, i) => { c.photo = { path: v.path, t: Math.round(v.duration * (i + 0.5) / 6 * 10) / 10 }; });
    return true;
  }
  return false;
}
function saveCar(extra) {
  if (!C.work) return;
  clearTimeout(C.saveT);
  const snap = { work: C.work, carousel: JSON.parse(JSON.stringify({ common: C.car.common, cards: C.car.cards })), ...(extra || {}) };
  const send = () => api("/api/carousel_save", snap).then((r) => { if (r && r.status) C.car.status = r.status; }).catch(() => { });
  if (extra) return send();
  C.saveT = setTimeout(send, 700);
}
function carChanged() { C.dirty = true; C.thumbDirty = true; saveCar(); }
function carBadge(y) {
  loadBadge(y).then(() => { C.dirty = true; C.thumbDirty = true; badgeNote(); });
}
function badgeNote() {
  const y = String(C.car.common.year || "").replace(/\D/g, "");
  const el = $("#carBadgeNote"); if (!el) return;
  el.textContent = y.length === 4 && S.badgeImgs[y] === null ? `${y}년 배지가 아직 없어요. 쇼츠 편집 화면 '배지·로고' 칸에서 한 번 넣어 두면 표지·마지막 장에 들어가요.` : "";
}

// ------------------------------------------------------------ 사진 불러오기
function photoUrl(ph, w = 1600) {
  if (!ph) return null;
  return ph.t == null ? `/api/photo?path=${encodeURIComponent(ph.path)}&w=${w}` : `/api/still?path=${encodeURIComponent(ph.path)}&t=${ph.t}&w=${w}`;
}
function getImg(ph) {
  const u = photoUrl(ph); if (!u) return null;
  const hit = C.imgs[u];
  if (hit) return hit.ok ? hit.im : null;
  const im = new Image();
  C.imgs[u] = { im, ok: false, p: new Promise((res) => {
    im.onload = () => { C.imgs[u].ok = true; C.dirty = true; C.thumbDirty = true; res(true); };
    im.onerror = () => { C.imgs[u].bad = true; res(false); };
  }) };
  im.src = u;
  return null;
}
async function waitImgs() {
  C.car.cards.forEach((c) => getImg(c.photo));
  await Promise.all(Object.values(C.imgs).map((x) => x.p));
}

// ------------------------------------------------------------ 글자 도우미
function cleanGold(t) { return String(t || "").replace(/\*/g, ""); }
function wrapN(ctx, text, maxW, maxLines) {
  // 줄바꿈(\n)은 그대로, 넘치면 낱말(안 되면 글자) 단위로 나눔. maxLines 넘으면 마지막 줄 끝에 …
  const out = [];
  for (const para of String(text || "").split("\n")) {
    if (!para.trim()) { out.push(""); continue; }
    let line = "";
    for (const w of para.split(/(\s+)/)) {
      const test = line + w;
      if (ctx.measureText(cleanGold(test)).width <= maxW) { line = test; continue; }
      if (line.trim()) { out.push(line.trimEnd()); line = w.trimStart(); } else line = "";
      if (ctx.measureText(cleanGold(line)).width > maxW) {
        let cur = "";
        for (const ch of line) {
          if (ctx.measureText(cleanGold(cur + ch)).width > maxW && cur) { out.push(cur); cur = ch; } else cur += ch;
        }
        line = cur;
      }
    }
    out.push(line.trimEnd());
  }
  while (out.length && !out[out.length - 1].trim()) out.pop();
  if (out.length > maxLines) {
    const keep = out.slice(0, maxLines);
    keep[maxLines - 1] = keep[maxLines - 1].replace(/\s*$/, "") + "…";
    keep.over = true;
    return keep;
  }
  return out;
}
// *금색* 표시를 살려서 한 줄 쓰기 (왼쪽 정렬)
function goldLine(ctx, line, x, y, color, gold) {
  for (const r of parseRuns(line)) { ctx.fillStyle = r.gold ? gold : color; ctx.fillText(r.t, x, y); x += ctx.measureText(r.t).width; }
}
function spaced(ctx, px) { if ("letterSpacing" in ctx) ctx.letterSpacing = px + "px"; }

// 아래에서부터 쌓는 글 덩어리: {h, draw(ctx, top)}
function tBlock(ctx, text, font, size, lh, maxW, maxLines, color, opt = {}) {
  ctx.font = font;
  spaced(ctx, opt.spacing || 0);
  const lines = text ? wrapN(ctx, text, maxW, maxLines) : [];
  spaced(ctx, 0);
  if (!lines.length) return null;
  return {
    h: lines.length * lh, over: !!lines.over,
    draw(c, top) {
      c.font = font; spaced(c, opt.spacing || 0); c.textBaseline = "middle"; c.textAlign = "left";
      lines.forEach((ln, i) => goldLine(c, ln, opt.x || 60, top + lh * i + lh / 2, color, opt.gold || GOLD2));
      spaced(c, 0);
    },
  };
}
function gap(h) { return { h, draw() { } }; }
function rule() { return { h: 4, rule: true, draw(c, top) { c.fillStyle = GOLD; c.fillRect(60, top, 64, 4); } }; }
function stackFromBottom(ctx, blocks, bottom) {
  blocks = blocks.filter(Boolean);
  // 글이 하나도 없으면 금색 선도 그리지 않음
  if (!blocks.some((b) => b.draw.length && !b.rule)) return { top: bottom, over: false };
  // 맨 앞·맨 뒤의 빈칸은 빼기
  while (blocks.length && blocks[0].draw.length === 0) blocks.shift();
  while (blocks.length && blocks[blocks.length - 1].draw.length === 0) blocks.pop();
  const total = blocks.reduce((a, b) => a + b.h, 0);
  let y = bottom - total;
  const over = blocks.some((b) => b.over);
  for (const b of blocks) { b.draw(ctx, y); y += b.h; }
  return { top: bottom - total, over };
}

// ------------------------------------------------------------ 카드 한 장 그리기 (1080×1350)
function drawCard(ctx, i, opt = {}) {
  const card = C.car.cards[i], cm = C.car.common, tc = TC();
  const year = String(cm.year || "").replace(/\D/g, "").slice(0, 4);
  ctx.save();
  ctx.clearRect(0, 0, CW, CH);
  // 배경 사진 (꽉 채우기 + 확대·위치)
  const im = getImg(card.photo);
  if (im && im.naturalWidth) {
    const s = Math.max(CW / im.naturalWidth, CH / im.naturalHeight) * (card.zoom || 1);
    const w = im.naturalWidth * s, h = im.naturalHeight * s;
    ctx.drawImage(im, (CW - w) * (card.px ?? 0.5), (CH - h) * (card.py ?? 0.5), w, h);
  } else {
    ctx.fillStyle = "#15151f"; ctx.fillRect(0, 0, CW, CH);
    const g = ctx.createRadialGradient(CW / 2, CH * 0.4, 30, CW / 2, CH * 0.4, 800);
    g.addColorStop(0, "rgba(120,90,40,0.35)"); g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g; ctx.fillRect(0, 0, CW, CH);
    if (!opt.export) {
      ctx.fillStyle = "rgba(255,255,255,0.35)"; ctx.font = `700 34px ${SANS}`; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.fillText(card.photo ? "사진 불러오는 중…" : "왼쪽에서 사진을 골라 주세요", CW / 2, CH * 0.36);
    }
  }
  // 위·아래 어둡게
  let g = ctx.createLinearGradient(0, 0, 0, 260);
  g.addColorStop(0, "rgba(0,0,0,0.6)"); g.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = g; ctx.fillRect(0, 0, CW, 260);
  const shade = tc.bottom_shade || 0.45, sTop = CH * (1 - shade) - 120;
  g = ctx.createLinearGradient(0, sTop, 0, CH);
  g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(0.35, "rgba(0,0,0,0.62)"); g.addColorStop(1, "rgba(0,0,0,0.9)");
  ctx.fillStyle = g; ctx.fillRect(0, sTop, CW, CH - sTop);

  // 머리: BEST OF FEST · 쪽번호
  const lg = tc.logo || {};
  ctx.textBaseline = "middle"; ctx.textAlign = "left";
  ctx.shadowColor = "rgba(0,0,0,0.5)"; ctx.shadowBlur = 10;
  ctx.fillStyle = lg.color || GOLD; ctx.font = `700 ${lg.size || 40}px ${SERIF}`;
  ctx.fillText(lg.text || "BEST OF FEST", 60, lg.y || 65);
  ctx.textAlign = "right"; ctx.fillStyle = "#fff"; ctx.font = `700 ${(tc.page || {}).size || 20}px ${SERIF}`;
  ctx.fillText(`${String(i + 1).padStart(2, "0")} / 06`, CW - 60, lg.y || 65);
  // 발: @best_of_fest · 사진 크레딧
  const ft = tc.footer || {};
  ctx.shadowBlur = 6;
  ctx.font = `500 ${ft.size || 20}px ${SANS}`; ctx.fillStyle = ft.color || "#bdbdbd";
  ctx.textAlign = "left"; ctx.fillText(ft.left || "@best_of_fest", 60, ft.y || 1308);
  const credit = (card.credit || cm.credit || "").trim();
  if (credit) { ctx.textAlign = "right"; fitFont(ctx, credit, 500, ft.size || 20, SANS, 640); ctx.fillText(credit, CW - 60, ft.y || 1308); }
  ctx.shadowColor = "rgba(0,0,0,0.55)"; ctx.shadowBlur = 14; ctx.shadowOffsetY = 2;

  const badge = S.badgeImgs[year] || null;
  const bw = tc.badge_width || {};
  const bottom = 1238;
  let res = { over: false };
  const W = CW - 120;
  if (card.role === "cover") {
    if (badge) { const w = bw.cover || 185; ctx.drawImage(badge, 60, 104, w, w * badge.height / badge.width); }
    // 영문 제목: 120px에서 폭에 맞게 줄이고, 2줄까지
    const tl = String(card.title || "").split("\n").filter((x) => x.trim()).slice(0, 2);
    let tsz = 120;
    for (const t of tl) tsz = Math.min(tsz, fitFont(ctx, t, 600, 120, SERIF, W));
    tsz = Math.max(tsz, 64);
    const titleB = tl.length ? { h: tl.length * tsz * 1.04, draw(c, top) {
      c.font = `600 ${tsz}px ${SERIF}`; c.fillStyle = "#fff"; c.textAlign = "left"; c.textBaseline = "middle";
      tl.forEach((t, k) => c.fillText(t, 60, top + tsz * 1.04 * k + tsz * 0.52));
    } } : null;
    res = stackFromBottom(ctx, [
      tBlock(ctx, card.award, `700 22px ${SANS}`, 22, 30, W, 1, GOLD, { spacing: 4 }), gap(14),
      titleB, gap(10),
      tBlock(ctx, card.subtitle, `500 30px ${SANS}`, 30, 40, W, 1, "rgba(255,255,255,0.92)"), gap(26),
      rule(), gap(26),
      tBlock(ctx, card.tagline, `500 32px ${SANS}`, 32, 48, W, 3, "#fff"),
    ], bottom);
  } else if (card.role === "story" || card.role === "highlight") {
    res = stackFromBottom(ctx, [
      tBlock(ctx, card.title, `700 56px ${SANS}`, 56, 72, W, 2, "#fff"), gap(24),
      rule(), gap(26),
      tBlock(ctx, card.body, `500 30px ${SANS}`, 30, 47, W, 3, "rgba(255,255,255,0.94)"),
    ], bottom);
  } else if (card.role === "acclaim") {
    const rows = String(card.items || "").split("\n").filter((x) => x.trim()).slice(0, 4);
    const rh = 66;
    const list = rows.length ? { h: rows.length * rh, draw(c, top) {
      rows.forEach((row, k) => {
        const y = top + k * rh;
        c.save(); c.shadowBlur = 0; c.fillStyle = "rgba(255,255,255,0.22)"; c.fillRect(60, y, W, 1); c.restore();
        const [head, ...rest] = row.split("|");
        const body = rest.join("|").trim();
        c.textBaseline = "middle"; c.textAlign = "left";
        let x = 60;
        if (rest.length) {
          c.font = `700 26px ${SANS}`; c.fillStyle = GOLD2;
          const ht = head.trim(); c.fillText(ht, x, y + rh / 2); x += c.measureText(ht).width + 20;
        }
        const txt = rest.length ? body : head.trim();
        fitFont(c, txt, 500, 26, SANS, CW - 60 - x); c.fillStyle = "#fff"; c.fillText(txt, x, y + rh / 2);
      });
    } } : null;
    res = stackFromBottom(ctx, [
      tBlock(ctx, card.kicker, `700 24px ${SANS}`, 24, 34, W, 1, GOLD, { spacing: 2 }), gap(12),
      tBlock(ctx, card.title, `700 56px ${SANS}`, 56, 72, W, 2, "#fff"), gap(24),
      rule(), gap(18),
      list,
    ], bottom);
  } else if (card.role === "jury_note") {
    const qm = { h: 74, draw(c, top) { c.font = `700 130px ${SERIF}`; c.fillStyle = GOLD; c.textAlign = "left"; c.textBaseline = "top"; c.fillText("“", 52, top - 8); } };
    res = stackFromBottom(ctx, [
      tBlock(ctx, "JURY CHAIR'S NOTE", `700 24px ${SANS}`, 24, 34, W, 1, GOLD, { spacing: 3 }), gap(18),
      qm, gap(6),
      tBlock(ctx, card.quote, `500 40px ${SERIF_KR}`, 40, 64, W, 6, "#fff"), gap(26),
      tBlock(ctx, card.sign, `500 24px ${SANS}`, 24, 34, W, 1, GOLD),
    ], bottom);
  } else if (card.role === "info_cta") {
    const en = String(card.title || ""), ko = String(card.title_ko || "");
    ctx.font = `500 28px ${SANS}`;
    const kw = ko ? ctx.measureText(ko).width + 22 : 0;
    const esz = en ? Math.max(48, fitFont(ctx, en, 600, 80, SERIF, W - kw)) : 0;
    const head = (en || ko) ? { h: Math.max(esz, 40) * 1.05, draw(c, top) {
      const base = top + Math.max(esz, 40) * 0.82;
      c.textBaseline = "alphabetic"; c.textAlign = "left";
      c.font = `600 ${esz}px ${SERIF}`; c.fillStyle = "#fff"; c.fillText(en, 60, base);
      const x = 60 + (en ? c.measureText(en).width + 22 : 0);
      c.font = `500 28px ${SANS}`; c.fillStyle = "rgba(255,255,255,0.85)"; c.fillText(ko, x, base);
    } } : null;
    const bwid = bw.info_cta || 210;
    const info = tBlock(ctx, card.info, `500 28px ${SANS}`, 28, 44, W - (badge ? bwid + 24 : 0), 3, "rgba(255,255,255,0.94)");
    const infoB = info ? { h: info.h, draw(c, top) {
      info.draw(c, top);
      if (badge) { const h = bwid * badge.height / badge.width; c.drawImage(badge, CW - 60 - bwid, top + info.h - h, bwid, h); }
    } } : null;
    ctx.font = `600 28px ${SANS}`;
    const ctaLines = card.cta ? wrapN(ctx, card.cta, W - 56, 2) : [];
    const cta = ctaLines.length ? { h: ctaLines.length * 44 + 44, over: !!ctaLines.over, draw(c, top) {
      c.save(); c.shadowBlur = 0;
      c.fillStyle = "rgba(0,0,0,0.35)"; roundRect(c, 60, top, W, this.h, 12); c.fill();
      c.strokeStyle = GOLD; c.lineWidth = 2; roundRect(c, 61, top + 1, W - 2, this.h - 2, 12); c.stroke();
      c.restore();
      c.font = `600 28px ${SANS}`; c.textBaseline = "middle"; c.textAlign = "left";
      ctaLines.forEach((ln, k) => goldLine(c, ln, 88, top + 22 + 44 * k + 22, "#fff", GOLD2));
    } } : null;
    res = stackFromBottom(ctx, [head, gap(20), rule(), gap(22), infoB, gap(30), cta], bottom);
  }
  ctx.restore();
  return res;
}

// ------------------------------------------------------------ 화면
function renderWorks(works) {
  const box = $("#workList"), card = $("#workCard");
  if (!box) return;
  box.innerHTML = "";
  card.classList.toggle("hidden", !(works && works.length));
  for (const w of works || []) {
    const el = document.createElement("button");
    el.className = "work";
    const chip = { edit: ["✏️ 만드는 중", "c-edit"], made: ["✅ 완성", "c-made"] }[w.status];
    el.innerHTML = `<div class="nm"></div><div class="meta"></div>`;
    el.querySelector(".nm").textContent = w.title;
    el.querySelector(".meta").textContent = `${w.year} · 사진 ${w.photos} · 영상 ${w.videos}`;
    if (chip) { const c = document.createElement("span"); c.className = "chip-st " + chip[1]; c.textContent = chip[0]; el.appendChild(c); }
    el.onclick = () => openCarousel(w.path);
    box.appendChild(el);
  }
}
function renderCarThumbs() {
  const box = $("#carThumbs"); box.innerHTML = "";
  C.car.cards.forEach((cd, i) => {
    const b = document.createElement("button");
    b.className = "car-thumb" + (i === C.sel ? " sel" : "");
    b.innerHTML = `<canvas width="216" height="270"></canvas><span>${String(i + 1).padStart(2, "0")} ${roleName(cd.role)}</span>`;
    b.onclick = () => { C.sel = i; renderCarThumbs(); renderCarFields(); renderCarPicker(); C.dirty = true; };
    box.appendChild(b);
  });
  C.thumbDirty = true; C.thumbT = 0;
}
function renderCarPicker() {
  $$("[data-cpick]").forEach((b) => b.classList.toggle("on", b.dataset.cpick === C.pick));
  $("#carPickPhotos").textContent = `사진 ${C.photos.length}`;
  $("#carPickVideo").textContent = `영상 장면 ${C.videos.length ? "" : "(없음)"}`;
  const grid = $("#carGrid"); grid.innerHTML = "";
  const vs = $("#carVidSel");
  vs.classList.toggle("hidden", C.pick !== "video" || C.videos.length < 2);
  const cur = C.car.cards[C.sel].photo;
  const add = (ph, label) => {
    const b = document.createElement("button");
    b.className = "pick";
    if (cur && cur.path === ph.path && (cur.t ?? null) === (ph.t ?? null)) b.classList.add("on");
    b.style.backgroundImage = `url("${photoUrl(ph, 320)}")`;
    b.title = label;
    if (ph.t != null) b.innerHTML = `<span>${fmt(ph.t).replace(/\.\d$/, "")}</span>`;
    b.onclick = () => {
      Object.assign(C.car.cards[C.sel], { photo: ph, zoom: 1, px: 0.5, py: 0.5 });
      carChanged(); renderCarPicker();
    };
    grid.appendChild(b);
  };
  if (C.pick === "photos") {
    if (!C.photos.length) grid.innerHTML = `<div class="muted small">이 작품 폴더에 사진이 없어요. '영상 장면'에서 골라 주세요.</div>`;
    C.photos.forEach((p) => add({ path: p.path }, p.name));
  } else {
    if (!C.videos.length) { grid.innerHTML = `<div class="muted small">이 작품 폴더에 영상이 없어요.</div>`; return; }
    vs.innerHTML = C.videos.map((v, k) => `<option value="${k}">${v.name.replace(/</g, "&lt;")}</option>`).join("");
    vs.value = String(C.vid);
    const v = C.videos[C.vid] || C.videos[0];
    const d = v.duration || 0, n = 12;
    for (let k = 0; k < n; k++) add({ path: v.path, t: Math.round(d * (k + 0.5) / n * 10) / 10 }, v.name);
  }
}
function fieldEl(label, val, rows, hint, onInput) {
  const wrap = document.createElement("div");
  wrap.innerHTML = `<span class="mini"></span>${rows > 1 ? `<textarea rows="${rows}"></textarea>` : `<input type="text">`}${hint ? `<div class="muted small"></div>` : ""}`;
  wrap.querySelector(".mini").textContent = label;
  const inp = wrap.querySelector("textarea, input");
  inp.value = val || "";
  inp.oninput = () => onInput(inp.value);
  if (hint) wrap.querySelector(".muted").textContent = hint;
  return wrap;
}
function renderCarFields() {
  const card = C.car.cards[C.sel], cm = C.car.common;
  $("#carTarget").textContent = `${String(C.sel + 1).padStart(2, "0")} ${roleName(card.role)}`;
  const box = $("#carFields"); box.innerHTML = "";
  for (const [label, key, rows, hint] of CARD_FIELDS[card.role] || []) {
    box.appendChild(fieldEl(label, card[key], rows, hint, (v) => { card[key] = v; carChanged(); }));
  }
  box.appendChild(fieldEl("이 장 사진 크레딧", card.credit, 1, "비우면 아래 공통 크레딧", (v) => { card.credit = v; carChanged(); }));
  $("#carZoom").value = card.zoom || 1;
  const cb = $("#carCommon"); cb.innerHTML = "";
  cb.appendChild(fieldEl("공통 사진 크레딧", cm.credit, 1, "Photo © 이름 · 모르면 Photo courtesy of 단체명", (v) => { cm.credit = v; carChanged(); }));
  cb.appendChild(fieldEl("수상 연도 (배지)", cm.year, 1, "", (v) => { cm.year = v; carBadge(v); carChanged(); }));
  cb.appendChild(fieldEl("파일 이름 (영문)", cm.slug, 1, "예: flamencoh → flamencoh_card01~06.jpg", (v) => { cm.slug = v; carChanged(); }));
  badgeNote();
}
function drawCarLoop() {
  requestAnimationFrame(drawCarLoop);
  if ($("#carousel").classList.contains("hidden") || !C.car) return;
  const now = performance.now();
  if (C.dirty) {
    C.dirty = false;
    const cv = $("#carPreview"), ctx = cv.getContext("2d");
    const r = drawCard(ctx, C.sel);
    $("#carWarn").textContent = r.over ? "글이 칸보다 길어서 잘렸어요(…). 줄이거나 줄바꿈을 고쳐 주세요." : "";
  }
  // 아래 6장 작은 그림은 1초에 한 번까지만 다시 그림 (옛날 노트북 배려)
  if (C.thumbDirty && now - C.thumbT > 1000) {
    C.thumbDirty = false; C.thumbT = now;
    const big = document.createElement("canvas"); big.width = CW; big.height = CH;
    const bctx = big.getContext("2d");
    $$("#carThumbs canvas").forEach((tc, i) => { drawCard(bctx, i); const t = tc.getContext("2d"); t.clearRect(0, 0, 216, 270); t.drawImage(big, 0, 0, 216, 270); });
  }
}
function bindCarDrag() {
  const cv = $("#carPreview");
  let st = null;
  cv.onpointerdown = (e) => { cv.setPointerCapture(e.pointerId); st = { x: e.clientX, y: e.clientY, c: { ...C.car.cards[C.sel] } }; cv.classList.add("drag"); };
  cv.onpointermove = (e) => {
    if (!st) return;
    const card = C.car.cards[C.sel], im = getImg(card.photo);
    if (!im) return;
    const k = cv.clientWidth / CW;
    const s = Math.max(CW / im.naturalWidth, CH / im.naturalHeight) * (card.zoom || 1);
    const roomX = im.naturalWidth * s - CW, roomY = im.naturalHeight * s - CH;
    if (roomX > 1) card.px = clamp01(st.c.px - (e.clientX - st.x) / k / roomX);
    if (roomY > 1) card.py = clamp01(st.c.py - (e.clientY - st.y) / k / roomY);
    C.dirty = true;
  };
  cv.onpointerup = cv.onpointercancel = () => { if (st) { C.thumbDirty = true; saveCar(); } st = null; cv.classList.remove("drag"); };
  cv.onwheel = (e) => {
    e.preventDefault();
    const card = C.car.cards[C.sel];
    card.zoom = Math.max(1, Math.min(3, (card.zoom || 1) * (e.deltaY < 0 ? 1.05 : 1 / 1.05)));
    $("#carZoom").value = card.zoom; carChanged();
  };
}

// ------------------------------------------------------------ 캡션·저장
function carCaption() {
  const cm = C.car.common, cards = C.car.cards;
  const y = String(cm.year || "").replace(/\D/g, "").slice(0, 4);
  const one = (t) => cleanGold(t).replace(/\s*\n\s*/g, " ").trim();
  const cap = (S.state && S.state.template && S.state.template.caption) || {};
  const tags = [...(cap.hashtags_fixed || ["#베스트오브페스트", "#서울아츠어워즈", "#에든버러페스티벌"])];
  for (const t of String(cm.tags || "").split(/[\s,]+/)) { const h = t.startsWith("#") ? t : "#" + t; if (t && !tags.includes(h)) tags.push(h); }
  const credits = [];
  for (const c of [cm.credit, ...cards.map((x) => x.credit)]) { const s = (c || "").trim(); if (s && !credits.includes(s)) credits.push(s); }
  const info = cards.find((x) => x.role === "info_cta") || {};
  const cover = cards.find((x) => x.role === "cover") || {};
  const out = [
    one(cover.tagline),
    "",
    `〈${cm.en || ""}〉 ${cm.ko || ""}`.trim(),
    `${y} 서울아츠어워즈 베스트 퍼포먼스${cm.adult ? " · 성인 관람" : ""}`,
    "",
    one(info.cta),
    "",
    `Seoul Arts Awards ${y} Best Performance — with gratitude to ${cm.company || "the company"} for sharing such authentic magic.`,
    "",
    credits.join(" / "),
    tags.slice(0, cap.hashtags_max || 5).join(" "),
  ];
  return out.join("\n").replace(/\n{3,}/g, "\n\n").replace(/^\n+/, "");
}
function openCarExport() {
  const cm = C.car.common;
  const slug = (cm.slug || "").toLowerCase().replace(/[^0-9a-z]/g, "");
  $("#cxSummary").textContent = `6장 · ${slug || "cards"}_card01 ~ 06.jpg (1080×1350) — 같은 이름이 있으면 _v2처럼 번호를 붙여요`;
  $("#cxCaption").value = carCaption();
  const empty = C.car.cards.map((c, i) => (!c.photo ? i + 1 : 0)).filter(Boolean);
  $("#cxWarn").textContent = empty.length ? `사진이 없는 장: ${empty.join(", ")}번 (어두운 배경으로 저장돼요)` : "";
  ["#cxForm", "#cxRun", "#cxDone"].forEach((x) => $(x).classList.toggle("hidden", x !== "#cxForm"));
  $("#carModal").classList.remove("hidden");
}
async function carExport() {
  if (C.busy) return;
  C.busy = true;
  ["#cxForm", "#cxRun", "#cxDone"].forEach((x) => $(x).classList.toggle("hidden", x !== "#cxRun"));
  try {
    try { await document.fonts.ready; } catch { }
    await waitImgs();
    const cv = document.createElement("canvas"); cv.width = CW; cv.height = CH;
    const ctx = cv.getContext("2d");
    const q = TC().jpg_quality || 0.9;
    const cards = [];
    for (let i = 0; i < 6; i++) { drawCard(ctx, i, { export: true }); cards.push(cv.toDataURL("image/jpeg", q)); }
    await saveCar({});
    const caption = $("#cxCaption").value;
    const r = await api("/api/carousel_export", { work: C.work, slug: C.car.common.slug, cards, caption });
    if (r.error) throw new Error(r.error);
    C.car.status = "made";
    $("#cxInfo").textContent = r.files.map((f) => f.split(/[\\/]/).pop()).join("\n");
    $("#cxCap").textContent = caption;
    const links = $("#cxLinks"); links.innerHTML = "";
    if (S.state.remote) {
      r.files.forEach((f, i) => {
        const a = document.createElement("a"); a.className = "btn ghost"; a.href = mediaUrl(f) + "&dl=1"; a.textContent = `📥 ${i + 1}번`;
        links.appendChild(a);
      });
    }
    $("#cxOpen").onclick = () => api("/api/open", { path: r.files[0] });
    ["#cxForm", "#cxRun", "#cxDone"].forEach((x) => $(x).classList.toggle("hidden", x !== "#cxDone"));
  } catch (e) {
    toast("저장하지 못했어요: " + e.message, 4000);
    ["#cxForm", "#cxRun", "#cxDone"].forEach((x) => $(x).classList.toggle("hidden", x !== "#cxForm"));
  } finally { C.busy = false; }
}
function bindCarousel() {
  $("#carBack").onclick = () => { saveCar({}); show("#home"); loadFiles(); };
  $("#carSave").onclick = openCarExport;
  $("#cxCancel").onclick = () => $("#carModal").classList.add("hidden");
  $("#cxClose").onclick = () => $("#carModal").classList.add("hidden");
  $("#cxGo").onclick = carExport;
  $("#cxCopy").onclick = () => { navigator.clipboard.writeText($("#cxCap").textContent).then(() => toast("설명을 복사했어요")); };
  $$("[data-cpick]").forEach((b) => b.onclick = () => { C.pick = b.dataset.cpick; renderCarPicker(); });
  $("#carVidSel").onchange = (e) => { C.vid = Number(e.target.value); renderCarPicker(); };
  $("#carZoom").oninput = (e) => { C.car.cards[C.sel].zoom = Number(e.target.value); carChanged(); };
  $("#carCenter").onclick = () => { Object.assign(C.car.cards[C.sel], { zoom: 1, px: 0.5, py: 0.5 }); $("#carZoom").value = 1; carChanged(); };
  $("#carNoPhoto").onclick = () => { C.car.cards[C.sel].photo = null; carChanged(); renderCarPicker(); };
  $("#carReset").onclick = () => ask("이 장의 글을 처음 값으로 되돌릴까요?", "작품표에서 가져온 기본 글로 바뀌어요. 사진은 그대로 둬요.", [{
    label: "되돌리기", primary: true, fn: async () => {
      const r = await api("/api/carousel_get", { path: C.work, fresh: 1 }).catch(() => null);
      const d = r && r.default_cards ? r.default_cards[C.sel] : null;
      if (!d) { toast("기본 글을 가져오지 못했어요"); return; }
      const keep = { photo: C.car.cards[C.sel].photo, zoom: C.car.cards[C.sel].zoom, px: C.car.cards[C.sel].px, py: C.car.cards[C.sel].py };
      C.car.cards[C.sel] = { ...d, ...keep }; renderCarFields(); carChanged();
    },
  }]);
  const eb = $("#btnCarousel");
  if (eb) eb.onclick = () => { if (S.cur) openCarousel(S.cur.path); };
  bindCarDrag();
  requestAnimationFrame(drawCarLoop);
}
bindCarousel();
