/* 공연 쇼츠 편집기 — 화면 동작 */
"use strict";
const $ = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));
const OW = 1080, OH = 1920;
const COLORS = ["#ffb23d", "#3ccf8e", "#5ab0ff", "#ff7ac6", "#c38bff", "#ffe14d", "#ff8a5c", "#6ee7e7"];

const S = {
  state: null,
  files: [],
  cur: null,            // 지금 열린 파일 {path,name,info,src}
  segments: [],         // {id,path,name,start,end,framing}
  sel: null,            // 선택된 구간 id
  draft: { mode: "fill", zoom: 1, px: 0.5, py: 0.5 },
  draftTouched: false,
  dirty: true,
  pendingIn: null,
  stopAt: null,
  style: {
    title: "", sub: "", tstyle: "shadow", tSize: 76, tY: 0.12, sY: 0.70, guide: true,
    logoPos: "tr", logoSize: 0.2, logoAlpha: 0.9,
    tpl: "bof",
    bof: { series: "", year: "2026", en: "", ko: "", company: "", tags: "" },
  },
  draftHook: "",
  projStatus: "",
  draftBadge: true,
  badgeImgs: {},
  logoImg: null,
  job: null,
};

// ------------------------------------------------------------ 공통
function setOffline(off) { const o = $("#offline"); if (o) o.classList.toggle("hidden", !off); }
async function api(path, body) {
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) };
  let r;
  try { r = await fetch(path, opt); }
  catch (e) { setOffline(true); throw new Error("프로그램과 연결이 끊겼어요"); }
  setOffline(false);
  const j = await r.json().catch(() => ({}));
  if (r.status === 401 && j.need_login) { showLogin(); throw new Error("PIN 로그인이 필요해요"); }
  // 작업 상태(/api/job)는 error 칸이 있어도 정상 응답이라 그대로 돌려줌
  if (!r.ok || (j.error && j.state === undefined)) throw new Error(j.error || ("서버 오류 " + r.status));
  return j;
}
function toast(msg, ms = 2200) {
  const t = $("#toast"); t.textContent = msg; t.classList.remove("hidden");
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.add("hidden"), ms);
}
function fmt(t) {
  if (!isFinite(t)) t = 0;
  const m = Math.floor(t / 60), s = t - m * 60;
  return `${m}:${s.toFixed(1).padStart(4, "0")}`;
}
function fmtSize(b) { return b > 1e9 ? (b / 1e9).toFixed(1) + "GB" : (b / 1e6).toFixed(0) + "MB"; }
function fmtDate(t) { const d = new Date(t * 1000); return `${d.getMonth() + 1}월 ${d.getDate()}일 ${d.getHours()}:${String(d.getMinutes()).padStart(2, "0")}`; }
function uid() { return Math.random().toString(36).slice(2, 9); }
function mediaUrl(p) { return "/media?path=" + encodeURIComponent(p); }
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { } },
  del(k) { try { localStorage.removeItem(k); } catch { } },
};
function show(id) { $$(".screen").forEach((e) => e.classList.add("hidden")); $(id).classList.remove("hidden"); }

window.addEventListener("error", (e) => { try { fetch("/api/clientlog", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ msg: `${e.message} @${e.filename}:${e.lineno}` }) }); } catch { } });
window.addEventListener("unhandledrejection", (e) => { try { fetch("/api/clientlog", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ msg: "promise: " + (e.reason && e.reason.message || e.reason) }) }); } catch { } });

// ------------------------------------------------------------ PIN 로그인 (원격 접속)
function showLogin() {
  $$(".screen").forEach((e) => e.classList.add("hidden"));
  $("#login").classList.remove("hidden");
  setTimeout(() => $("#pinInput").focus(), 50);
}
async function doLogin() {
  const pin = $("#pinInput").value.trim();
  if (!pin) return;
  $("#pinMsg").textContent = "확인 중…";
  try {
    const r = await fetch("/api/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pin }) });
    const j = await r.json().catch(() => ({}));
    if (r.ok && j.ok) { location.reload(); return; }
    $("#pinMsg").textContent = j.error || "다시 해 주세요";
    $("#pinInput").value = "";
  } catch { $("#pinMsg").textContent = "서버 노트북에 연결이 안 돼요. 노트북이 켜져 있는지 확인해 주세요."; }
}
$("#pinGo").onclick = doLogin;
$("#pinInput").addEventListener("keydown", (e) => { if (e.key === "Enter") doLogin(); });

// ------------------------------------------------------------ 시작
async function init() {
  setInterval(() => api("/api/heartbeat", {}).catch(() => { }), 20000);
  api("/api/heartbeat", {}).catch(() => { });
  try { await refreshState(); } catch (e) { if (!$("#login").classList.contains("hidden")) return; throw e; }
  document.body.classList.toggle("remote", !!S.state.remote);
  try { await Promise.all([document.fonts.load("800 80px Pretendard"), document.fonts.load("700 50px Pretendard")]); } catch { }
  if (S.state.settings.style && Object.keys(S.state.settings.style).length) {
    const saved = S.state.settings.style;
    Object.assign(S.style, saved, { bof: { ...S.style.bof, ...(saved.bof || {}) } });
  }
  try { await Promise.all([document.fonts.load("700 80px SourceSerif"), document.fonts.load("600 80px SourceSerif")]); } catch { }
  await loadLogo();
  bindHome(); bindEditor(); bindModal(); bindSettings();
  await loadFiles();
  checkResume();
  requestAnimationFrame(drawLoop);
}
async function refreshState() { S.state = await api("/api/state"); }
const BOF_FRAMING = { mode: "fit", zoom: 1, px: 0.5, py: 0.379 };
function isBof() { return S.style.tpl === "bof"; }
function loadBadge(year) {
  year = String(year || "").replace(/\D/g, "").slice(0, 4);
  if (year.length !== 4) return Promise.resolve(null);
  if (S.badgeImgs[year] !== undefined) return Promise.resolve(S.badgeImgs[year]);
  return new Promise((res) => {
    const im = new Image();
    im.onload = () => { S.badgeImgs[year] = im; S.dirty = true; updateBadgeBox(); res(im); };
    im.onerror = () => { S.badgeImgs[year] = null; updateBadgeBox(); res(null); };
    im.src = "/api/badge?year=" + year + "&t=" + Date.now();
  });
}
function curBadge() { const y = String(S.style.bof.year || "").replace(/\D/g, ""); return S.badgeImgs[y] || null; }
function updateBadgeBox() {
  const y = String(S.style.bof.year || "").replace(/\D/g, "");
  const b = $("#badgePrev"); if (!b) return;
  const im = S.badgeImgs[y];
  b.style.backgroundImage = im ? `url("${im.src}")` : "";
  b.textContent = im ? "" : (y ? `${y}년 배지가 아직 없어요` : "수상 연도를 먼저 적어 주세요");
  $("#btnBadge").textContent = y ? `${y}년 배지 불러오기` : "배지 이미지 불러오기";
}
async function loadLogo() {
  S.logoImg = null;
  if (!S.state.has_logo) return;
  await new Promise((res) => {
    const im = new Image();
    im.onload = () => { S.logoImg = im; res(); };
    im.onerror = res;
    im.src = "/api/logo?t=" + Date.now();
  });
}

// ------------------------------------------------------------ 목록 화면
function bindHome() {
  $("#btnRefresh").onclick = loadFiles;
  $("#btnOpenFile").onclick = async () => {
    const r = await api("/api/pick_file", {}).catch((e) => toast(e.message));
    if (r && r.ok) openFile(r.file);
  };
  $$("[data-pick]").forEach((b) => b.onclick = async () => {
    const r = await api("/api/pick_folder", { which: b.dataset.pick }).catch((e) => toast(e.message));
    if (r && r.ok) { toast("폴더를 바꿨어요"); await refreshState(); await loadFiles(); fillSettings(); }
  });
  $("#btnMakeSrc").onclick = async () => {
    await api("/api/create_folder", { which: "source" });
    await api("/api/create_folder", { which: "output" });
    await refreshState(); await loadFiles();
    toast("구글 드라이브에 폴더를 만들었어요");
  };
  $("#btnSettings").onclick = () => { fillSettings(); $("#settings").classList.remove("hidden"); };
}
async function loadFiles() {
  await refreshState();
  const st = S.state.settings;
  const box = $("#setupBox");
  const waitDrive = S.state.source_state === "drive_missing";
  const needSetup = !S.state.source_ok && !waitDrive;
  clearTimeout(loadFiles._t);
  if (waitDrive) loadFiles._t = setTimeout(loadFiles, 5000);
  box.classList.toggle("hidden", !needSetup);
  $("#setupSrc").textContent = st.source_dir || "아직 정해지지 않았어요";
  $("#setupOut").textContent = st.output_dir || "아직 정해지지 않았어요";
  $("#btnMakeSrc").classList.toggle("hidden", !(st.source_dir && needSetup));
  $("#folderLabel").textContent = st.source_dir ? "폴더: " + st.source_dir : "";
  const list = $("#fileList");
  list.innerHTML = "";
  let r = { files: [] };
  try { r = await api("/api/files"); } catch (e) { toast(e.message); }
  S.files = r.files || [];
  if (window.renderWorks) renderWorks(r.works || []);
  if (!S.files.length) {
    list.innerHTML = `<div class="empty">${waitDrive
      ? "구글 드라이브가 아직 준비되지 않았어요.<br>노트북을 막 켰다면 1~2분 기다려 주세요. 준비되면 저절로 목록이 떠요."
      : S.state.source_ok
        ? "아직 영상이 없어요.<br>구글 드라이브의 소스 폴더에 영상을 올린 뒤 ↻ 새로고침을 눌러 주세요."
        : "소스 폴더를 먼저 정해 주세요."}</div>`;
    return;
  }
  S.files.forEach((f, i) => {
    const el = document.createElement("button");
    el.className = "file";
    el.innerHTML = `<div class="thumb">🎬</div><div class="grow"><div class="nm"></div><div class="meta"></div></div><div class="muted small">열기 →</div>`;
    if (i < 40) {
      const th = el.querySelector(".thumb"), im = new Image();
      im.onload = () => { th.style.backgroundImage = `url("${im.src}")`; th.textContent = ""; };
      im.src = "/api/thumb?path=" + encodeURIComponent(f.path);
    }
    el.querySelector(".nm").textContent = f.name;
    el.querySelector(".meta").textContent = `${fmtDate(f.mtime)} · ${fmtSize(f.size)}${f.folder ? " · " + f.folder : ""}`;
    const chip = { auto: ["✨ 자동 초안", "c-auto"], edit: ["✏️ 편집 중", "c-edit"], ready: ["🤖 자막 완료 · 확인 필요", "c-ready"], made: ["✅ 완성", "c-made"] }[f.status];
    if (chip) { const c = document.createElement("span"); c.className = "chip-st " + chip[1]; c.textContent = chip[0]; el.querySelector(".nm").after(c); }
    el.onclick = () => openFromList(f);
    list.appendChild(el);
  });
}
function openFromList(f) {
  openFile(f);
}
function _unusedAsk(f) {
  const others = S.segments.filter((s) => s.path !== f.path);
  if (others.length) {
    ask("전에 고른 구간이 남아 있어요", `구간 ${S.segments.length}개가 있어요. 이 영상 구간을 뒤에 이어 붙일까요, 새로 시작할까요?`, [
      { label: "이어 붙이기", fn: () => openFile(f) },
      { label: "새로 시작", primary: true, fn: () => { S.segments = []; S.sel = null; store.del("project"); openFile(f); } },
    ]);
  } else openFile(f);
}
function ask(title, text, btns) {
  $("#askTitle").textContent = title; $("#askText").textContent = text;
  const box = $("#askBtns"); box.innerHTML = "";
  const cancel = document.createElement("button"); cancel.className = "ghost"; cancel.textContent = "취소";
  cancel.onclick = () => $("#ask").classList.add("hidden"); box.appendChild(cancel);
  for (const b of btns) {
    const el = document.createElement("button"); el.className = b.primary ? "primary" : "ghost"; el.textContent = b.label;
    el.onclick = () => { $("#ask").classList.add("hidden"); b.fn(); }; box.appendChild(el);
  }
  $("#ask").classList.remove("hidden");
}
function checkResume() {
  return;  // 영상별 편집 내용은 서버에 저장돼서 목록에서 바로 이어서 할 수 있음
  const p = store.get("project", null);
  if (p && p.segments && p.segments.length) {
    $("#resumeBox").classList.remove("hidden");
    $("#resumeInfo").textContent = `구간 ${p.segments.length}개 · ${p.segments[0].name}`;
    $("#btnResume").onclick = async () => {
      S.segments = p.segments; S.draft = p.draft || S.draft; S.draftTouched = true;
      $("#resumeBox").classList.add("hidden");
      const last = p.curPath || p.segments[p.segments.length - 1].path;
      const seg = p.segments.find((s) => s.path === last) || p.segments[0];
      await openFile({ path: seg.path, name: seg.name }, true);
    };
    $("#btnDiscard").onclick = () => { store.del("project"); S.segments = []; S.sel = null; $("#resumeBox").classList.add("hidden"); };
  }
}
let saveProjT = null;
function projPath() { return S.segments.length ? S.segments[0].path : (S.cur && S.cur.path); }
function saveProject(extra) {
  store.set("project", { segments: S.segments, draft: S.draft, curPath: S.cur && S.cur.path });
  const path = projPath(); if (!path) return;
  clearTimeout(saveProjT);
  // 지금 내용을 바로 복사해 둠 (0.7초 사이에 다른 영상으로 넘어가도 섞이지 않게)
  const snap = { path, segments: JSON.parse(JSON.stringify(S.segments)), bof: { ...S.style.bof }, ...(extra || {}) };
  const send = () => api("/api/project", snap).then((r) => { if (S.cur && projPath() === path) S.projStatus = r.status; }).catch(() => { });
  if (extra) send(); else saveProjT = setTimeout(send, 700);
}
function fillBofInputs() {
  const b = S.style.bof;
  [["bSeries", "series"], ["bYear", "year"], ["bEn", "en"], ["bKo", "ko"], ["bCompany", "company"], ["bTags", "tags"]].forEach(([id, k]) => { const el = $("#" + id); if (el) el.value = b[k] || ""; });
  loadBadge(b.year); updateBadgeBox(); S.dirty = true;
}

// ------------------------------------------------------------ 파일 열기
const video = () => $("#video");
async function openFile(f, keep = false) {
  if (!keep && S.segments.length && !S.segments.some((s) => s.path === f.path)) {
    // 다른 영상 구간도 같이 이어 붙일 수 있음 — 기존 구간 유지
  }
  show("#editor");
  if (!store.get("helpSeen", 0)) $("#help").classList.remove("hidden");
  $("#curName").textContent = f.name;
  const v = video();
  setVideoMsg("영상 불러오는 중…<br><span class='small muted'>구글 드라이브에서 처음 여는 영상이면 내려받느라 조금 걸려요.</span>");
  let info;
  try { info = (await api("/api/probe", { path: f.path })).info; }
  catch (e) { setVideoMsg("이 영상을 열 수 없어요.<br><span class='small muted'>" + e.message + "</span>"); return; }
  S.cur = { path: f.path, name: f.name, info, src: mediaUrl(f.path), proxied: false };
  if (!keep) {
    // 이 영상의 저장된 편집(자동 초안 포함) 불러오기
    let pj = null, defB = null;
    try { const r = await api("/api/project_get", { path: f.path }); pj = r.project; defB = r.default_bof; } catch { }
    S.sel = null; S.pendingIn = null;
    S.segments = (pj && pj.segments) ? pj.segments : [];
    S.projStatus = pj ? pj.status : "";
    S.projCaption = (pj && pj.caption) || "";
    const b = (pj && pj.bof) || defB;
    if (b) {
      Object.assign(S.style.bof, { series: "", en: "", ko: "", company: "", tags: "", slug: "", adult: false }, b);
      // 예전에 저장된 초안에 slug·성인 표시가 없으면 작품표 기본값으로 보충
      if (defB) for (const k of ["slug", "adult"]) if (!b[k] && defB[k]) S.style.bof[k] = defB[k];
      fillBofInputs();
    }
    S.draftHook = ""; S.draftBadge = S.segments.length === 0 || (TR().badge || {}).all_scenes !== false;
    if (S.segments.length) { S.draft = { ...S.segments[S.segments.length - 1].framing }; S.draftTouched = true; }
    else S.draftTouched = false;
    if (S.projStatus === "auto") setTimeout(() => toast("✨ 자동으로 고른 하이라이트예요. 확인하고 자막만 적어 주세요", 4000), 600);
    if (S.projStatus === "ready") setTimeout(() => toast("🤖 Claude가 자막과 설명을 채워 뒀어요. 미리보기로 확인하고 '쇼츠 만들기'만 누르세요", 5000), 600);
    syncHookUI();
  }
  if (!S.draftTouched && !S.segments.length && isBof()) {
    S.draft = { ...BOF_FRAMING };
  } else if (!S.draftTouched && !S.segments.length) {
    // 가로 공연 영상은 '전체 보이기'(흐린 배경)가 사람이 덜 잘려서 기본값
    S.draft = info.width > info.height ? { mode: "fit", zoom: 1.25, px: 0.5, py: 0.5 } : { mode: "fill", zoom: 1, px: 0.5, py: 0.5 };
  }
  $("#timeDur").textContent = fmt(info.duration);
  $("#timeNow").textContent = fmt(0);
  v.onerror = () => tryProxy();
  v.onloadedmetadata = () => {
    if (!v.videoWidth) { tryProxy(); return; }
    setVideoMsg(null);
    drawTimeline(); S.dirty = true;
  };
  v.onseeked = v.onloadeddata = () => { S.dirty = true; };
  if (S.state.remote) {
    tryProxy(false, true);
  } else {
    v.src = S.cur.src;
    v.load();
  }
  S.pendingIn = null;
  updateMarks(); renderSegs(); drawTimeline(); syncFrameUI();
}
function setVideoMsg(html) {
  const m = $("#videoMsg");
  if (!html) { m.classList.add("hidden"); return; }
  m.innerHTML = `<div>${html}</div>`; m.classList.remove("hidden");
}
async function tryProxy(force = false, remoteFirst = false) {
  const cur = S.cur;
  if (force && cur && cur.proxied && cur.src.includes("proxy_")) { toast("이미 가벼운 미리보기로 보고 있어요"); return; }
  if (force && cur) cur.proxied = false;
  if (!cur || cur.proxied) { setVideoMsg("이 영상은 미리보기가 안 돼요. 그래도 만들기는 될 수 있어요."); return; }
  cur.proxied = true;
  setVideoMsg((remoteFirst
    ? `가벼운 미리보기를 준비하고 있어요.<br><span class="small muted">처음 여는 영상은 서버 노트북이 변환하느라 몇 분 걸릴 수 있어요. 완성본은 원본 화질 그대로예요.</span>`
    : `이 영상은 바로 재생이 안 돼서<br>미리보기용 사본을 만들고 있어요. (원본 화질은 그대로)`) +
    `<div class="bar"><div id="pxBar"></div></div><div class="small muted" id="pxPct">0%</div>`);
  try {
    const { job } = await api("/api/proxy", { path: cur.path });
    for (; ;) {
      const st = await api("/api/job?id=" + job);
      if (S.cur !== cur) return;
      const b = $("#pxBar"); if (b) b.style.width = (st.progress * 100).toFixed(0) + "%";
      const p = $("#pxPct"); if (p) p.textContent = (st.progress * 100).toFixed(0) + "%";
      if (st.state === "done") {
        const t = video().currentTime;
        cur.src = mediaUrl(st.output); video().src = cur.src; video().load();
        video().addEventListener("loadedmetadata", () => { video().currentTime = t; }, { once: true });
        return;
      }
      if (st.state === "error") throw new Error(st.error);
      await new Promise((r) => setTimeout(r, 700));
    }
  } catch (e) { setVideoMsg("미리보기를 만들지 못했어요.<br><span class='small muted'>" + e.message.slice(0, 200) + "</span>"); }
}

// ------------------------------------------------------------ 편집 화면
function bindEditor() {
  const v = video();
  $("#btnBack").onclick = () => { v.pause(); show("#home"); loadFiles(); checkResume(); };
  $("#btnPlay").onclick = togglePlay;
  $$("[data-skip]").forEach((b) => b.onclick = () => seek(v.currentTime + Number(b.dataset.skip)));
  v.onplay = v.onpause = () => { $("#btnPlay").textContent = v.paused ? "▶ 재생" : "❚❚ 멈춤"; };
  v.ontimeupdate = () => { $("#timeNow").textContent = fmt(v.currentTime); };
  $("#btnIn").onclick = markIn;
  $("#btnOut").onclick = markOut;
  $$("[data-quick]").forEach((b) => b.onclick = () => quickAdd(Number(b.dataset.quick)));
  $("#btnUnsel").onclick = () => selectSeg(null);
  $("#btnLight").onclick = () => tryProxy(true);
  $("#btnHelp").onclick = () => $("#help").classList.remove("hidden");
  $("#helpClose").onclick = () => { $("#help").classList.add("hidden"); store.set("helpSeen", 1); };

  // 타임라인 클릭/끌기
  const tl = $("#timeline");
  let dragging = false;
  const tlSeek = (e) => {
    const r = tl.getBoundingClientRect();
    const d = S.cur ? S.cur.info.duration : 0;
    seek(Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * d);
  };
  tl.onpointerdown = (e) => { dragging = true; tl.setPointerCapture(e.pointerId); tlSeek(e); };
  tl.onpointermove = (e) => {
    if (dragging) tlSeek(e);
    if (!S.cur) return;
    const r = tl.getBoundingClientRect(), x = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
    const tip = $("#tlTip"); tip.classList.remove("hidden");
    tip.style.left = Math.max(24, Math.min(r.width - 24, x * r.width)) + "px";
    tip.textContent = fmt(x * S.cur.info.duration);
  };
  tl.onpointerleave = () => $("#tlTip").classList.add("hidden");
  tl.onpointerup = () => { dragging = false; };

  // 키보드
  document.addEventListener("keydown", (e) => {
    if ($("#editor").classList.contains("hidden")) return;
    if (["#modal", "#settings", "#help", "#ask"].some((id) => !$(id).classList.contains("hidden"))) return;
    if (["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement.tagName)) return;
    const k = e.key.toLowerCase();
    if (k === " ") { e.preventDefault(); togglePlay(); }
    else if (k === "arrowleft") { e.preventDefault(); seek(v.currentTime - (e.shiftKey ? 5 : 1)); }
    else if (k === "arrowright") { e.preventDefault(); seek(v.currentTime + (e.shiftKey ? 5 : 1)); }
    else if (k === ",") seek(v.currentTime - 1 / 30);
    else if (k === ".") seek(v.currentTime + 1 / 30);
    else if (k === "i") markIn();
    else if (k === "o") markOut();
    else if (k === "escape") { if (S.sel) selectSeg(null); else if (S.pendingIn !== null) { S.pendingIn = null; updateMarks(); drawTimeline(); } }
  });

  // 탭
  $$(".tab").forEach((t) => t.onclick = () => {
    $$(".tab").forEach((x) => x.classList.toggle("active", x === t));
    $$(".tabpane").forEach((p) => p.classList.toggle("hidden", p.id !== "tab-" + t.dataset.tab));
  });

  // 화면 배치
  $$("[data-mode]").forEach((b) => b.onclick = () => setFraming({ mode: b.dataset.mode, zoom: 1, px: 0.5, py: 0.5 }));
  ["zoom", "px", "py"].forEach((k) => $("#" + k).oninput = (e) => setFraming({ [k]: Number(e.target.value) }));
  $("#btnCenter").onclick = () => setFraming({ px: 0.5, py: 0.5 });
  $("#btnApplyAll").onclick = () => {
    const f = { ...curFraming() };
    S.segments.forEach((s) => s.framing = { ...f });
    S.draft = { ...f };
    saveProject(); toast("모든 구간에 같은 화면 설정을 적용했어요");
  };
  bindPreviewDrag();

  // 글자
  const st = S.style;
  $("#tTitle").value = st.title; $("#tSub").value = st.sub;
  $("#tSize").value = st.tSize; $("#tY").value = st.tY; $("#sY").value = st.sY; $("#guide").checked = st.guide;
  $("#tTitle").oninput = (e) => { st.title = e.target.value; saveStyle(); };
  $("#tSub").oninput = (e) => { st.sub = e.target.value; saveStyle(); };
  $("#tSize").oninput = (e) => { st.tSize = Number(e.target.value); saveStyle(); };
  $("#tY").oninput = (e) => { st.tY = Number(e.target.value); saveStyle(); };
  $("#sY").oninput = (e) => { st.sY = Number(e.target.value); saveStyle(); };
  $("#guide").onchange = (e) => { st.guide = e.target.checked; saveStyle(); };
  $$("[data-tstyle]").forEach((b) => b.onclick = () => { st.tstyle = b.dataset.tstyle; saveStyle(); });
  // 베스트오브페스트 양식
  $$("[data-tpl]").forEach((b) => b.onclick = () => {
    st.tpl = b.dataset.tpl; saveStyle(); syncTplUI(); renderSegs();
    if (st.tpl === "bof") {
      if (S.segments.length) {
        ask("화면 위치도 양식에 맞출까요?", "영상을 가로 그대로, 제목 아래쪽에 두는 베스트오브페스트 배치로 모든 구간을 바꿔요.", [
          { label: "맞추기", primary: true, fn: () => { S.segments.forEach((x) => x.framing = { ...BOF_FRAMING }); S.draft = { ...BOF_FRAMING }; syncFrameUI(); saveProject(); S.dirty = true; } },
        ]);
      } else { S.draft = { ...BOF_FRAMING }; syncFrameUI(); }
    }
  });
  const bf = st.bof;
  const bindB = (id, key) => { const el = $("#" + id); el.value = bf[key] || ""; el.oninput = () => { S.style.bof[key] = el.value; saveStyle(); if (S.segments.length) saveProject(); if (key === "year") { loadBadge(S.style.bof.year); updateBadgeBox(); } }; };
  bindB("bSeries", "series"); bindB("bYear", "year"); bindB("bEn", "en"); bindB("bKo", "ko"); bindB("bCompany", "company"); bindB("bTags", "tags");
  $("#bHook").oninput = (e) => {
    const maxL = (TR().caption || {}).max_lines || 2;
    const ls = e.target.value.split("\n");
    if (ls.length > maxL) {
      // 넘친 줄은 마지막 줄 뒤에 이어 붙임
      e.target.value = ls.slice(0, maxL - 1).concat([ls.slice(maxL - 1).join(" ").trim()]).join("\n");
      toast(`자막은 ${maxL}줄까지예요`);
    }
    const sg = curSeg();
    if (sg) { sg.hook = e.target.value; renderSegs(); saveProject(); } else S.draftHook = e.target.value;
    S.dirty = true;
  };
  $("#bBadge").onchange = (e) => {
    const sg = curSeg();
    if (sg) { sg.badge = e.target.checked ? (sg.badge || true) : false; renderSegs(); saveProject(); } else S.draftBadge = e.target.checked;
    S.dirty = true;
  };
  $("#btnBadge").onclick = () => {
    if (!String(S.style.bof.year || "").replace(/\D/g, "")) { toast("'글자' 칸에서 수상 연도를 먼저 적어 주세요"); return; }
    $("#badgeFile").click();
  };
  $("#badgeFile").onchange = async (e) => {
    const file = e.target.files[0]; if (!file) return;
    const url = await new Promise((res) => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(file); });
    const im = new Image();
    im.onload = async () => {
      const sc = Math.min(1, 900 / Math.max(im.width, im.height));
      const c = document.createElement("canvas"); c.width = Math.round(im.width * sc); c.height = Math.round(im.height * sc);
      c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
      const y = String(S.style.bof.year).replace(/\D/g, "").slice(0, 4);
      await api("/api/badge", { year: y, data: c.toDataURL("image/png") });
      delete S.badgeImgs[y]; await loadBadge(y); toast(`${y}년 배지를 넣었어요`);
    };
    im.src = url; e.target.value = "";
  };
  $("#btnBadgeOff").onclick = async () => {
    const y = String(S.style.bof.year).replace(/\D/g, "").slice(0, 4); if (!y) return;
    await api("/api/badge", { year: y, data: null }); S.badgeImgs[y] = null; updateBadgeBox(); S.dirty = true; toast("배지를 뺐어요");
  };
  syncTplUI(); syncHookUI(); loadBadge(bf.year);

  // 로고
  $("#btnLogo").onclick = () => $("#logoFile").click();
  $("#logoFile").onchange = async (e) => {
    const file = e.target.files[0]; if (!file) return;
    const url = await new Promise((res) => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(file); });
    const im = new Image();
    im.onload = async () => {
      // PNG 로 정규화 (최대 800px)
      const sc = Math.min(1, 800 / Math.max(im.width, im.height));
      const c = document.createElement("canvas"); c.width = Math.round(im.width * sc); c.height = Math.round(im.height * sc);
      c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
      await api("/api/logo", { data: c.toDataURL("image/png") });
      S.state.has_logo = true; await loadLogo(); S.dirty = true; toast("로고를 넣었어요");
    };
    im.src = url;
    e.target.value = "";
  };
  $("#btnLogoOff").onclick = async () => { await api("/api/logo", { data: null }); S.state.has_logo = false; S.logoImg = null; S.dirty = true; toast("로고를 뺐어요"); };
  $$("[data-lpos]").forEach((b) => b.onclick = () => { st.logoPos = b.dataset.lpos; saveStyle(); });
  $("#lSize").value = st.logoSize; $("#lAlpha").value = st.logoAlpha;
  $("#lSize").oninput = (e) => { st.logoSize = Number(e.target.value); saveStyle(); };
  $("#lAlpha").oninput = (e) => { st.logoAlpha = Number(e.target.value); saveStyle(); };
  syncStyleUI();
}
function togglePlay() {
  const v = video(); if (!v.src) return;
  S.stopAt = null;
  if (v.paused) v.play().catch(() => { }); else v.pause();
}
function seek(t) {
  const v = video(); if (!S.cur) return;
  v.currentTime = Math.max(0, Math.min(S.cur.info.duration - 0.05, t));
  $("#timeNow").textContent = fmt(v.currentTime);
}
function adjSeg() { const s = curSeg(); return s && S.cur && s.path === S.cur.path ? s : null; }
function markIn() {
  if (!S.cur) return;
  const s = adjSeg(), t = +video().currentTime.toFixed(3);
  if (s) {
    if (t > s.end - 0.3) { toast("시작은 끝보다 앞이어야 해요"); return; }
    s.start = t; afterSegChange(); toast("시작을 바꿨어요"); return;
  }
  S.pendingIn = video().currentTime;
  updateMarks(); drawTimeline();
}
function newSeg(a, b) {
  const seg = { id: uid(), path: S.cur.path, name: S.cur.name, start: +a.toFixed(3), end: +b.toFixed(3), framing: { ...S.draft },
    hook: S.draftHook, badge: S.draftBadge };
  // 다음 구간은 새 자막으로 (장면마다 자막이 바뀌는 양식)
  // 배지는 모든 장면에 (STYLE.md 2장)
  S.draftHook = ""; S.draftBadge = (TR().badge || {}).all_scenes !== false;
  syncHookUI();
  return seg;
}
function afterSegChange() { renderSegs(); drawTimeline(); updateMarks(); saveProject(); }
function quickAdd(n) {
  if (!S.cur) return;
  if (S.sel) selectSeg(null);
  const a = video().currentTime, b = Math.min(S.cur.info.duration, a + n);
  if (b - a < 0.3) { toast("영상 끝이라 넣을 수 없어요"); return; }
  S.segments.push(newSeg(a, b));
  S.pendingIn = null; afterSegChange();
  toast(`구간 ${S.segments.length} 추가 (${(b - a).toFixed(1)}초)`);
}
function markOut() {
  const s = adjSeg();
  if (s) {
    const t = +video().currentTime.toFixed(3);
    if (t < s.start + 0.3) { toast("끝은 시작보다 뒤여야 해요"); return; }
    s.end = t; afterSegChange(); toast("끝을 바꿨어요"); return;
  }
  if (!S.cur || S.pendingIn === null) return;
  let a = S.pendingIn, b = video().currentTime;
  if (b < a) [a, b] = [b, a];
  if (b - a < 0.3) { toast("구간이 너무 짧아요. 조금 더 재생한 뒤 눌러 주세요."); return; }
  const seg = newSeg(a, b);
  S.segments.push(seg);
  S.pendingIn = null;
  updateMarks(); renderSegs(); drawTimeline(); saveProject();
  toast(`구간 ${S.segments.length} 추가 (${(b - a).toFixed(1)}초)`);
}
function updateMarks() {
  const s = adjSeg();
  const armed = S.pendingIn !== null && !s;
  const bi = $("#btnIn"), bo = $("#btnOut"), info = $("#pendingInfo");
  bi.classList.toggle("armed", armed);
  bi.classList.toggle("adjust", !!s); bo.classList.toggle("adjust", !!s);
  $("#btnUnsel").classList.toggle("hidden", !S.sel);
  $$("[data-quick]").forEach((b) => b.classList.toggle("hidden", !!S.sel));
  info.classList.toggle("adjust", !!s);
  if (s) {
    const n = S.segments.indexOf(s) + 1;
    bi.textContent = `⎡ 구간 ${n} 시작을 여기로`; bo.textContent = `구간 ${n} 끝을 여기로 ⎦`; bo.disabled = false;
    info.textContent = `구간 ${n}을 고치는 중이에요 (${fmt(s.start)} ~ ${fmt(s.end)}). 다 고쳤으면 '선택 풀기'.`;
  } else {
    bi.textContent = "⎡ 여기서 시작"; bo.textContent = "여기서 끝 ⎦ 구간 추가"; bo.disabled = !armed;
    info.textContent = armed
      ? `시작 ${fmt(S.pendingIn)} — 끝날 곳에서 '여기서 끝'을 누르세요. (취소: Esc)`
      : "재생하다가 쓰고 싶은 곳에서 '여기서 시작', 끝낼 곳에서 '여기서 끝'. 바로 넣으려면 +15초 / +30초.";
  }
}
function totalLen() { return S.segments.reduce((a, s) => a + (s.end - s.start), 0); }
function renderSegs() {
  const list = $("#segList"); list.innerHTML = "";
  if (!S.segments.length) list.innerHTML = `<div class="seg-empty">아직 고른 구간이 없어요</div>`;
  S.segments.forEach((s, i) => {
    const el = document.createElement("div");
    el.className = "seg" + (S.sel === s.id ? " sel" : "");
    const multi = new Set(S.segments.map((x) => x.path)).size > 1;
    el.innerHTML = `<div class="chip" style="background:${COLORS[i % COLORS.length]}">${i + 1}</div>
      <div class="info"><div class="t">${fmt(s.start)} ~ ${fmt(s.end)} <span class="muted small">(${(s.end - s.start).toFixed(1)}초)</span></div>
      ${multi ? `<div class="f"></div>` : ""}${isBof() && s.hook ? `<div class="h"></div>` : ""}</div>
      <button data-a="play" title="이 구간만 보기">▶</button>
      <button data-a="up" title="앞으로">▲</button><button data-a="down" title="뒤로">▼</button>
      <button data-a="del" title="지우기">✕</button>`;
    if (multi) el.querySelector(".f").textContent = s.name;
    if (isBof() && s.hook) el.querySelector(".h").textContent = "💬 " + s.hook.replace(/\*/g, "").replace(/\n/g, " ") + (s.badge ? (isHero(s) ? "  🏅✨" : "  🏅") : "");
    el.onclick = (e) => {
      const a = e.target.dataset && e.target.dataset.a;
      if (a === "del") { S.segments.splice(i, 1); if (S.sel === s.id) S.sel = null; }
      else if (a === "up" && i > 0) { [S.segments[i - 1], S.segments[i]] = [S.segments[i], S.segments[i - 1]]; }
      else if (a === "down" && i < S.segments.length - 1) { [S.segments[i + 1], S.segments[i]] = [S.segments[i], S.segments[i + 1]]; }
      else if (a === "play") { selectSeg(s.id, true); return; }
      else { selectSeg(S.sel === s.id ? null : s.id); return; }
      renderSegs(); drawTimeline(); syncFrameUI(); saveProject();
    };
    list.appendChild(el);
  });
  const t = totalLen();
  $("#totalLen").textContent = S.segments.length
    ? `총 ${t.toFixed(1)}초${t > 180 ? " · 3분이 넘으면 유튜브 쇼츠로 안 올라가요" : t > 90 ? " · 90초 넘으면 릴스 노출이 줄 수 있어요" : ""}` : "";
  $("#btnExport").disabled = !S.segments.length;
}
async function selectSeg(id, play = false) {
  S.sel = id;
  const s = S.segments.find((x) => x.id === id);
  if (s && (!S.cur || S.cur.path !== s.path)) await openFile({ path: s.path, name: s.name }, true);
  S.pendingIn = null;
  renderSegs(); drawTimeline(); syncFrameUI(); updateMarks(); syncHookUI(); S.dirty = true;
  if (s) {
    const v = video();
    seek(s.start + 0.01);
    if (play) { S.stopAt = s.end; v.play().catch(() => { }); }
  }
}

// ------------------------------------------------------------ 타임라인
function drawTimeline() {
  const box = $("#tlSegs"); box.innerHTML = "";
  if (!S.cur) return;
  const d = S.cur.info.duration || 1;
  S.segments.forEach((s, i) => {
    if (s.path !== S.cur.path) return;
    const el = document.createElement("div");
    el.className = "tl-seg" + (S.sel === s.id ? " sel" : "");
    el.style.left = (s.start / d * 100) + "%";
    el.style.width = Math.max(0.4, (s.end - s.start) / d * 100) + "%";
    el.style.background = COLORS[i % COLORS.length];
    el.textContent = i + 1;
    box.appendChild(el);
  });
  const p = $("#tlPending");
  if (S.pendingIn !== null) {
    p.classList.remove("hidden");
    p.style.left = (S.pendingIn / d * 100) + "%";
    p.style.width = Math.max(0, (video().currentTime - S.pendingIn) / d * 100) + "%";
  } else p.classList.add("hidden");
}

// ------------------------------------------------------------ 화면 배치
function curSeg() { return S.segments.find((x) => x.id === S.sel) || null; }
function curFraming() { const s = curSeg(); return s ? s.framing : S.draft; }
function setFraming(patch) {
  const s = curSeg();
  const f = { ...curFraming(), ...patch };
  if (s) s.framing = f; else S.draft = f;
  // 선택 구간을 고치면 다음 구간 기본값도 같이 따라가게
  if (s) S.draft = { ...f };
  S.draftTouched = true; S.dirty = true;
  syncFrameUI(); saveProject();
}
function syncFrameUI() {
  const f = curFraming(), s = curSeg();
  const idx = s ? S.segments.indexOf(s) + 1 : 0;
  const tg = $("#frameTarget");
  tg.textContent = s ? `지금 고치는 것: 구간 ${idx}` : "다음에 추가할 구간의 화면";
  tg.classList.toggle("on", !!s);
  $$("[data-mode]").forEach((b) => b.classList.toggle("on", b.dataset.mode === f.mode));
  $("#zoom").value = f.zoom; $("#px").value = f.px; $("#py").value = f.py;
  $("#zoomVal").textContent = Math.round(f.zoom * 100) + "%";
}
function srcDims() {
  const v = video();
  if (v.videoWidth) return [v.videoWidth, v.videoHeight];
  if (S.cur) return [S.cur.info.width, S.cur.info.height];
  return [1920, 1080];
}
function geom(W, H, f) {
  if (f.mode === "fill") {
    const s = Math.max(OW / W, OH / H) * f.zoom;
    const sw = W * s, sh = H * s;
    return { mode: "fill", fg: { x: -(sw - OW) * f.px, y: -(sh - OH) * f.py, w: sw, h: sh }, roomX: sw - OW, roomY: sh - OH };
  }
  const s0 = Math.max(OW / W, OH / H);
  const bw = W * s0, bh = H * s0;
  const s = Math.min(OW / W, OH / H) * f.zoom;
  const fw = W * s, fh = H * s;
  return {
    mode: "fit", bg: { x: -(bw - OW) / 2, y: -(bh - OH) / 2, w: bw, h: bh },
    fg: { x: (OW - fw) * f.px, y: (OH - fh) * f.py, w: fw, h: fh }, roomX: fw - OW, roomY: fh - OH,
  };
}
function bindPreviewDrag() {
  const c = $("#preview");
  let start = null;
  c.onpointerdown = (e) => {
    c.setPointerCapture(e.pointerId); c.classList.add("drag");
    start = { x: e.clientX, y: e.clientY, f: { ...curFraming() } };
  };
  c.onpointermove = (e) => {
    if (!start) return;
    const k = c.clientWidth / OW;
    const [W, H] = srcDims();
    const g = geom(W, H, start.f);
    const dx = (e.clientX - start.x) / k, dy = (e.clientY - start.y) / k;
    const patch = {};
    if (Math.abs(g.roomX) > 1) patch.px = clamp01(start.f.px + (g.mode === "fill" ? -dx / g.roomX : -dx / g.roomX));
    if (Math.abs(g.roomY) > 1) patch.py = clamp01(start.f.py + (g.mode === "fill" ? -dy / g.roomY : -dy / g.roomY));
    if (Object.keys(patch).length) setFraming(patch);
  };
  c.onpointerup = c.onpointercancel = () => { start = null; c.classList.remove("drag"); };
  c.onwheel = (e) => {
    e.preventDefault();
    const f = curFraming();
    setFraming({ zoom: Math.max(1, Math.min(3, f.zoom * (e.deltaY < 0 ? 1.05 : 1 / 1.05))) });
  };
}
function clamp01(v) { return Math.max(0, Math.min(1, v)); }

// ------------------------------------------------------------ 글자·로고 그리기
let saveStyleT = null;
function saveStyle() {
  syncStyleUI(); S.dirty = true;
  clearTimeout(saveStyleT);
  saveStyleT = setTimeout(() => api("/api/settings", { style: S.style }).catch(() => { }), 800);
}
function syncTplUI() {
  const bof = isBof();
  $$("[data-tpl]").forEach((b) => b.classList.toggle("on", b.dataset.tpl === S.style.tpl));
  $("#tplBof").classList.toggle("hidden", !bof);
  $("#tplFree").classList.toggle("hidden", bof);
  $("#badgeBox").classList.toggle("hidden", !bof);
  updateBadgeBox();
}
function syncHookUI() {
  const sg = curSeg();
  const t = $("#hookTarget"); if (!t) return;
  t.textContent = sg ? `구간 ${S.segments.indexOf(sg) + 1}의 자막` : "다음에 추가할 구간의 자막";
  t.classList.toggle("on", !!sg);
  $("#bHook").value = sg ? (sg.hook || "") : S.draftHook;
  $("#bBadge").checked = sg ? !!sg.badge : S.draftBadge;
}
function syncStyleUI() {
  $$("[data-tstyle]").forEach((b) => b.classList.toggle("on", b.dataset.tstyle === S.style.tstyle));
  $$("[data-lpos]").forEach((b) => b.classList.toggle("on", b.dataset.lpos === S.style.logoPos));
}
function wrapLines(ctx, text, maxW) {
  const out = [];
  for (const para of text.split("\n")) {
    if (!para.trim()) { out.push(""); continue; }
    const words = para.split(/(\s+)/);
    let line = "";
    for (const w of words) {
      const test = line + w;
      if (ctx.measureText(test).width <= maxW || !line) {
        if (ctx.measureText(test).width > maxW) {
          // 한 단어가 너무 길면 글자 단위로 자르기
          for (const ch of w) {
            if (ctx.measureText(line + ch).width > maxW && line) { out.push(line); line = ch; } else line += ch;
          }
        } else line = test;
      } else { out.push(line.trimEnd()); line = w.trimStart(); }
    }
    out.push(line.trimEnd());
  }
  while (out.length && out[out.length - 1] === "") out.pop();
  return out.slice(0, 4);
}
function drawTextBlock(ctx, text, size, weight, topY, style) {
  if (!text || !text.trim()) return;
  ctx.save();
  ctx.font = `${weight} ${size}px Pretendard, "Malgun Gothic", sans-serif`;
  ctx.textAlign = "center"; ctx.textBaseline = "middle";
  const lines = wrapLines(ctx, text, 940);
  const lh = size * 1.28;
  lines.forEach((ln, i) => {
    const y = topY + lh * i + lh / 2;
    if (style === "band" && ln) {
      const w = ctx.measureText(ln).width + size * 0.7;
      ctx.fillStyle = "rgba(0,0,0,0.78)";
      roundRect(ctx, OW / 2 - w / 2, y - lh / 2 + 2, w, lh - 4, size * 0.18); ctx.fill();
      ctx.fillStyle = "#fff"; ctx.fillText(ln, OW / 2, y);
    } else {
      ctx.shadowColor = "rgba(0,0,0,0.75)"; ctx.shadowBlur = size * 0.35; ctx.shadowOffsetY = size * 0.05;
      ctx.lineWidth = Math.max(3, size * 0.08); ctx.strokeStyle = "rgba(0,0,0,0.45)"; ctx.lineJoin = "round";
      ctx.strokeText(ln, OW / 2, y);
      ctx.shadowBlur = size * 0.2;
      ctx.fillStyle = style === "yellow" ? "#ffe14d" : "#ffffff";
      ctx.fillText(ln, OW / 2, y);
    }
  });
  ctx.restore();
}
function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}
function parseRuns(line) {
  // *금색* 표시 해석
  const runs = []; let gold = false;
  for (const part of line.split("*")) { if (part) runs.push({ t: part, gold }); gold = !gold; }
  return runs;
}
function fitFont(ctx, text, weight, size, family, maxW) {
  let sz = size;
  ctx.font = `${weight} ${sz}px ${family}`;
  while (ctx.measureText(text).width > maxW && sz > 20) { sz -= 2; ctx.font = `${weight} ${sz}px ${family}`; }
  return sz;
}
const SERIF = `SourceSerif, Georgia, "Times New Roman", serif`;
const SANS = `Pretendard, "Malgun Gothic", sans-serif`;
const GOLD = "#e9b44c", GOLD2 = "#f2c14e";
// 양식 수치 (app/templates/best_of_fest.json 의 reel 부분 — 없으면 아래 기본값)
function TR() { return (S.state && S.state.template && S.state.template.reel) || {}; }
function drawBof(ctx, sg, opt = {}) {
  const b = S.style.bof;
  ctx.save();
  // 위쪽을 어둡게 해서 제목이 잘 보이게
  const g = ctx.createLinearGradient(0, 0, 0, OH * 0.27);
  g.addColorStop(0, "rgba(0,0,0,0.72)"); g.addColorStop(0.85, "rgba(0,0,0,0.45)"); g.addColorStop(1, "rgba(0,0,0,0.0)");
  ctx.fillStyle = g; ctx.fillRect(0, 0, OW, OH * 0.27);
  // 영상 아래 흐린 배경도 실제 계정처럼 한 톤 더 어둡게
  ctx.fillStyle = "rgba(0,0,0,0.28)"; ctx.fillRect(0, 1108, OW, OH - 1108);
  ctx.textAlign = "center"; ctx.textBaseline = "middle";
  ctx.shadowColor = "rgba(0,0,0,0.55)"; ctx.shadowBlur = 14; ctx.shadowOffsetY = 2;
  ctx.fillStyle = GOLD; ctx.font = `700 52px ${SERIF}`;
  ctx.fillText("BEST OF FEST", OW / 2, 246);
  const series = String(b.series || "").replace(/\D/g, "");
  if (series) {
    ctx.font = `700 25px ${SANS}`;
    if ("letterSpacing" in ctx) ctx.letterSpacing = "5px";
    ctx.fillText(`WINNER SERIES ${series.padStart(2, "0")}`, OW / 2, 300);
    if ("letterSpacing" in ctx) ctx.letterSpacing = "0px";
  }
  if (b.en) {
    ctx.fillStyle = "#fff";
    fitFont(ctx, b.en, 600, 96, SERIF, 1000);
    ctx.fillText(b.en, OW / 2, 372);
  }
  if (b.ko) {
    ctx.fillStyle = "rgba(255,255,255,0.92)";
    fitFont(ctx, b.ko, 500, 30, SANS, 980);
    ctx.fillText(b.ko, OW / 2, 444);
  }
  // 구간 자막 (최대 2줄, *별표* = 금색)
  const cp = TR().caption || {};
  const hook = (sg && sg.hook) || "";
  if (hook.trim()) {
    const size = cp.size || 58;
    ctx.font = `700 ${size}px ${SANS}`;
    ctx.shadowColor = "rgba(0,0,0,0.7)"; ctx.shadowBlur = 16; ctx.shadowOffsetY = 3;
    ctx.textAlign = "left";
    const lines = hook.split("\n").slice(0, cp.max_lines || 2);
    lines.forEach((ln, i) => {
      const runs = parseRuns(ln);
      // 너무 길면 화면 폭(1000)에 맞게 글자를 줄임
      let w = runs.reduce((a, r) => a + ctx.measureText(r.t).width, 0);
      const sc = w > 1000 ? 1000 / w : 1;
      ctx.save();
      if (sc < 1) { ctx.translate(OW / 2, 0); ctx.scale(sc, 1); ctx.translate(-OW / 2, 0); }
      let x = (OW - w) / 2;
      const y = (cp.first_y || 1170) + i * (cp.line_gap || 78);
      for (const r of runs) { ctx.fillStyle = r.gold ? (cp.accent || GOLD2) : "#fff"; ctx.fillText(r.t, x, y); x += ctx.measureText(r.t).width; }
      ctx.restore();
    });
  }
  if (!opt.noBadge) drawBadge(ctx, sg);
  ctx.restore();
}
// 'hero' 로 정했거나 자막에 '베스트 퍼포먼스'가 있으면 배지를 크게 + 빛
function isHero(sg) { return !!(sg && sg.badge && (sg.badge === "hero" || /베스트\s*퍼포먼스/.test(sg.hook || ""))); }
function drawBadge(ctx, sg) {
  const bimg = curBadge();
  if (!(sg && sg.badge && bimg)) return;
  const bc = TR().badge || {};
  const hero = isHero(sg);
  const w = (bc.width || 300) * (hero ? (bc.hero_scale || 1.15) : 1), h = w * bimg.height / bimg.width;
  const cy = bc.center_y || 1452;
  ctx.save();
  if (hero && bc.hero_glow !== false) {
    // 은은한 금빛
    const g = ctx.createRadialGradient(OW / 2, cy, w * 0.1, OW / 2, cy, w * 0.75);
    g.addColorStop(0, "rgba(242,193,78,0.30)"); g.addColorStop(0.6, "rgba(242,193,78,0.10)"); g.addColorStop(1, "rgba(242,193,78,0)");
    ctx.fillStyle = g; ctx.fillRect(OW / 2 - w, cy - w, w * 2, w * 2);
    ctx.shadowColor = "rgba(255,200,80,0.55)"; ctx.shadowBlur = 30;
  } else { ctx.shadowColor = "rgba(0,0,0,0.5)"; ctx.shadowBlur = 18; }
  ctx.drawImage(bimg, (OW - w) / 2, cy - h / 2, w, h);
  ctx.restore();
}
// 엔딩 화면 (짙은 남색 + 가운데 따뜻한 빛)
function drawEnding(ctx) {
  const e = TR().ending || {};
  ctx.save();
  ctx.fillStyle = e.bg || "#15151f"; ctx.fillRect(0, 0, OW, OH);
  const g = ctx.createRadialGradient(OW / 2, 960, 40, OW / 2, 960, 900);
  g.addColorStop(0, "rgba(120,90,40,0.38)"); g.addColorStop(0.5, "rgba(80,60,30,0.14)"); g.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = g; ctx.fillRect(0, 0, OW, OH);
  ctx.textAlign = "center"; ctx.textBaseline = "middle";
  const lines = e.lines || [
    { text: "BEST OF FEST", font: "serif", weight: 700, size: 100, y: 865, color: GOLD },
    { text: "세계 축제가 주목한 무대를", font: "sans", weight: 500, size: 40, y: 985, color: "#ffffff" },
    { text: "한국에 소개합니다", font: "sans", weight: 500, size: 40, y: 1047, color: "#ffffff" },
    { text: "@best_of_fest", font: "sans", weight: 500, size: 34, y: 1138, color: GOLD },
  ];
  for (const l of lines) {
    ctx.font = `${l.weight || 500} ${l.size}px ${l.font === "serif" ? SERIF : SANS}`;
    ctx.fillStyle = l.color || "#fff";
    if (l.font === "serif") { ctx.shadowColor = "rgba(233,180,76,0.35)"; ctx.shadowBlur = 24; } else { ctx.shadowBlur = 0; }
    ctx.fillText(l.text, OW / 2, l.y);
  }
  ctx.restore();
}
function canvasPNG(draw) {
  const c = document.createElement("canvas"); c.width = OW; c.height = OH;
  draw(c.getContext("2d"));
  return c.toDataURL("image/png");
}
function drawOverlay(ctx, sg, opt = {}) {
  const st = S.style;
  if (isBof()) { drawBof(ctx, sg, opt); drawLogo(ctx); return; }
  drawTextBlock(ctx, st.title, st.tSize, 800, st.tY * OH, st.tstyle);
  drawTextBlock(ctx, st.sub, Math.round(st.tSize * 0.62), 700, st.sY * OH, st.tstyle === "yellow" ? "shadow" : st.tstyle);
  drawLogo(ctx);
}
function drawLogo(ctx) {
  const st = S.style;
  if (S.logoImg) {
    const im = S.logoImg;
    const w = OW * st.logoSize, h = w * im.height / im.width;
    const m = 48;
    const x = st.logoPos.endsWith("l") ? m : OW - m - w;
    const y = st.logoPos.startsWith("t") ? m + 40 : OH * 0.80 - h;
    ctx.save(); ctx.globalAlpha = st.logoAlpha; ctx.drawImage(im, x, y, w, h); ctx.restore();
  }
}
function hasOverlay() { return isBof() || !!(S.style.title.trim() || S.style.sub.trim() || S.logoImg); }
function overlayPNG(sg, opt = {}) {
  return canvasPNG((ctx) => drawOverlay(ctx, sg, opt));
}
function previewSeg() {
  // 선택한 구간 > 재생 위치에 있는 구간 > 다음에 추가할 구간
  const sg = curSeg(); if (sg) return sg;
  if (S.cur) {
    const t = video().currentTime;
    const hit = S.segments.find((x) => x.path === S.cur.path && t >= x.start && t < x.end);
    if (hit) return hit;
  }
  return { hook: S.draftHook, badge: S.draftBadge };
}

// ------------------------------------------------------------ 미리보기 그리기
const blurCanvas = document.createElement("canvas");
blurCanvas.width = 27; blurCanvas.height = 48;
let lastSize = "";
function drawLoop() {
  const v = video();
  const c = $("#preview");
  const size = c.clientWidth + "x" + c.clientHeight;
  if (size !== lastSize) { lastSize = size; S.dirty = true; }
  if (S.dirty || !v.paused) {
    S.dirty = false;
    try { drawPreview(); } catch (e) { /* 계속 */ }
  }
  if (S.stopAt !== null && v.currentTime >= S.stopAt) { v.pause(); S.stopAt = null; }
  if (!v.paused && S.pendingIn !== null) drawTimeline();
  const head = $("#tlHead");
  if (S.cur && S.cur.info.duration) head.style.left = (v.currentTime / S.cur.info.duration * 100) + "%";
  requestAnimationFrame(drawLoop);
}
function drawPreview() {
  const c = $("#preview");
  if ($("#editor").classList.contains("hidden")) return;
  const dpr = Math.min(1.5, window.devicePixelRatio || 1);
  const cw = Math.round(c.clientWidth * dpr), ch = Math.round(c.clientHeight * dpr);
  if (c.width !== cw || c.height !== ch) { c.width = cw; c.height = ch; }
  const ctx = c.getContext("2d");
  const k = cw / OW;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = "#000"; ctx.fillRect(0, 0, cw, ch);
  ctx.setTransform(k, 0, 0, k, 0, 0);
  const v = video();
  if (v.readyState >= 2 && v.videoWidth) {
    const g = geom(v.videoWidth, v.videoHeight, curFraming());
    if (g.mode === "fit") {
      // 작은 캔버스에 줄였다가 키우는 방식 — 옛날 노트북에서도 가볍고, 실제 결과(boxblur)와 비슷
      const bc = blurCanvas.getContext("2d");
      bc.imageSmoothingQuality = "low";
      bc.drawImage(v, g.bg.x / 40, g.bg.y / 40, g.bg.w / 40, g.bg.h / 40);
      ctx.save(); ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = "high";
      ctx.drawImage(blurCanvas, 0, 0, OW, OH);
      ctx.fillStyle = "rgba(0,0,0,0.18)"; ctx.fillRect(0, 0, OW, OH);
      ctx.restore();
    }
    ctx.drawImage(v, g.fg.x, g.fg.y, g.fg.w, g.fg.h);
  }
  drawOverlay(ctx, previewSeg());
  if (S.style.guide) {
    ctx.save();
    ctx.fillStyle = "rgba(255,106,61,0.16)";
    ctx.fillRect(0, OH * 0.80, OW, OH * 0.20);
    ctx.fillRect(OW * 0.86, OH * 0.45, OW * 0.14, OH * 0.35);
    ctx.fillRect(0, 0, OW, OH * 0.06);
    ctx.fillStyle = "rgba(255,255,255,0.7)";
    ctx.font = "700 34px Pretendard, sans-serif"; ctx.textAlign = "center";
    ctx.fillText("앱 버튼·설명에 가려지는 곳", OW / 2, OH * 0.90);
    ctx.restore();
  }
}

// ------------------------------------------------------------ 만들기
function bindModal() {
  $("#btnExport").onclick = openExport;
  $("#exCancel").onclick = closeModal;
  $("#exGo").onclick = startExport;
  $("#runStop").onclick = async () => { if (S.job) await api("/api/cancel", { id: S.job }).catch(() => { }); };
  $("#doneEdit").onclick = closeModal;
  $("#doneNew").onclick = () => {
    closeModal(); S.segments = []; S.sel = null; store.del("project");
    S.style.title = ""; S.style.sub = ""; $("#tTitle").value = ""; $("#tSub").value = ""; $("#exCaption").value = "";
    const keepYear = S.style.bof.year;
    S.style.bof = { series: "", year: keepYear, en: "", ko: "", company: "", tags: "", slug: "", adult: false };
    ["bSeries", "bEn", "bKo", "bCompany", "bTags"].forEach((id) => $("#" + id).value = "");
    S.draftHook = ""; S.draftBadge = true; syncHookUI(); saveStyle();
    video().pause(); show("#home"); loadFiles();
  };
  $("#errClose").onclick = closeModal;
  $("#errRetry").onclick = startExport;
  $("#doneCopy").onclick = async () => {
    const t = $("#doneCap").textContent;
    try { await navigator.clipboard.writeText(t); }
    catch { const ta = document.createElement("textarea"); ta.value = t; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove(); }
    toast("설명을 복사했어요");
  };
}
function modalStep(id) { ["#exportForm", "#exportRun", "#exportDone", "#exportErr"].forEach((x) => $(x).classList.toggle("hidden", x !== id)); }
function openExport() {
  if (!S.segments.length) return;
  video().pause();
  const base = ((isBof() ? S.style.bof.en : S.style.title.split("\n")[0]) || S.segments[0].name.replace(/\.[^.]+$/, "")).trim();
  if (S.projCaption) $("#exCaption").value = S.projCaption;
  else if (isBof() && !$("#exCaption").value.trim()) $("#exCaption").value = bofCaption();
  // Best of Fest: 완성본 이름은 {slug}_reel.mp4 (같은 이름이 있으면 서버가 _reel2, _reel3 … 로 붙임)
  const slug = isBof() ? String(S.style.bof.slug || "").replace(/[^0-9a-z]/gi, "").toLowerCase() : "";
  $("#exName").value = slug ? slug + "_reel" : base.slice(0, 60);
  $("#exLoud").checked = S.state.settings.loudnorm !== false;
  const endSec = isBof() ? (TR().ending_sec || 3) : 0;
  $("#exSummary").textContent = `장면 ${S.segments.length}개${endSec ? ` + 엔딩 ${endSec}초` : ""} · 총 ${(totalLen() + endSec).toFixed(1)}초 · 세로 1080×1920 · 저장 위치: ${S.state.settings.output_dir || "(미정)"}`;
  modalStep("#exportForm");
  $("#modal").classList.remove("hidden");
}
function bofCaption() {
  // STYLE.md 5장 릴스 캡션: 첫 줄 = 릴스 자막 1번(줄바꿈 없이), 해시태그 5개 이내
  const b = S.style.bof;
  const hookSeg = S.segments.find((x) => (x.hook || "").trim());
  const hook = hookSeg ? hookSeg.hook.replace(/\*/g, "").replace(/\s*\n\s*/g, " ").trim() : "";
  const y = String(b.year || "").replace(/\D/g, "").slice(0, 4);
  const cap = (S.state && S.state.template && S.state.template.caption) || {};
  const tags = [...(cap.hashtags_fixed || ["#베스트오브페스트", "#서울아츠어워즈", "#에든버러페스티벌"])];
  for (const t of String(b.tags || "").split(/[\s,]+/)) {
    const h = t.startsWith("#") ? t : "#" + t;
    if (t && !tags.includes(h)) tags.push(h);
  }
  return [
    hook,
    `세계 축제가 주목한 무대 〈${b.en || ""}〉, 30초로 먼저 만나 보세요.`,
    `${y} 서울아츠어워즈 베스트 퍼포먼스${b.adult ? " · 성인 관람" : ""}`,
    "",
    "한국에서 이 무대를 보고 싶다면 저장하고, 함께 볼 친구에게 보내 주세요.",
    `Seoul Arts Awards ${y} Best Performance${b.company ? " · " + b.company : ""}`,
    tags.slice(0, cap.hashtags_max || 5).join(" "),
  ].join("\n");
}
function closeModal() { $("#modal").classList.add("hidden"); const dv = $("#doneVideo"); dv.pause(); dv.removeAttribute("src"); dv.load(); }
async function startExport() {
  try { await document.fonts.load("800 80px Pretendard"); await document.fonts.load("700 50px Pretendard"); } catch { }
  try { await document.fonts.load("700 100px SourceSerif"); await document.fonts.load("500 40px Pretendard"); } catch { }
  const bof = isBof();
  // 첫 장면의 배지는 따로 그려서 영상 시작 후 서서히 나타나게 함
  const fadeBadge = bof && S.segments.length && S.segments[0].badge && curBadge() && TR().badge?.fade_in_sec !== 0;
  const body = {
    segments: S.segments.map((s) => ({ path: s.path, start: s.start, end: s.end, framing: s.framing })),
    overlay: !bof && hasOverlay() ? overlayPNG(null) : null,
    seg_overlays: bof ? S.segments.map((s, i) => overlayPNG(s, { noBadge: i === 0 && fadeBadge })) : null,
    badge_layer: fadeBadge ? canvasPNG((ctx) => drawBadge(ctx, S.segments[0])) : null,
    ending: bof ? canvasPNG(drawEnding) : null,
    ending_sec: TR().ending_sec || 3,
    name: $("#exName").value.trim(),
    slug: bof ? $("#exName").value.trim().replace(/_reel\d*$/, "").toLowerCase().replace(/[^0-9a-z]/g, "") : "",
    caption: $("#exCaption").value,
    loudnorm: $("#exLoud").checked,
  };
  modalStep("#exportRun");
  $("#runBar").style.width = "0%"; $("#runPct").textContent = "0%"; $("#runMsg").textContent = "준비 중";
  try {
    const r = await api("/api/export", body);
    S.job = r.job;
    const t0 = Date.now();
    for (; ;) {
      const st = await api("/api/job?id=" + r.job);
      const pct = Math.round(st.progress * 100);
      $("#runBar").style.width = pct + "%"; $("#runPct").textContent = pct + "%";
      let msg = st.message || "";
      if (st.progress > 0.03) {
        const el = (Date.now() - t0) / 1000, left = el / st.progress - el;
        msg += ` · 남은 시간 약 ${left > 90 ? Math.round(left / 60) + "분" : Math.max(1, Math.round(left)) + "초"}`;
      }
      $("#runMsg").textContent = msg;
      if (st.state === "done") {
        modalStep("#exportDone");
        $("#doneInfo").textContent = S.state.remote ? st.output.split(/[\\/]/).pop() + " — 구글 드라이브 완성본 폴더에도 저장됐어요" : st.output;
        $("#doneVideo").src = mediaUrl(st.output);
        $("#doneOpen").onclick = () => api("/api/open", { path: st.output });
        $("#doneDl").href = mediaUrl(st.output) + "&dl=1";
        saveProject({ status: "made", output: st.output });
        const cap = body.caption.trim();
        $("#doneCapBox").classList.toggle("hidden", !cap); $("#doneCap").textContent = cap;
        return;
      }
      if (st.state === "error") {
        if (st.cancel) { closeModal(); toast("만들기를 멈췄어요"); return; }
        throw new Error(st.error || "알 수 없는 오류");
      }
      await new Promise((res) => setTimeout(res, 800));
    }
  } catch (e) {
    console.error("export error", e && e.stack || e);
    modalStep("#exportErr");
    $("#errText").textContent = e.message;
    api("/api/report", { note: "자동 기록 — 만들기 실패: " + e.message.slice(0, 300) }).catch(() => { });
  } finally { S.job = null; }
}


// ------------------------------------------------------------ 설정
function bindSettings() {
  $("#remoteBox").classList.add("local-only");
  $("#remoteOn").onclick = () => remoteSetup($("#remotePin").value);
  $("#remoteRedo").onclick = () => remoteSetup("");
  $("#remoteDisable").onclick = async () => { await api("/api/remote_off", {}); await refreshState(); showRemoteResult(null); toast("원격 접속을 껐어요"); };
  $("#remoteCopy").onclick = async () => { try { await navigator.clipboard.writeText($("#remoteUrl").textContent); toast("주소를 복사했어요"); } catch { } };
  $("#setClose").onclick = () => $("#settings").classList.add("hidden");
  $("#setClaudeAuto").onchange = async (e) => { await api("/api/settings", { claude_auto: e.target.checked }); toast(e.target.checked ? "자막 자동 채우기를 켰어요" : "자막 자동 채우기를 껐어요"); };
  $("#setEncSel").onchange = async (e) => { await api("/api/settings", { encoder: e.target.value }); toast("바꿨어요"); setTimeout(fillSettings, 3000); };
  $("#btnReport").onclick = async () => {
    try { await api("/api/report", { note: "설정 화면에서 보냄" }); toast("기록을 완성본 폴더의 _오류기록에 저장했어요", 3500); }
    catch (e) { toast(e.message); }
  };
  $("#btnCleanup").onclick = async () => { const r = await api("/api/cleanup", {}); toast(`임시 파일 ${r.removed}개를 지웠어요`); };
  $("#btnQuit").onclick = async () => { await api("/api/shutdown", {}).catch(() => { }); document.body.innerHTML = "<div class='empty' style='margin-top:30vh'>프로그램을 껐어요. 이 창은 닫아도 돼요.</div>"; };
}
function showRemoteResult(r) {
  const enabled = !!S.state.remote_enabled;
  const live = enabled && S.state.funnel_on === true;
  // PIN 은 정했지만 인터넷 공개가 실제로 안 켜진 상태도 따로 보여 줌
  $("#remoteOff").classList.toggle("hidden", enabled);
  $("#remoteOnBox").classList.toggle("hidden", !enabled);
  $("#remoteLive").classList.toggle("hidden", !live);
  $("#remoteDead").classList.toggle("hidden", live);
  const url = (r && r.url) || S.state.funnel_url || "";
  $("#remoteUrl").textContent = url;
  const qrBox = $("#remoteQr"); qrBox.innerHTML = "";
  if (url && live && window.qrcode) {
    try { const q = qrcode(0, "M"); q.addData(url); q.make(); qrBox.innerHTML = q.createSvgTag(4, 0); } catch { }
  }
  const msg = $("#remoteMsg"); msg.innerHTML = "";
  if (r && r.message) {
    const p = document.createElement("div"); p.textContent = r.message; msg.appendChild(p);
  }
  if (r && r.approve_url) {
    const a = document.createElement("a"); a.href = r.approve_url; a.target = "_blank"; a.textContent = r.approve_url; msg.appendChild(a);
  }
}
async function remoteSetup(pin) {
  $("#remoteMsg").textContent = "켜는 중이에요… 노트북에 '예/아니요' 창이 뜨면 '예'를 눌러 주세요.";
  try {
    const r = await api("/api/remote_setup", { pin });
    await refreshState(); showRemoteResult(r);
    if (r.ok) toast("원격 접속을 켰어요");
  } catch (e) { $("#remoteMsg").textContent = e.message; }
}
async function fillSettings() {
  await refreshState();
  if (!S.state.remote) showRemoteResult(null);
  const st = S.state.settings;
  $("#setSrc").textContent = st.source_dir || "-";
  $("#setOut").textContent = st.output_dir || "-";
  $("#setEncSel").value = st.encoder === "software" ? "software" : "auto";
  const names = { h264_qsv: "인텔 하드웨어 (빠름)", h264_mf: "윈도우 하드웨어 (빠름)", libx264: "기본 방식 (느리지만 안정적)" };
  $("#setEnc").textContent = "지금: " + (names[S.state.encoder] || "확인 중…");
  $("#setVer").textContent = `버전 ${S.state.version}`;
  const cl = S.state.claude || {};
  $("#setClaudeAuto").checked = st.claude_auto !== false;
  $("#setClaude").textContent = !cl.installed ? "이 노트북에서 Claude Code를 찾지 못했어요"
    : cl.running ? `지금 채우는 중: ${cl.running}`
      : `새 자동 초안이 생기면 Claude가 자막을 채우고 '확인 필요'로 표시해요${cl.last ? " · 최근: " + cl.last : ""}`;
}

init().catch((e) => { document.body.innerHTML = `<div class="empty">프로그램을 시작하지 못했어요: ${e.message}</div>`; });
