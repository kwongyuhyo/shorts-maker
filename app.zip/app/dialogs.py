"""폴더/파일 고르기 창. 결과 경로를 표준출력으로 내보냄."""
import sys


def main():
    kind = sys.argv[1] if len(sys.argv) > 1 else "folder"
    init = sys.argv[2] if len(sys.argv) > 2 else ""
    import tkinter as tk
    from tkinter import filedialog
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    root.update()
    if kind == "file":
        p = filedialog.askopenfilename(
            parent=root, initialdir=init or None, title="영상 파일 고르기",
            filetypes=[("영상 파일", "*.mp4 *.mov *.m4v *.mkv *.avi *.mts *.m2ts *.webm *.3gp *.wmv"),
                       ("모든 파일", "*.*")])
    else:
        p = filedialog.askdirectory(parent=root, initialdir=init or None, title="폴더 고르기",
                                    mustexist=True)
    root.destroy()
    if p:
        sys.stdout.buffer.write(p.encode("utf-8"))


if __name__ == "__main__":
    main()
